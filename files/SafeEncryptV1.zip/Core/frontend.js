defaultpass = "sR47uFSeuQbS32TC";

function SafeencryptPass() {
    encryptThis = prompt("Tekst om te encrypten:");
    ENpassword = prompt("Wachtwoord");
    encrypted = CryptoJS.AES.encrypt(encryptThis, ENpassword);
    document.getElementById('encryptResultPass').innerHTML = encrypted;
}

function SafedecryptPass() {
    decryptThis = prompt("Tekst om te decrypten:");
    DEpassword = prompt("Wachtwoord");
    decrypted = CryptoJS.AES.decrypt(decryptThis, DEpassword);  
    document.getElementById('decryptResultPass').innerHTML = decrypted.toString(CryptoJS.enc.Utf8);
}

function SafeencryptNoPass() {
    encryptThis = prompt("Tekst om te encrypten:");
    encrypted = CryptoJS.AES.encrypt(encryptThis, defaultpass);
    document.getElementById('encryptResultNoPass').innerHTML = encrypted;
}

function SafedecryptNoPass() {
    decryptThis = prompt("Tekst om te decrypten:");
    decrypted = CryptoJS.AES.decrypt(decryptThis, defaultpass);
    document.getElementById('decryptResultNoPass').innerHTML = decrypted.toString(CryptoJS.enc.Utf8);
}
function reset() {
    delete encryptThis;
    delete ENpassword;
    delete encrypted;
    delete decryptThis;
    delete DEpassword;
    delete decrypted;
    document.getElementById('encryptResultPass').innerHTML = "Hier komt het resultaat van het encrypten.";
    document.getElementById('decryptResultPass').innerHTML = "Hier komt het resultaat van het decrypten.";
    document.getElementById('encryptResultNoPass').innerHTML = "Hier komt het resultaat van het encrypten.";
    document.getElementById('decryptResultNoPass').innerHTML = "Hier komt het resultaat van het decrypten.";
}