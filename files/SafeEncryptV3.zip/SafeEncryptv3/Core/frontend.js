// SafeEncrypt V3
defaultpass = "e3YkQkg0LzguLiVZLTVFZyEoeX0yek16ZDViRixDJHJyOjNqYSpqcm16d3pLaVtaTjtHYlQ0ViEvWVlYcWhnals7NnBNXThEZE00cTRlWWQ9SlRSWXU2SDhGOFMsLUxQXUM7dFNfNi1CLXBiOFkkZkN2JCVHUT9WQnZpVXl4UFZ9RHVBWVIqUz8jenlxRzorKHsqNz0pJVdQdiFkfSRtSDRML2d2SHVaVnUqZldXTTUvJGdKOlNVTGNkcWIqTlt0OCxCVXdqblAsaXk5RHhXY1d2JU5lZmcmai9SaE53U0BVW0glQytZOyQuJWJwUmdQKSx9NixlSlQ6anh9eCwmJQ==";

// Delete all objects
function secureDelete() {
    delete ENpassword;
    delete DEpassword;
    delete encryptThis;
    delete encrypted;
    delete decryptThis;
    delete decrypted;
    delete SECarray;
}

// Generate a random Base64 title so it cant be searched easily in history
function secureRandomNumber() {
    SECarray = new Uint32Array(1);
    return window.crypto.getRandomValues(SECarray);
}
document.title = btoa(secureRandomNumber());
secureDelete();

// Encrypt with password
function SafeEncryptPass() {
    encryptThis = document.getElementById("textpass").value;
    ENpassword = document.getElementById("pass").value;
    encrypted = CryptoJS.AES.encrypt(encryptThis, ENpassword);
    document.getElementById('ResultPass').innerHTML = encrypted;
    document.getElementById("pass").value = "";
    secureDelete();
}

// Decrypt with password
function SafedecryptPass() {
    decryptThis = document.getElementById("textpass").value;
    DEpassword = document.getElementById("pass").value;
    decrypted = CryptoJS.AES.decrypt(decryptThis, DEpassword);  
    document.getElementById('ResultPass').innerHTML = decrypted.toString(CryptoJS.enc.Utf8);
    document.getElementById("pass").value = "";
    secureDelete();
}

// Encrypt without password
function SafeEncryptNoPass() {
    encryptThis = document.getElementById("textnopass").value;
    encrypted = CryptoJS.AES.encrypt(encryptThis, atob(defaultpass));
    document.getElementById('ResultNoPass').innerHTML = encrypted;
    document.getElementById("textnopass").value = "";
    secureDelete();
}

// Decrypt without password
function SafedecryptNoPass() {
    decryptThis = document.getElementById("textnopass").value;
    decrypted = CryptoJS.AES.decrypt(decryptThis, atob(defaultpass));
    document.getElementById('ResultNoPass').innerHTML = decrypted.toString(CryptoJS.enc.Utf8);
    secureDelete();
}
function reset() {
    secureDelete();
    document.getElementById('ResultPass').innerHTML = "Result";
    document.getElementById('ResultNoPass').innerHTML = "Result";
    document.getElementById("textpass").value = "";
    document.getElementById("pass").value = "";
    document.getElementById("textnopass").value = "";
}

