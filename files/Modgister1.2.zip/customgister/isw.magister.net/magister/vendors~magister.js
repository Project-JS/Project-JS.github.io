(window.webpackJsonp = window.webpackJsonp || []).push([[23], {
    117: function(e, t) {
        e.exports = function() {
            throw new Error("define cannot be used indirect")
        }
    },
    128: function(e, t) {
        e.exports = {
            isFunction: function(e) {
                return "function" == typeof e
            },
            isArray: function(e) {
                return "[object Array]" === Object.prototype.toString.apply(e)
            },
            each: function(e, t) {
                for (var n = 0, r = e.length; n < r && !1 !== t(e[n], n); n++)
                    ;
            }
        }
    },
    139: function(e, t, n) {
        (function(n, r) {
            /**
 * oclazyload - Load modules on demand (lazy load) with angularJS
 * @version v1.0.10
 * @link https://github.com/ocombe/ocLazyLoad
 * @license MIT
 * @author Olivier Combe <olivier.combe@gmail.com>
 */
            !function(n, r) {
                "use strict";
                var i = ["ng", "oc.lazyLoad"]
                  , o = {}
                  , a = []
                  , s = []
                  , c = []
                  , u = []
                  , l = n.noop
                  , d = {}
                  , f = [];
                n.module("oc.lazyLoad", ["ng"]).provider("$ocLazyLoad", ["$controllerProvider", "$provide", "$compileProvider", "$filterProvider", "$injector", "$animateProvider", function(e, t, h, v, m, y) {
                    var E = {}
                      , L = {
                        $controllerProvider: e,
                        $compileProvider: h,
                        $filterProvider: v,
                        $provide: t,
                        $injector: m,
                        $animateProvider: y
                    }
                      , T = !1
                      , M = !1
                      , x = []
                      , D = {};
                    x.push = function(e) {
                        -1 === this.indexOf(e) && Array.prototype.push.apply(this, arguments)
                    }
                    ,
                    this.config = function(e) {
                        n.isDefined(e.modules) && (n.isArray(e.modules) ? n.forEach(e.modules, function(e) {
                            E[e.name] = e
                        }) : E[e.modules.name] = e.modules),
                        n.isDefined(e.debug) && (T = e.debug),
                        n.isDefined(e.events) && (M = e.events)
                    }
                    ,
                    this._init = function(e) {
                        if (0 === s.length) {
                            var t = [e]
                              , o = ["ng:app", "ng-app", "x-ng-app", "data-ng-app"]
                              , a = /\sng[:\-]app(:\s*([\w\d_]+);?)?\s/
                              , c = function(e) {
                                return e && t.push(e)
                            };
                            n.forEach(o, function(t) {
                                o[t] = !0,
                                c(document.getElementById(t)),
                                t = t.replace(":", "\\:"),
                                void 0 !== e[0] && e[0].querySelectorAll && (n.forEach(e[0].querySelectorAll("." + t), c),
                                n.forEach(e[0].querySelectorAll("." + t + "\\:"), c),
                                n.forEach(e[0].querySelectorAll("[" + t + "]"), c))
                            }),
                            n.forEach(t, function(t) {
                                if (0 === s.length) {
                                    var r = " " + e.className + " "
                                      , i = a.exec(r);
                                    i ? s.push((i[2] || "").replace(/\s+/g, ",")) : n.forEach(t.attributes, function(e) {
                                        0 === s.length && o[e.name] && s.push(e.value)
                                    })
                                }
                            })
                        }
                        0 !== s.length || (r.jasmine || r.mocha) && n.isDefined(n.mock) || console.error("No module found during bootstrap, unable to init ocLazyLoad. You should always use the ng-app directive or angular.boostrap when you use ocLazyLoad.");
                        n.forEach(s, function(e) {
                            !function e(t) {
                                if (-1 === i.indexOf(t)) {
                                    i.push(t);
                                    var r = n.module(t);
                                    _(null, r._invokeQueue, t),
                                    _(null, r._configBlocks, t),
                                    n.forEach(r.requires, e)
                                }
                            }(e)
                        }),
                        s = [],
                        u.pop()
                    }
                    ;
                    var w = function(e) {
                        try {
                            return JSON.stringify(e)
                        } catch (r) {
                            var t = [];
                            return JSON.stringify(e, function(e, r) {
                                if (n.isObject(r) && null !== r) {
                                    if (-1 !== t.indexOf(r))
                                        return;
                                    t.push(r)
                                }
                                return r
                            })
                        }
                    }
                      , b = function(e) {
                        var t, n, r = 0;
                        if (0 == e.length)
                            return r;
                        for (t = 0,
                        n = e.length; t < n; t++)
                            r = (r << 5) - r + e.charCodeAt(t),
                            r |= 0;
                        return r
                    };
                    function O(e, t, r) {
                        if (t) {
                            var o, a, s, u = [];
                            for (o = t.length - 1; o >= 0; o--)
                                if (a = t[o],
                                n.isString(a) || (a = C(a)),
                                a && -1 === f.indexOf(a) && (!E[a] || -1 !== c.indexOf(a))) {
                                    var h = -1 === i.indexOf(a);
                                    if (s = g(a),
                                    h && (i.push(a),
                                    O(e, s.requires, r)),
                                    s._runBlocks.length > 0)
                                        for (d[a] = []; s._runBlocks.length > 0; )
                                            d[a].push(s._runBlocks.shift());
                                    n.isDefined(d[a]) && (h || r.rerun) && (u = u.concat(d[a])),
                                    _(e, s._invokeQueue, a, r.reconfig),
                                    _(e, s._configBlocks, a, r.reconfig),
                                    l(h ? "ocLazyLoad.moduleLoaded" : "ocLazyLoad.moduleReloaded", a),
                                    t.pop(),
                                    f.push(a)
                                }
                            var p = e.getInstanceInjector();
                            n.forEach(u, function(e) {
                                p.invoke(e)
                            })
                        }
                    }
                    function S(e, t) {
                        var r = e[2][0]
                          , i = e[1]
                          , a = !1;
                        n.isUndefined(o[t]) && (o[t] = {}),
                        n.isUndefined(o[t][i]) && (o[t][i] = {});
                        var s = function(e, r) {
                            o[t][i].hasOwnProperty(e) || (o[t][i][e] = []),
                            function(e, t) {
                                var r, i = !0;
                                t.length && (r = c(e),
                                n.forEach(t, function(e) {
                                    i = i && c(e) !== r
                                }));
                                return i
                            }(r, o[t][i][e]) && (a = !0,
                            o[t][i][e].push(r),
                            l("ocLazyLoad.componentLoaded", [t, i, e]))
                        };
                        function c(e) {
                            return n.isArray(e) ? b(e.toString()) : n.isObject(e) ? b(w(e)) : n.isDefined(e) && null !== e ? b(e.toString()) : e
                        }
                        if (n.isString(r))
                            s(r, e[2][1]);
                        else {
                            if (!n.isObject(r))
                                return !1;
                            n.forEach(r, function(e, t) {
                                n.isString(e) ? s(e, r[1]) : s(t, e)
                            })
                        }
                        return a
                    }
                    function _(e, t, r, i) {
                        var o, s, c, u;
                        if (t)
                            for (o = 0,
                            s = t.length; o < s; o++)
                                if (c = t[o],
                                n.isArray(c)) {
                                    if (null !== e) {
                                        if (!e.hasOwnProperty(c[0]))
                                            throw new Error("unsupported provider " + c[0]);
                                        u = e[c[0]]
                                    }
                                    var l = S(c, r);
                                    if ("invoke" !== c[1])
                                        l && n.isDefined(u) && u[c[1]].apply(u, c[2]);
                                    else {
                                        var d = function(e) {
                                            var t = a.indexOf(r + "-" + e);
                                            (-1 === t || i) && (-1 === t && a.push(r + "-" + e),
                                            n.isDefined(u) && u[c[1]].apply(u, c[2]))
                                        };
                                        if (n.isFunction(c[2][0]))
                                            d(c[2][0]);
                                        else if (n.isArray(c[2][0]))
                                            for (var f = 0, h = c[2][0].length; f < h; f++)
                                                n.isFunction(c[2][0][f]) && d(c[2][0][f])
                                    }
                                }
                    }
                    function C(e) {
                        var t = null;
                        return n.isString(e) ? t = e : n.isObject(e) && e.hasOwnProperty("name") && n.isString(e.name) && (t = e.name),
                        t
                    }
                    function A(e) {
                        if (!n.isString(e))
                            return !1;
                        try {
                            return g(e)
                        } catch (e) {
                            if (/No module/.test(e) || e.message.indexOf("$injector:nomod") > -1)
                                return !1
                        }
                    }
                    this.$get = ["$log", "$rootElement", "$rootScope", "$cacheFactory", "$q", function(e, t, r, a, c) {
                        var d, h = a("ocLazyLoad");
                        function v(t) {
                            var n = c.defer();
                            return e.error(t.message),
                            n.reject(t),
                            n.promise
                        }
                        return T || ((e = {}).error = n.noop,
                        e.warn = n.noop,
                        e.info = n.noop),
                        L.getInstanceInjector = function() {
                            return d || (d = t.data("$injector") || n.injector())
                        }
                        ,
                        {
                            _broadcast: l = function(t, n) {
                                M && r.$broadcast(t, n),
                                T && e.info(t, n)
                            }
                            ,
                            _$log: e,
                            _getFilesCache: function() {
                                return h
                            },
                            toggleWatch: function(e) {
                                e ? u.push(!0) : u.pop()
                            },
                            getModuleConfig: function(e) {
                                if (!n.isString(e))
                                    throw new Error("You need to give the name of the module to get");
                                return E[e] ? n.copy(E[e]) : null
                            },
                            setModuleConfig: function(e) {
                                if (!n.isObject(e))
                                    throw new Error("You need to give the module config object to set");
                                return E[e.name] = e,
                                e
                            },
                            getModules: function() {
                                return i
                            },
                            isLoaded: function(e) {
                                var t = function(e) {
                                    var t = i.indexOf(e) > -1;
                                    return t || (t = !!A(e)),
                                    t
                                };
                                if (n.isString(e) && (e = [e]),
                                n.isArray(e)) {
                                    var r, o;
                                    for (r = 0,
                                    o = e.length; r < o; r++)
                                        if (!t(e[r]))
                                            return !1;
                                    return !0
                                }
                                throw new Error("You need to define the module(s) name(s)")
                            },
                            _getModuleName: C,
                            _getModule: function(e) {
                                try {
                                    return g(e)
                                } catch (t) {
                                    throw (/No module/.test(t) || t.message.indexOf("$injector:nomod") > -1) && (t.message = 'The module "' + w(e) + '" that you are trying to load does not exist. ' + t.message),
                                    t
                                }
                            },
                            moduleExists: A,
                            _loadDependencies: function(e, t) {
                                var r, i, o, a = [], s = this;
                                if (null === (e = s._getModuleName(e)))
                                    return c.when();
                                try {
                                    r = s._getModule(e)
                                } catch (e) {
                                    return v(e)
                                }
                                return i = s.getRequires(r),
                                n.forEach(i, function(r) {
                                    if (n.isString(r)) {
                                        var i = s.getModuleConfig(r);
                                        if (null === i)
                                            return void x.push(r);
                                        r = i,
                                        i.name = void 0
                                    }
                                    if (s.moduleExists(r.name))
                                        return 0 !== (o = r.files.filter(function(e) {
                                            return s.getModuleConfig(r.name).files.indexOf(e) < 0
                                        })).length && s._$log.warn('Module "', e, '" attempted to redefine configuration for dependency. "', r.name, '"\n Additional Files Loaded:', o),
                                        n.isDefined(s.filesLoader) ? void a.push(s.filesLoader(r, t).then(function() {
                                            return s._loadDependencies(r)
                                        })) : v(new Error("Error: New dependencies need to be loaded from external files (" + r.files + "), but no loader has been defined."));
                                    if (n.isArray(r)) {
                                        var c = [];
                                        n.forEach(r, function(e) {
                                            var t = s.getModuleConfig(e);
                                            null === t ? c.push(e) : t.files && (c = c.concat(t.files))
                                        }),
                                        c.length > 0 && (r = {
                                            files: c
                                        })
                                    } else
                                        n.isObject(r) && r.hasOwnProperty("name") && r.name && (s.setModuleConfig(r),
                                        x.push(r.name));
                                    if (n.isDefined(r.files) && 0 !== r.files.length) {
                                        if (!n.isDefined(s.filesLoader))
                                            return v(new Error('Error: the module "' + r.name + '" is defined in external files (' + r.files + "), but no loader has been defined."));
                                        a.push(s.filesLoader(r, t).then(function() {
                                            return s._loadDependencies(r)
                                        }))
                                    }
                                }),
                                c.all(a)
                            },
                            inject: function(e) {
                                var t = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1]
                                  , r = !(arguments.length <= 2 || void 0 === arguments[2]) && arguments[2]
                                  , i = this
                                  , o = c.defer();
                                if (n.isDefined(e) && null !== e) {
                                    if (n.isArray(e)) {
                                        var a = [];
                                        return n.forEach(e, function(e) {
                                            a.push(i.inject(e, t, r))
                                        }),
                                        c.all(a)
                                    }
                                    i._addToLoadList(i._getModuleName(e), !0, r)
                                }
                                if (s.length > 0) {
                                    var u = s.slice();
                                    !function e(n) {
                                        x.push(n),
                                        D[n] = o.promise,
                                        i._loadDependencies(n, t).then(function() {
                                            try {
                                                f = [],
                                                O(L, x, t)
                                            } catch (e) {
                                                return i._$log.error(e.message),
                                                void o.reject(e)
                                            }
                                            s.length > 0 ? e(s.shift()) : o.resolve(u)
                                        }, function(e) {
                                            o.reject(e)
                                        })
                                    }(s.shift())
                                } else {
                                    if (t && t.name && D[t.name])
                                        return D[t.name];
                                    o.resolve()
                                }
                                return o.promise
                            },
                            getRequires: function(e) {
                                var t = [];
                                return n.forEach(e.requires, function(e) {
                                    -1 === i.indexOf(e) && t.push(e)
                                }),
                                t
                            },
                            _invokeQueue: _,
                            _registerInvokeList: S,
                            _register: O,
                            _addToLoadList: p,
                            _unregister: function(e) {
                                n.isDefined(e) && n.isArray(e) && n.forEach(e, function(e) {
                                    o[e] = void 0
                                })
                            }
                        }
                    }
                    ],
                    this._init(n.element(r.document))
                }
                ]);
                var h = n.bootstrap;
                n.bootstrap = function(e, t, r) {
                    return i = ["ng", "oc.lazyLoad"],
                    o = {},
                    a = [],
                    s = [],
                    c = [],
                    u = [],
                    l = n.noop,
                    d = {},
                    f = [],
                    n.forEach(t.slice(), function(e) {
                        p(e, !0, !0)
                    }),
                    h(e, t, r)
                }
                ;
                var p = function(e, t, r) {
                    (u.length > 0 || t) && n.isString(e) && -1 === s.indexOf(e) && (s.push(e),
                    r && c.push(e))
                }
                  , g = n.module;
                n.module = function(e, t, n) {
                    return p(e, !1, !0),
                    g(e, t, n)
                }
                ,
                e.exports === t && (e.exports = "oc.lazyLoad")
            }(n, window),
            function(e) {
                "use strict";
                e.module("oc.lazyLoad").directive("ocLazyLoad", ["$ocLazyLoad", "$compile", "$animate", "$parse", "$timeout", function(t, n, r, i, o) {
                    return {
                        restrict: "A",
                        terminal: !0,
                        priority: 1e3,
                        compile: function(o, a) {
                            var s = o[0].innerHTML;
                            return o.html(""),
                            function(o, a, c) {
                                var u = i(c.ocLazyLoad);
                                o.$watch(function() {
                                    return u(o) || c.ocLazyLoad
                                }, function(i) {
                                    e.isDefined(i) && t.load(i).then(function() {
                                        r.enter(s, a),
                                        n(a.contents())(o)
                                    })
                                }, !0)
                            }
                        }
                    }
                }
                ])
            }(n),
            function(e) {
                "use strict";
                e.module("oc.lazyLoad").config(["$provide", function(t) {
                    t.decorator("$ocLazyLoad", ["$delegate", "$q", "$window", "$interval", function(t, n, i, o) {
                        var a = !1
                          , s = i.document.getElementsByTagName("head")[0] || i.document.getElementsByTagName("body")[0];
                        return t.buildElement = function(c, u, l) {
                            var d, f, h = n.defer(), p = t._getFilesCache(), g = function(e) {
                                var t = (new Date).getTime();
                                return e.indexOf("?") >= 0 ? "&" === e.substring(0, e.length - 1) ? e + "_dc=" + t : e + "&_dc=" + t : e + "?_dc=" + t
                            };
                            switch (e.isUndefined(p.get(u)) && p.put(u, h.promise),
                            c) {
                            case "css":
                                (d = i.document.createElement("link")).type = "text/css",
                                d.rel = "stylesheet",
                                d.href = !1 === l.cache ? g(u) : u;
                                break;
                            case "js":
                                (d = i.document.createElement("script")).src = !1 === l.cache ? g(u) : u;
                                break;
                            default:
                                p.remove(u),
                                h.reject(new Error('Requested type "' + c + '" is not known. Could not inject "' + u + '"'))
                            }
                            d.onload = d.onreadystatechange = function(e) {
                                d.readyState && !/^c|loade/.test(d.readyState) || f || (d.onload = d.onreadystatechange = null,
                                f = 1,
                                t._broadcast("ocLazyLoad.fileLoaded", u),
                                h.resolve(d))
                            }
                            ,
                            d.onerror = function() {
                                p.remove(u),
                                h.reject(new Error("Unable to load " + u))
                            }
                            ,
                            d.async = l.serie ? 0 : 1;
                            var v = s.lastChild;
                            if (l.insertBefore) {
                                var m = e.element(e.isDefined(r) ? l.insertBefore : document.querySelector(l.insertBefore));
                                m && m.length > 0 && (v = m[0])
                            }
                            if (v.parentNode.insertBefore(d, v),
                            "css" == c) {
                                var y = i.navigator.userAgent.toLowerCase();
                                if (y.indexOf("phantomjs/1.9") > -1)
                                    a = !0;
                                else if (/iP(hone|od|ad)/.test(i.navigator.platform)) {
                                    var E = i.navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/)
                                      , L = parseFloat([parseInt(E[1], 10), parseInt(E[2], 10), parseInt(E[3] || 0, 10)].join("."));
                                    a = L < 6
                                } else if (y.indexOf("android") > -1) {
                                    var T = parseFloat(y.slice(y.indexOf("android") + 8));
                                    a = T < 4.4
                                } else if (y.indexOf("safari") > -1) {
                                    var M = y.match(/version\/([\.\d]+)/i);
                                    a = M && M[1] && parseFloat(M[1]) < 6
                                }
                                if (a)
                                    var x = 1e3
                                      , D = o(function() {
                                        try {
                                            d.sheet.cssRules,
                                            o.cancel(D),
                                            d.onload()
                                        } catch (e) {
                                            --x <= 0 && d.onerror()
                                        }
                                    }, 20)
                            }
                            return h.promise
                        }
                        ,
                        t
                    }
                    ])
                }
                ])
            }(n),
            function(e) {
                "use strict";
                e.module("oc.lazyLoad").config(["$provide", function(t) {
                    t.decorator("$ocLazyLoad", ["$delegate", "$q", function(t, n) {
                        return t.filesLoader = function(r) {
                            var i = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1]
                              , o = []
                              , a = []
                              , s = []
                              , c = []
                              , u = null
                              , l = t._getFilesCache();
                            t.toggleWatch(!0),
                            e.extend(i, r);
                            var d = function(n) {
                                var r, d = null;
                                if (e.isObject(n) && (d = n.type,
                                n = n.path),
                                u = l.get(n),
                                e.isUndefined(u) || !1 === i.cache) {
                                    if (null !== (r = /^(css|less|html|htm|js)?(?=!)/.exec(n)) && (d = r[1],
                                    n = n.substr(r[1].length + 1, n.length)),
                                    !d)
                                        if (null !== (r = /[.](css|less|html|htm|js)?((\?|#).*)?$/.exec(n)))
                                            d = r[1];
                                        else {
                                            if (t.jsLoader.hasOwnProperty("ocLazyLoadLoader") || !t.jsLoader.hasOwnProperty("requirejs"))
                                                return void t._$log.error("File type could not be determined. " + n);
                                            d = "js"
                                        }
                                    "css" !== d && "less" !== d || -1 !== o.indexOf(n) ? "html" !== d && "htm" !== d || -1 !== a.indexOf(n) ? "js" === d || -1 === s.indexOf(n) ? s.push(n) : t._$log.error("File type is not valid. " + n) : a.push(n) : o.push(n)
                                } else
                                    u && c.push(u)
                            };
                            if (i.serie ? d(i.files.shift()) : e.forEach(i.files, function(e) {
                                d(e)
                            }),
                            o.length > 0) {
                                var f = n.defer();
                                t.cssLoader(o, function(n) {
                                    e.isDefined(n) && t.cssLoader.hasOwnProperty("ocLazyLoadLoader") ? (t._$log.error(n),
                                    f.reject(n)) : f.resolve()
                                }, i),
                                c.push(f.promise)
                            }
                            if (a.length > 0) {
                                var h = n.defer();
                                t.templatesLoader(a, function(n) {
                                    e.isDefined(n) && t.templatesLoader.hasOwnProperty("ocLazyLoadLoader") ? (t._$log.error(n),
                                    h.reject(n)) : h.resolve()
                                }, i),
                                c.push(h.promise)
                            }
                            if (s.length > 0) {
                                var p = n.defer();
                                t.jsLoader(s, function(n) {
                                    e.isDefined(n) && (t.jsLoader.hasOwnProperty("ocLazyLoadLoader") || t.jsLoader.hasOwnProperty("requirejs")) ? (t._$log.error(n),
                                    p.reject(n)) : p.resolve()
                                }, i),
                                c.push(p.promise)
                            }
                            if (0 === c.length) {
                                var g = n.defer()
                                  , v = "Error: no file to load has been found, if you're trying to load an existing module you should use the 'inject' method instead of 'load'.";
                                return t._$log.error(v),
                                g.reject(v),
                                g.promise
                            }
                            return i.serie && i.files.length > 0 ? n.all(c).then(function() {
                                return t.filesLoader(r, i)
                            }) : n.all(c).finally(function(e) {
                                return t.toggleWatch(!1),
                                e
                            })
                        }
                        ,
                        t.load = function(r) {
                            var i, o = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1], a = this, s = null, c = [], u = n.defer(), l = e.copy(r), d = e.copy(o);
                            if (e.isArray(l))
                                return e.forEach(l, function(e) {
                                    c.push(a.load(e, d))
                                }),
                                n.all(c).then(function(e) {
                                    u.resolve(e)
                                }, function(e) {
                                    u.reject(e)
                                }),
                                u.promise;
                            if (e.isString(l) ? (s = a.getModuleConfig(l)) || (s = {
                                files: [l]
                            }) : e.isObject(l) && (s = e.isDefined(l.path) && e.isDefined(l.type) ? {
                                files: [l]
                            } : a.setModuleConfig(l)),
                            null === s)
                                return i = 'Module "' + (a._getModuleName(l) || "unknown") + '" is not configured, cannot load.',
                                t._$log.error(i),
                                u.reject(new Error(i)),
                                u.promise;
                            e.isDefined(s.template) && (e.isUndefined(s.files) && (s.files = []),
                            e.isString(s.template) ? s.files.push(s.template) : e.isArray(s.template) && s.files.concat(s.template));
                            var f = e.extend({}, d, s);
                            return e.isUndefined(s.files) && e.isDefined(s.name) && t.moduleExists(s.name) ? t.inject(s.name, f, !0) : (t.filesLoader(s, f).then(function() {
                                t.inject(null, f).then(function(e) {
                                    u.resolve(e)
                                }, function(e) {
                                    u.reject(e)
                                })
                            }, function(e) {
                                u.reject(e)
                            }),
                            u.promise)
                        }
                        ,
                        t
                    }
                    ])
                }
                ])
            }(n),
            function(e) {
                "use strict";
                e.module("oc.lazyLoad").config(["$provide", function(t) {
                    t.decorator("$ocLazyLoad", ["$delegate", "$q", function(t, n) {
                        return t.cssLoader = function(r, i, o) {
                            var a = [];
                            e.forEach(r, function(e) {
                                a.push(t.buildElement("css", e, o))
                            }),
                            n.all(a).then(function() {
                                i()
                            }, function(e) {
                                i(e)
                            })
                        }
                        ,
                        t.cssLoader.ocLazyLoadLoader = !0,
                        t
                    }
                    ])
                }
                ])
            }(n),
            function(e) {
                "use strict";
                e.module("oc.lazyLoad").config(["$provide", function(t) {
                    t.decorator("$ocLazyLoad", ["$delegate", "$q", function(t, n) {
                        return t.jsLoader = function(r, i, o) {
                            var a = [];
                            e.forEach(r, function(e) {
                                a.push(t.buildElement("js", e, o))
                            }),
                            n.all(a).then(function() {
                                i()
                            }, function(e) {
                                i(e)
                            })
                        }
                        ,
                        t.jsLoader.ocLazyLoadLoader = !0,
                        t
                    }
                    ])
                }
                ])
            }(n),
            function(e) {
                "use strict";
                e.module("oc.lazyLoad").config(["$provide", function(t) {
                    t.decorator("$ocLazyLoad", ["$delegate", "$templateCache", "$q", "$http", function(t, n, r, i) {
                        return t.templatesLoader = function(o, a, s) {
                            var c = []
                              , u = t._getFilesCache();
                            return e.forEach(o, function(t) {
                                var o = r.defer();
                                c.push(o.promise),
                                i.get(t, s).then(function(r) {
                                    var i = r.data;
                                    e.isString(i) && i.length > 0 && e.forEach(e.element(i), function(e) {
                                        "SCRIPT" === e.nodeName && "text/ng-template" === e.type && n.put(e.id, e.innerHTML)
                                    }),
                                    e.isUndefined(u.get(t)) && u.put(t, !0),
                                    o.resolve()
                                }).catch(function(e) {
                                    o.reject(new Error('Unable to load template file "' + t + '": ' + e.data))
                                })
                            }),
                            r.all(c).then(function() {
                                a()
                            }, function(e) {
                                a(e)
                            })
                        }
                        ,
                        t.templatesLoader.ocLazyLoadLoader = !0,
                        t
                    }
                    ])
                }
                ])
            }(n),
            Array.prototype.indexOf || (Array.prototype.indexOf = function(e, t) {
                var n;
                if (null == this)
                    throw new TypeError('"this" is null or not defined');
                var r = Object(this)
                  , i = r.length >>> 0;
                if (0 === i)
                    return -1;
                var o = +t || 0;
                if (Math.abs(o) === 1 / 0 && (o = 0),
                o >= i)
                    return -1;
                for (n = Math.max(o >= 0 ? o : i - Math.abs(o), 0); n < i; ) {
                    if (n in r && r[n] === e)
                        return n;
                    n++
                }
                return -1
            }
            )
        }
        ).call(this, n(1), n(15))
    },
    255: function(e, t, n) {
        var r = n(256);
        e.exports = new r
    },
    256: function(e, t, n) {
        var r = n(257)
          , i = n(128)
          , o = i.each
          , a = i.isFunction
          , s = i.isArray;
        function c() {
            if (!window.matchMedia)
                throw new Error("matchMedia not present, legacy browsers require a polyfill");
            this.queries = {},
            this.browserIsIncapable = !window.matchMedia("only all").matches
        }
        c.prototype = {
            constructor: c,
            register: function(e, t, n) {
                var i = this.queries
                  , c = n && this.browserIsIncapable;
                return i[e] || (i[e] = new r(e,c)),
                a(t) && (t = {
                    match: t
                }),
                s(t) || (t = [t]),
                o(t, function(t) {
                    a(t) && (t = {
                        match: t
                    }),
                    i[e].addHandler(t)
                }),
                this
            },
            unregister: function(e, t) {
                var n = this.queries[e];
                return n && (t ? n.removeHandler(t) : (n.clear(),
                delete this.queries[e])),
                this
            }
        },
        e.exports = c
    },
    257: function(e, t, n) {
        var r = n(258)
          , i = n(128).each;
        function o(e, t) {
            this.query = e,
            this.isUnconditional = t,
            this.handlers = [],
            this.mql = window.matchMedia(e);
            var n = this;
            this.listener = function(e) {
                n.mql = e.currentTarget || e,
                n.assess()
            }
            ,
            this.mql.addListener(this.listener)
        }
        o.prototype = {
            constuctor: o,
            addHandler: function(e) {
                var t = new r(e);
                this.handlers.push(t),
                this.matches() && t.on()
            },
            removeHandler: function(e) {
                var t = this.handlers;
                i(t, function(n, r) {
                    if (n.equals(e))
                        return n.destroy(),
                        !t.splice(r, 1)
                })
            },
            matches: function() {
                return this.mql.matches || this.isUnconditional
            },
            clear: function() {
                i(this.handlers, function(e) {
                    e.destroy()
                }),
                this.mql.removeListener(this.listener),
                this.handlers.length = 0
            },
            assess: function() {
                var e = this.matches() ? "on" : "off";
                i(this.handlers, function(t) {
                    t[e]()
                })
            }
        },
        e.exports = o
    },
    258: function(e, t) {
        function n(e) {
            this.options = e,
            !e.deferSetup && this.setup()
        }
        n.prototype = {
            constructor: n,
            setup: function() {
                this.options.setup && this.options.setup(),
                this.initialised = !0
            },
            on: function() {
                !this.initialised && this.setup(),
                this.options.match && this.options.match()
            },
            off: function() {
                this.options.unmatch && this.options.unmatch()
            },
            destroy: function() {
                this.options.destroy ? this.options.destroy() : this.off()
            },
            equals: function(e) {
                return this.options === e || this.options.match === e
            }
        },
        e.exports = n
    },
    335: function(e, t, n) {
        var r;
        /*! Hammer.JS - v1.1.3 - 2014-05-20
 * http://eightmedia.github.io/hammer.js
 *
 * Copyright (c) 2014 Jorik Tangelder <j.tangelder@gmail.com>;
 * Licensed under the MIT license */
        /*! Hammer.JS - v1.1.3 - 2014-05-20
 * http://eightmedia.github.io/hammer.js
 *
 * Copyright (c) 2014 Jorik Tangelder <j.tangelder@gmail.com>;
 * Licensed under the MIT license */
        !function(i, o) {
            "use strict";
            var a = function e(t, n) {
                return new e.Instance(t,n || {})
            };
            a.VERSION = "1.1.3",
            a.defaults = {
                behavior: {
                    userSelect: "none",
                    touchAction: "pan-y",
                    touchCallout: "none",
                    contentZooming: "none",
                    userDrag: "none",
                    tapHighlightColor: "rgba(0,0,0,0)"
                }
            },
            a.DOCUMENT = document,
            a.HAS_POINTEREVENTS = navigator.pointerEnabled || navigator.msPointerEnabled,
            a.HAS_TOUCHEVENTS = "ontouchstart"in i,
            a.IS_MOBILE = /mobile|tablet|ip(ad|hone|od)|android|silk/i.test(navigator.userAgent),
            a.NO_MOUSEEVENTS = a.HAS_TOUCHEVENTS && a.IS_MOBILE || a.HAS_POINTEREVENTS,
            a.CALCULATE_INTERVAL = 25;
            var s = {}
              , c = a.DIRECTION_DOWN = "down"
              , u = a.DIRECTION_LEFT = "left"
              , l = a.DIRECTION_UP = "up"
              , d = a.DIRECTION_RIGHT = "right"
              , f = a.POINTER_MOUSE = "mouse"
              , h = a.POINTER_TOUCH = "touch"
              , p = a.POINTER_PEN = "pen"
              , g = a.EVENT_START = "start"
              , v = a.EVENT_MOVE = "move"
              , m = a.EVENT_END = "end"
              , y = a.EVENT_RELEASE = "release"
              , E = a.EVENT_TOUCH = "touch";
            a.READY = !1,
            a.plugins = a.plugins || {},
            a.gestures = a.gestures || {};
            var L = a.utils = {
                extend: function(e, t, n) {
                    for (var r in t)
                        !t.hasOwnProperty(r) || void 0 !== e[r] && n || (e[r] = t[r]);
                    return e
                },
                on: function(e, t, n) {
                    e.addEventListener(t, n, !1)
                },
                off: function(e, t, n) {
                    e.removeEventListener(t, n, !1)
                },
                each: function(e, t, n) {
                    var r, i;
                    if ("forEach"in e)
                        e.forEach(t, n);
                    else if (void 0 !== e.length) {
                        for (r = 0,
                        i = e.length; r < i; r++)
                            if (!1 === t.call(n, e[r], r, e))
                                return
                    } else
                        for (r in e)
                            if (e.hasOwnProperty(r) && !1 === t.call(n, e[r], r, e))
                                return
                },
                inStr: function(e, t) {
                    return e.indexOf(t) > -1
                },
                inArray: function(e, t) {
                    if (e.indexOf) {
                        var n = e.indexOf(t);
                        return -1 !== n && n
                    }
                    for (var r = 0, i = e.length; r < i; r++)
                        if (e[r] === t)
                            return r;
                    return !1
                },
                toArray: function(e) {
                    return Array.prototype.slice.call(e, 0)
                },
                hasParent: function(e, t) {
                    for (; e; ) {
                        if (e == t)
                            return !0;
                        e = e.parentNode
                    }
                    return !1
                },
                getCenter: function(e) {
                    var t = []
                      , n = []
                      , r = []
                      , i = []
                      , o = Math.min
                      , a = Math.max;
                    return 1 === e.length ? {
                        pageX: e[0].pageX,
                        pageY: e[0].pageY,
                        clientX: e[0].clientX,
                        clientY: e[0].clientY
                    } : (L.each(e, function(e) {
                        t.push(e.pageX),
                        n.push(e.pageY),
                        r.push(e.clientX),
                        i.push(e.clientY)
                    }),
                    {
                        pageX: (o.apply(Math, t) + a.apply(Math, t)) / 2,
                        pageY: (o.apply(Math, n) + a.apply(Math, n)) / 2,
                        clientX: (o.apply(Math, r) + a.apply(Math, r)) / 2,
                        clientY: (o.apply(Math, i) + a.apply(Math, i)) / 2
                    })
                },
                getVelocity: function(e, t, n) {
                    return {
                        x: Math.abs(t / e) || 0,
                        y: Math.abs(n / e) || 0
                    }
                },
                getAngle: function(e, t) {
                    var n = t.clientX - e.clientX
                      , r = t.clientY - e.clientY;
                    return 180 * Math.atan2(r, n) / Math.PI
                },
                getDirection: function(e, t) {
                    return Math.abs(e.clientX - t.clientX) >= Math.abs(e.clientY - t.clientY) ? e.clientX - t.clientX > 0 ? u : d : e.clientY - t.clientY > 0 ? l : c
                },
                getDistance: function(e, t) {
                    var n = t.clientX - e.clientX
                      , r = t.clientY - e.clientY;
                    return Math.sqrt(n * n + r * r)
                },
                getScale: function(e, t) {
                    return e.length >= 2 && t.length >= 2 ? this.getDistance(t[0], t[1]) / this.getDistance(e[0], e[1]) : 1
                },
                getRotation: function(e, t) {
                    return e.length >= 2 && t.length >= 2 ? this.getAngle(t[1], t[0]) - this.getAngle(e[1], e[0]) : 0
                },
                isVertical: function(e) {
                    return e == l || e == c
                },
                setPrefixedCss: function(e, t, n, r) {
                    var i = ["", "Webkit", "Moz", "O", "ms"];
                    t = L.toCamelCase(t);
                    for (var o = 0; o < i.length; o++) {
                        var a = t;
                        if (i[o] && (a = i[o] + a.slice(0, 1).toUpperCase() + a.slice(1)),
                        a in e.style) {
                            e.style[a] = (null == r || r) && n || "";
                            break
                        }
                    }
                },
                toggleBehavior: function(e, t, n) {
                    if (t && e && e.style) {
                        L.each(t, function(t, r) {
                            L.setPrefixedCss(e, r, t, n)
                        });
                        var r = n && function() {
                            return !1
                        }
                        ;
                        "none" == t.userSelect && (e.onselectstart = r),
                        "none" == t.userDrag && (e.ondragstart = r)
                    }
                },
                toCamelCase: function(e) {
                    return e.replace(/[_-]([a-z])/g, function(e) {
                        return e[1].toUpperCase()
                    })
                }
            }
              , T = a.event = {
                preventMouseEvents: !1,
                started: !1,
                shouldDetect: !1,
                on: function(e, t, n, r) {
                    var i = t.split(" ");
                    L.each(i, function(t) {
                        L.on(e, t, n),
                        r && r(t)
                    })
                },
                off: function(e, t, n, r) {
                    var i = t.split(" ");
                    L.each(i, function(t) {
                        L.off(e, t, n),
                        r && r(t)
                    })
                },
                onTouch: function(e, t, n) {
                    var r = this
                      , i = function(i) {
                        var o, s = i.type.toLowerCase(), c = a.HAS_POINTEREVENTS, u = L.inStr(s, "mouse");
                        u && r.preventMouseEvents || (u && t == g && 0 === i.button ? (r.preventMouseEvents = !1,
                        r.shouldDetect = !0) : c && t == g ? r.shouldDetect = 1 === i.buttons || M.matchType(h, i) : u || t != g || (r.preventMouseEvents = !0,
                        r.shouldDetect = !0),
                        c && t != m && M.updatePointer(t, i),
                        r.shouldDetect && (o = r.doDetect.call(r, i, t, e, n)),
                        o == m && (r.preventMouseEvents = !1,
                        r.shouldDetect = !1,
                        M.reset()),
                        c && t == m && M.updatePointer(t, i))
                    };
                    return this.on(e, s[t], i),
                    i
                },
                doDetect: function(e, t, n, r) {
                    var i = this.getTouchList(e, t)
                      , o = i.length
                      , a = t
                      , s = i.trigger
                      , c = o;
                    t == g ? s = E : t == m && (s = y,
                    c = i.length - (e.changedTouches ? e.changedTouches.length : 1)),
                    c > 0 && this.started && (a = v),
                    this.started = !0;
                    var u = this.collectEventData(n, a, i, e);
                    return t != m && r.call(x, u),
                    s && (u.changedLength = c,
                    u.eventType = s,
                    r.call(x, u),
                    u.eventType = a,
                    delete u.changedLength),
                    a == m && (r.call(x, u),
                    this.started = !1),
                    a
                },
                determineEventTypes: function() {
                    var e;
                    return e = a.HAS_POINTEREVENTS ? i.PointerEvent ? ["pointerdown", "pointermove", "pointerup pointercancel lostpointercapture"] : ["MSPointerDown", "MSPointerMove", "MSPointerUp MSPointerCancel MSLostPointerCapture"] : a.NO_MOUSEEVENTS ? ["touchstart", "touchmove", "touchend touchcancel"] : ["touchstart mousedown", "touchmove mousemove", "touchend touchcancel mouseup"],
                    s[g] = e[0],
                    s[v] = e[1],
                    s[m] = e[2],
                    s
                },
                getTouchList: function(e, t) {
                    if (a.HAS_POINTEREVENTS)
                        return M.getTouchList();
                    if (e.touches) {
                        if (t == v)
                            return e.touches;
                        var n = []
                          , r = [].concat(L.toArray(e.touches), L.toArray(e.changedTouches))
                          , i = [];
                        return L.each(r, function(e) {
                            !1 === L.inArray(n, e.identifier) && i.push(e),
                            n.push(e.identifier)
                        }),
                        i
                    }
                    return e.identifier = 1,
                    [e]
                },
                collectEventData: function(e, t, n, r) {
                    var i = h;
                    return L.inStr(r.type, "mouse") || M.matchType(f, r) ? i = f : M.matchType(p, r) && (i = p),
                    {
                        center: L.getCenter(n),
                        timeStamp: Date.now(),
                        target: r.target,
                        touches: n,
                        eventType: t,
                        pointerType: i,
                        srcEvent: r,
                        preventDefault: function() {
                            var e = this.srcEvent;
                            e.preventManipulation && e.preventManipulation(),
                            e.preventDefault && e.preventDefault()
                        },
                        stopPropagation: function() {
                            this.srcEvent.stopPropagation()
                        },
                        stopDetect: function() {
                            return x.stopDetect()
                        }
                    }
                }
            }
              , M = a.PointerEvent = {
                pointers: {},
                getTouchList: function() {
                    var e = [];
                    return L.each(this.pointers, function(t) {
                        e.push(t)
                    }),
                    e
                },
                updatePointer: function(e, t) {
                    e == m || e != m && 1 !== t.buttons ? delete this.pointers[t.pointerId] : (t.identifier = t.pointerId,
                    this.pointers[t.pointerId] = t)
                },
                matchType: function(e, t) {
                    if (!t.pointerType)
                        return !1;
                    var n = t.pointerType
                      , r = {};
                    return r[f] = n === (t.MSPOINTER_TYPE_MOUSE || f),
                    r[h] = n === (t.MSPOINTER_TYPE_TOUCH || h),
                    r[p] = n === (t.MSPOINTER_TYPE_PEN || p),
                    r[e]
                },
                reset: function() {
                    this.pointers = {}
                }
            }
              , x = a.detection = {
                gestures: [],
                current: null,
                previous: null,
                stopped: !1,
                startDetect: function(e, t) {
                    this.current || (this.stopped = !1,
                    this.current = {
                        inst: e,
                        startEvent: L.extend({}, t),
                        lastEvent: !1,
                        lastCalcEvent: !1,
                        futureCalcEvent: !1,
                        lastCalcData: {},
                        name: ""
                    },
                    this.detect(t))
                },
                detect: function(e) {
                    if (this.current && !this.stopped) {
                        e = this.extendEventData(e);
                        var t = this.current.inst
                          , n = t.options;
                        return L.each(this.gestures, function(r) {
                            !this.stopped && t.enabled && n[r.name] && r.handler.call(r, e, t)
                        }, this),
                        this.current && (this.current.lastEvent = e),
                        e.eventType == m && this.stopDetect(),
                        e
                    }
                },
                stopDetect: function() {
                    this.previous = L.extend({}, this.current),
                    this.current = null,
                    this.stopped = !0
                },
                getCalculatedData: function(e, t, n, r, i) {
                    var o = this.current
                      , s = !1
                      , c = o.lastCalcEvent
                      , u = o.lastCalcData;
                    c && e.timeStamp - c.timeStamp > a.CALCULATE_INTERVAL && (t = c.center,
                    n = e.timeStamp - c.timeStamp,
                    r = e.center.clientX - c.center.clientX,
                    i = e.center.clientY - c.center.clientY,
                    s = !0),
                    e.eventType != E && e.eventType != y || (o.futureCalcEvent = e),
                    o.lastCalcEvent && !s || (u.velocity = L.getVelocity(n, r, i),
                    u.angle = L.getAngle(t, e.center),
                    u.direction = L.getDirection(t, e.center),
                    o.lastCalcEvent = o.futureCalcEvent || e,
                    o.futureCalcEvent = e),
                    e.velocityX = u.velocity.x,
                    e.velocityY = u.velocity.y,
                    e.interimAngle = u.angle,
                    e.interimDirection = u.direction
                },
                extendEventData: function(e) {
                    var t = this.current
                      , n = t.startEvent
                      , r = t.lastEvent || n;
                    e.eventType != E && e.eventType != y || (n.touches = [],
                    L.each(e.touches, function(e) {
                        n.touches.push({
                            clientX: e.clientX,
                            clientY: e.clientY
                        })
                    }));
                    var i = e.timeStamp - n.timeStamp
                      , o = e.center.clientX - n.center.clientX
                      , a = e.center.clientY - n.center.clientY;
                    return this.getCalculatedData(e, r.center, i, o, a),
                    L.extend(e, {
                        startEvent: n,
                        deltaTime: i,
                        deltaX: o,
                        deltaY: a,
                        distance: L.getDistance(n.center, e.center),
                        angle: L.getAngle(n.center, e.center),
                        direction: L.getDirection(n.center, e.center),
                        scale: L.getScale(n.touches, e.touches),
                        rotation: L.getRotation(n.touches, e.touches)
                    }),
                    e
                },
                register: function(e) {
                    var t = e.defaults || {};
                    return void 0 === t[e.name] && (t[e.name] = !0),
                    L.extend(a.defaults, t, !0),
                    e.index = e.index || 1e3,
                    this.gestures.push(e),
                    this.gestures.sort(function(e, t) {
                        return e.index < t.index ? -1 : e.index > t.index ? 1 : 0
                    }),
                    this.gestures
                }
            };
            a.Instance = function(e, t) {
                var n = this;
                a.READY || (T.determineEventTypes(),
                L.each(a.gestures, function(e) {
                    x.register(e)
                }),
                T.onTouch(a.DOCUMENT, v, x.detect),
                T.onTouch(a.DOCUMENT, m, x.detect),
                a.READY = !0),
                this.element = e,
                this.enabled = !0,
                L.each(t, function(e, n) {
                    delete t[n],
                    t[L.toCamelCase(n)] = e
                }),
                this.options = L.extend(L.extend({}, a.defaults), t || {}),
                this.options.behavior && L.toggleBehavior(this.element, this.options.behavior, !0),
                this.eventStartHandler = T.onTouch(e, g, function(e) {
                    n.enabled && e.eventType == g ? x.startDetect(n, e) : e.eventType == E && x.detect(e)
                }),
                this.eventHandlers = []
            }
            ,
            a.Instance.prototype = {
                on: function(e, t) {
                    var n = this;
                    return T.on(n.element, e, t, function(e) {
                        n.eventHandlers.push({
                            gesture: e,
                            handler: t
                        })
                    }),
                    n
                },
                off: function(e, t) {
                    var n = this;
                    return T.off(n.element, e, t, function(e) {
                        var r = L.inArray({
                            gesture: e,
                            handler: t
                        });
                        !1 !== r && n.eventHandlers.splice(r, 1)
                    }),
                    n
                },
                trigger: function(e, t) {
                    t || (t = {});
                    var n = a.DOCUMENT.createEvent("Event");
                    n.initEvent(e, !0, !0),
                    n.gesture = t;
                    var r = this.element;
                    return L.hasParent(t.target, r) && (r = t.target),
                    r.dispatchEvent(n),
                    this
                },
                enable: function(e) {
                    return this.enabled = e,
                    this
                },
                dispose: function() {
                    var e, t;
                    for (L.toggleBehavior(this.element, this.options.behavior, !1),
                    e = -1; t = this.eventHandlers[++e]; )
                        L.off(this.element, t.gesture, t.handler);
                    return this.eventHandlers = [],
                    T.off(this.element, s[g], this.eventStartHandler),
                    null
                }
            },
            function(e) {
                var t = !1;
                a.gestures.Drag = {
                    name: e,
                    index: 50,
                    handler: function(n, r) {
                        var i = x.current;
                        if (!(r.options.dragMaxTouches > 0 && n.touches.length > r.options.dragMaxTouches))
                            switch (n.eventType) {
                            case g:
                                t = !1;
                                break;
                            case v:
                                if (n.distance < r.options.dragMinDistance && i.name != e)
                                    return;
                                var o = i.startEvent.center;
                                if (i.name != e && (i.name = e,
                                r.options.dragDistanceCorrection && n.distance > 0)) {
                                    var a = Math.abs(r.options.dragMinDistance / n.distance);
                                    o.pageX += n.deltaX * a,
                                    o.pageY += n.deltaY * a,
                                    o.clientX += n.deltaX * a,
                                    o.clientY += n.deltaY * a,
                                    n = x.extendEventData(n)
                                }
                                (i.lastEvent.dragLockToAxis || r.options.dragLockToAxis && r.options.dragLockMinDistance <= n.distance) && (n.dragLockToAxis = !0);
                                var s = i.lastEvent.direction;
                                n.dragLockToAxis && s !== n.direction && (L.isVertical(s) ? n.direction = n.deltaY < 0 ? l : c : n.direction = n.deltaX < 0 ? u : d),
                                t || (r.trigger(e + "start", n),
                                t = !0),
                                r.trigger(e, n),
                                r.trigger(e + n.direction, n);
                                var f = L.isVertical(n.direction);
                                (r.options.dragBlockVertical && f || r.options.dragBlockHorizontal && !f) && n.preventDefault();
                                break;
                            case y:
                                t && n.changedLength <= r.options.dragMaxTouches && (r.trigger(e + "end", n),
                                t = !1);
                                break;
                            case m:
                                t = !1
                            }
                    },
                    defaults: {
                        dragMinDistance: 10,
                        dragDistanceCorrection: !0,
                        dragMaxTouches: 1,
                        dragBlockHorizontal: !1,
                        dragBlockVertical: !1,
                        dragLockToAxis: !1,
                        dragLockMinDistance: 25
                    }
                }
            }("drag"),
            a.gestures.Gesture = {
                name: "gesture",
                index: 1337,
                handler: function(e, t) {
                    t.trigger(this.name, e)
                }
            },
            function(e) {
                var t;
                a.gestures.Hold = {
                    name: e,
                    index: 10,
                    defaults: {
                        holdTimeout: 500,
                        holdThreshold: 2
                    },
                    handler: function(n, r) {
                        var i = r.options
                          , o = x.current;
                        switch (n.eventType) {
                        case g:
                            clearTimeout(t),
                            o.name = e,
                            t = setTimeout(function() {
                                o && o.name == e && r.trigger(e, n)
                            }, i.holdTimeout);
                            break;
                        case v:
                            n.distance > i.holdThreshold && clearTimeout(t);
                            break;
                        case y:
                            clearTimeout(t)
                        }
                    }
                }
            }("hold"),
            a.gestures.Release = {
                name: "release",
                index: 1 / 0,
                handler: function(e, t) {
                    e.eventType == y && t.trigger(this.name, e)
                }
            },
            a.gestures.Swipe = {
                name: "swipe",
                index: 40,
                defaults: {
                    swipeMinTouches: 1,
                    swipeMaxTouches: 1,
                    swipeVelocityX: .6,
                    swipeVelocityY: .6
                },
                handler: function(e, t) {
                    if (e.eventType == y) {
                        var n = e.touches.length
                          , r = t.options;
                        if (n < r.swipeMinTouches || n > r.swipeMaxTouches)
                            return;
                        (e.velocityX > r.swipeVelocityX || e.velocityY > r.swipeVelocityY) && (t.trigger(this.name, e),
                        t.trigger(this.name + e.direction, e))
                    }
                }
            },
            function(e) {
                var t = !1;
                a.gestures.Tap = {
                    name: e,
                    index: 100,
                    handler: function(n, r) {
                        var i, o, a = r.options, s = x.current, c = x.previous;
                        switch (n.eventType) {
                        case g:
                            t = !1;
                            break;
                        case v:
                            t = t || n.distance > a.tapMaxDistance;
                            break;
                        case m:
                            !L.inStr(n.srcEvent.type, "cancel") && n.deltaTime < a.tapMaxTime && !t && (i = c && c.lastEvent && n.timeStamp - c.lastEvent.timeStamp,
                            o = !1,
                            c && c.name == e && i && i < a.doubleTapInterval && n.distance < a.doubleTapDistance && (r.trigger("doubletap", n),
                            o = !0),
                            o && !a.tapAlways || (s.name = e,
                            r.trigger(s.name, n)))
                        }
                    },
                    defaults: {
                        tapMaxTime: 250,
                        tapMaxDistance: 10,
                        tapAlways: !0,
                        doubleTapDistance: 20,
                        doubleTapInterval: 300
                    }
                }
            }("tap"),
            a.gestures.Touch = {
                name: "touch",
                index: -1 / 0,
                defaults: {
                    preventDefault: !1,
                    preventMouse: !1
                },
                handler: function(e, t) {
                    t.options.preventMouse && e.pointerType == f ? e.stopDetect() : (t.options.preventDefault && e.preventDefault(),
                    e.eventType == E && t.trigger("touch", e))
                }
            },
            function(e) {
                var t = !1;
                a.gestures.Transform = {
                    name: e,
                    index: 45,
                    defaults: {
                        transformMinScale: .01,
                        transformMinRotation: 1
                    },
                    handler: function(n, r) {
                        switch (n.eventType) {
                        case g:
                            t = !1;
                            break;
                        case v:
                            if (n.touches.length < 2)
                                return;
                            var i = Math.abs(1 - n.scale)
                              , o = Math.abs(n.rotation);
                            if (i < r.options.transformMinScale && o < r.options.transformMinRotation)
                                return;
                            x.current.name = e,
                            t || (r.trigger(e + "start", n),
                            t = !0),
                            r.trigger(e, n),
                            o > r.options.transformMinRotation && r.trigger("rotate", n),
                            i > r.options.transformMinScale && (r.trigger("pinch", n),
                            r.trigger("pinch" + (n.scale < 1 ? "in" : "out"), n));
                            break;
                        case y:
                            t && n.changedLength < 2 && (r.trigger(e + "end", n),
                            t = !1)
                        }
                    }
                }
            }("transform"),
            void 0 === (r = function() {
                return a
            }
            .call(t, n, t, e)) || (e.exports = r)
        }(window)
    }
}]);
