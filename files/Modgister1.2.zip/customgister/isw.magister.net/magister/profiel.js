(window.webpackJsonp = window.webpackJsonp || []).push([[18], {
    114: function(e, n, t) {
        "use strict";
        (function(e) {
            t.d(n, "a", function() {
                return r
            });
            var i = t(0)
              , r = function() {
                function n(e, n, t) {
                    this.$routeParams = e,
                    this.profielService = n,
                    this.collectionResource = t
                }
                return n.prototype.getOpleidingGegevens = function(e) {
                    return this.profielService.getOpleiding(e).then(function(e) {
                        return {
                            Studie: e.Studie,
                            Klas: e.Klas,
                            ExamenNr: e.ExamenNr,
                            StamNr: e.StamNr,
                            Profielen: e.Profielen
                        }
                    })
                }
                ,
                n.prototype.getAdresGegevens = function(e) {
                    return this.profielService.getWoonGegevens(e).then(function(e) {
                        var n = Object(i.h)("{0} {1} {2}", e.Straatnaam, e.Huisnummer, e.Toevoeging).trim()
                          , t = Object(i.d)(e.Woonplaats.toLowerCase());
                        return {
                            adres: n,
                            postcode: e.Postcode,
                            woonPlaats: t
                        }
                    })
                }
                ,
                n.prototype.getAdresGegevensApi2 = function(n) {
                    var t = [{
                        rel: "self",
                        href: "api/personen/" + n + "/adressen"
                    }];
                    return this.collectionResource.get(t, "self").then(function(n) {
                        var t = e.findWhere(n.items, {
                            type: "Post"
                        });
                        t || (t = e.first(n.items));
                        var r = Object(i.h)("{0} {1} {2}", t.straat, t.huisnummer, t.toevoeging).trim()
                          , o = Object(i.d)(t.plaats.toLowerCase());
                        return {
                            adres: r,
                            postcode: t.postcode,
                            woonPlaats: o
                        }
                    })
                }
                ,
                n.prototype.getPersoonsGegevens = function(e, n) {
                    void 0 === n && (n = !1);
                    var t = Object(i.h)("{0} {1} {2}", n ? e.initials : e.firstName, e.prefixes ? e.prefixes : e.surname, e.prefixes ? e.surname : "").trim()
                      , r = e.officialPrefixes ? e.officialFirstNames + " " + e.officialPrefixes + " " + e.officialSurname : e.officialFirstNames + " " + e.officialSurname;
                    return {
                        firstName: e.firstName,
                        lastName: Object(i.h)("{0}{1}{2}", e.prefixes, e.prefixes ? " " : "", e.surname),
                        fullName: t,
                        officialName: r,
                        birthday: e.birthday ? e.birthday.format("D MMMM YYYY") : ""
                    }
                }
                ,
                n.prototype.getOneDriveForBusinessKoppelingDetails = function() {
                    return this.profielService.oneDriveForBusinessGekoppeld(this.$routeParams.success).then(this.createProviderResult)
                }
                ,
                n.prototype.createProviderResult = function(e) {
                    return {
                        IsGekoppeld: e.isCoupled,
                        IsEnabled: e.isEnabled,
                        OnlyAllowSchoolDomain: !Object(i.u)(e.allowedDomain),
                        Account: e.email
                    }
                }
                ,
                n.$inject = ["$routeParams", "profielService", "collectionResource", n],
                n
            }()
        }
        ).call(this, t(3))
    },
    138: function(e, n, t) {
        "use strict";
        function i(e) {
            return "object" == typeof e && ("number" == typeof e.status && !!e.headers)
        }
        t.d(n, "a", function() {
            return i
        })
    },
    607: function(e, n, t) {
        "use strict";
        t.r(n),
        function(e) {
            t.d(n, "profielAMD", function() {
                return c
            });
            var i = t(114)
              , r = t(132)
              , o = t(608)
              , s = t(609)
              , a = t(610)
              , c = e.module("ProfielAMD", []);
            c.controller("mijnGegevensController", o.a.$inject).controller("leerlingGegevensController", s.a.$inject),
            c.filter("profiel", a.a.prototype.profiel),
            c.service("gegevensOverzichtService", i.a.$inject).service("groepenService", r.a.$inject)
        }
        .call(this, t(1))
    },
    608: function(e, n, t) {
        "use strict";
        (function(e, i, r) {
            t.d(n, "a", function() {
                return g
            });
            var o = t(6)
              , s = t(5)
              , a = t(4)
              , c = t(8)
              , l = t(85)
              , u = t(138)
              , h = t(0)
              , g = function() {
                function n(e, n, t, i, r, l, u, g, v, p, d, f, m, S, O) {
                    var P = this;
                    this.$routeParams = e,
                    this.$filter = n,
                    this.profielService = t,
                    this.applicationService = i,
                    this.gegevensOverzichtService = r,
                    this.dialogService = l,
                    this.currentUser = u,
                    this.profielResource = g,
                    this.aanmeldingenService = v,
                    this.groepenService = p,
                    this.tabService = d,
                    this.oidcService = f,
                    this.downloadTokenService = m,
                    this.toestemmingsService = S,
                    this.$location = O,
                    this.activeTab = 1,
                    this.inschrijvingen = [],
                    this.overeenkomsten = [],
                    this.oneDriveUrls = {
                        business: globalSettings.apiHost + "api/oauth/onedriveforbusiness/init"
                    },
                    this.initialize(),
                    this.accountpaginaUrl = this.oidcService.getSettings().authority,
                    this.tabState = this.tabService.tabState,
                    this.isOuder = this.currentUser.isInRole(a.a.Ouder);
                    var j = this.currentUser.hasPrivilege(s.a.Oauth, o.a.Read);
                    this.profielService.getProfiel().then(function(e) {
                        var n = P.currentUser.hasPrivilege(s.a.ProfielMobiel, o.a.Update)
                          , t = P.currentUser.hasPrivilege(s.a.ProfielMobiel, o.a.Read)
                          , i = P.currentUser.hasPrivilege(s.a.ProfielEmail, o.a.Update)
                          , r = P.currentUser.hasPrivilege(s.a.ProfielEmail, o.a.Read)
                          , a = {
                            SchoolMail: e.EmailAdres,
                            StaticMail: e.EmailAdres,
                            TelefoonNummer: e.Mobiel,
                            CanChangePhone: n,
                            CanChangeMail: i,
                            CanViewMail: r,
                            CanViewPhone: t,
                            EloBerichtenDoorsturen: e.EloBerichtenDoorsturen,
                            CurrentPassword: "",
                            NewPassword: "",
                            PasswordConfirmation: "",
                            KanKoppelingMaken: j
                        };
                        P.Instellingen = a
                    }),
                    this.gegevensOverzichtService.getAdresGegevensApi2(this.activeUserId).then(function(e) {
                        P.adresGegevens = e
                    }),
                    this.currentUser.isInRole(a.a.Ouder) || (this.gegevensOverzichtService.getOpleidingGegevens(this.activeUserId).then(function(e) {
                        P.opleidingGegevens = e
                    }),
                    this.isGebruikerAchttienPlus() && this.profielResource.get(this.activeUserId).then(function(e) {
                        P.magOuderInzien = e.oudersMogenGegevensZien
                    })),
                    this.PersoonsGegevens = this.gegevensOverzichtService.getPersoonsGegevens(this.currentUser.person, this.currentUser.isInRole(a.a.Ouder)),
                    j ? this.gegevensOverzichtService.getOneDriveForBusinessKoppelingDetails().then(function(e) {
                        P.oneDriveForBusinessInstellingen = e
                    }) : Object(h.p)(this.$routeParams.message) || this.applicationService.showMessage(this.$routeParams.message, c.j.ERROR, c.f, "")
                }
                return n.prototype.initialize = function() {
                    var n = this;
                    this.profielFotoUrl = Object(h.h)("/api/leerlingen/{0}/foto", this.currentUser.relatedPersons.current.id),
                    this.activeUserId = this.currentUser.person.id,
                    this.mentoren = {
                        persoonlijkeMentor: null,
                        klasseMentoren: null
                    },
                    this.aanmeldingenService.getLeerlingAanmeldingen(this.currentUser.relatedPersons.current.id).then(function(t) {
                        var i = t.filter(function(e) {
                            return e.isHoofdAanmelding
                        });
                        if (i.length > 0 ? n.aanmelding = e.first(i) : n.aanmelding = e.first(t),
                        n.aanmelding) {
                            n.aanmeldingenService.getPersoonlijkeMentor(n.aanmelding.id).then(function(e) {
                                n.mentoren.persoonlijkeMentor = e
                            });
                            var r = n.aanmelding.groep.id;
                            n.groepenService.getKlasseMentoren(r).then(function(e) {
                                n.mentoren.klasseMentoren = e.items
                            })
                        }
                    }),
                    this.profielService.getInschrijvingen(this.currentUser.relatedPersons.current.id).then(function(t) {
                        t = e.sortBy(t, function(e) {
                            return e.begin
                        }).reverse(),
                        n.inschrijvingen = t
                    }),
                    this.currentUser.isInRole(a.a.Ouder) || this.toestemmingsService.getEntrypointCollection().then(function(t) {
                        var i = e.find(t.items, function(e) {
                            return e.persoonId === n.currentUser.person.id
                        });
                        if (!i)
                            throw new Error("ToestemmingsModule: No entrypoint was returned for leerling with id " + n.currentUser.person.id);
                        n.toestemmingsEntrypoint = i
                    }).catch(function(e) {
                        if (n.toestemmingsEntrypoint = null,
                        !Object(u.a)(e))
                            throw e
                    })
                }
                ,
                n.prototype.onEditToestemming = function() {
                    this.$location.url("/toestemming/wijzigen")
                }
                ,
                n.prototype.onInschrijvingSelected = function(n) {
                    var t = this;
                    this.profielService.getOvereenkomsten(n.links.overeenkomsten.href).then(function(n) {
                        t.overeenkomsten = [],
                        e.each(n, function(e) {
                            var n;
                            e.afgedruktDocument && (n = e.afgedruktDocument),
                            e.ondertekendDocument && (n = e.ondertekendDocument);
                            var i = {
                                naam: n ? n.naam : "-",
                                omschrijving: e.opleiding.omschrijving,
                                versie: e.versie,
                                inleverdatum: e.ingeleverdOp,
                                link: n ? n.links.download.href : null
                            };
                            t.overeenkomsten.push(i)
                        })
                    })
                }
                ,
                n.prototype.setMagOuderInzien = function(e) {
                    var n = this;
                    this.magOuderInzien = e,
                    this.profielResource.put(this.currentUser.person.id, {
                        oudersMogenGegevensZien: this.magOuderInzien
                    }).then(function() {
                        n.applicationService.showMessage("De instellingen zijn aangepast", c.j.INFORMATION, c.f)
                    })
                }
                ,
                n.prototype.onUpdateContactGegevens = function() {
                    this.updateContactGegevens(this.Instellingen.EloBerichtenDoorsturen, this.Instellingen.SchoolMail, this.Instellingen.TelefoonNummer, this.activeUserId)
                }
                ,
                n.prototype.updateContactGegevens = function(e, n, t, i) {
                    var r = this
                      , o = {
                        EloBerichtenDoorsturen: e,
                        EmailAdres: n,
                        Mobiel: t
                    };
                    this.profielService.setContactGegevens(o).then(function() {
                        r.showSuccesToast("De instellingen zijn aangepast")
                    })
                }
                ,
                n.prototype.onKoppelingMaken = function() {
                    var e = this;
                    globalSettings.showOnedriveConnectionWarning ? this.dialogService.showConfirm("Koppeling maken met OneDrive", "Let op: Nadat de koppeling gemaakt is, moet de browser worden afgesloten en Magister opnieuw gestart.", [l.a.Continue, l.a.Cancel], function(n) {
                        n.clickedButtonType === l.a.Continue && e.redirectToLoginPage()
                    }) : this.redirectToLoginPage()
                }
                ,
                n.prototype.onOneDriveForBusinessKoppelingVerwijderen = function() {
                    var e = this;
                    this.profielService.oneDriveForBusinessKoppelingVerwijderen().then(function(n) {
                        e.oneDriveForBusinessInstellingen.IsGekoppeld = !1,
                        e.showSuccesToast("De koppeling met OneDrive for Education is verwijderd")
                    })
                }
                ,
                n.prototype.showOpleidingNAW = function() {
                    return this.currentUser.isInRole(a.a.Leerling)
                }
                ,
                n.prototype.onUpdateMailDoorsturen = function(e) {
                    e !== this.Instellingen.EloBerichtenDoorsturen && this.Instellingen.SchoolMail && (this.Instellingen.EloBerichtenDoorsturen = e,
                    this.updateContactGegevens(e, this.Instellingen.SchoolMail, this.Instellingen.TelefoonNummer, this.activeUserId))
                }
                ,
                n.prototype.redirectToLoginPage = function() {
                    var e = this;
                    this.downloadTokenService.getLocation(this.oneDriveUrls.business).then(function(e) {
                        window.location.href = e
                    }).catch(function() {
                        e.applicationService.showMessage("Aanvang van koppelen met OneDrive Schoolaccount mislukt. Probeer het later nog eens.", c.j.ERROR, c.f)
                    })
                }
                ,
                n.prototype.invalidateElement = function(e, n) {
                    this.applicationService.showMessage(e, c.j.ERROR, c.f);
                    var t = i("input#" + n);
                    t && (t.addClass("validation-error"),
                    t.focus())
                }
                ,
                n.prototype.setElementValid = function(e) {
                    i("input#" + e).removeClass("validation-error")
                }
                ,
                n.prototype.isGebruikerAchttienPlus = function() {
                    var e = r()
                      , n = r(this.currentUser.person.birthday).subtract("months", 3);
                    return e.diff(n, "years") >= 18
                }
                ,
                n.prototype.showSuccesToast = function(e) {
                    this.applicationService.showMessage("De instellingen zijn aangepast", c.j.INFORMATION, c.f)
                }
                ,
                n.$inject = ["$routeParams", "$filter", "profielService", "applicationService", "gegevensOverzichtService", "dialogService", "currentUser", "profielResource", "aanmeldingenService", "groepenService", "tabService", "oidcService", "downloadTokenService", "toestemmingsService", "$location", n],
                n
            }()
        }
        ).call(this, t(3), t(15), t(14))
    },
    609: function(e, n, t) {
        "use strict";
        (function(e) {
            t.d(n, "a", function() {
                return o
            });
            var i = t(138)
              , r = t(0)
              , o = function() {
                function n(e, n, t, i, o, s, a, c) {
                    this.currentUser = e,
                    this.profielService = n,
                    this.gegevensOverzichtService = t,
                    this.aanmeldingenService = i,
                    this.groepenService = o,
                    this.tabService = s,
                    this.toestemmingsService = a,
                    this.$location = c,
                    this.activeTab = 1,
                    this.inschrijvingen = [],
                    this.overeenkomsten = [],
                    this.profielFotoUrl = Object(r.h)("/api/leerlingen/{0}/foto", this.currentUser.relatedPersons.current.id),
                    this.initialize(),
                    this.tabState = this.tabService.tabState
                }
                return n.prototype.initialize = function() {
                    var n = this;
                    this.profielService.getProfiel(this.currentUser.relatedPersons.current.id).then(function(e) {
                        n.profielGegevens = e
                    }),
                    this.persoonsGegevens = this.gegevensOverzichtService.getPersoonsGegevens(this.currentUser.relatedPersons.current);
                    var t = this.getOpleidingGegevens().then(function() {
                        return n.getHuidigeAanmelding()
                    });
                    t.then(function(e) {
                        return n.getPersoonlijkeMentor(e)
                    }),
                    t.then(function(e) {
                        return n.getKlasseMentoren(e)
                    }),
                    this.gegevensOverzichtService.getAdresGegevens(this.currentUser.relatedPersons.current.id).then(function(e) {
                        n.adresGegevens = e
                    }),
                    this.profielService.getInschrijvingen(this.currentUser.relatedPersons.current.id).then(function(t) {
                        t = e.sortBy(t, function(e) {
                            return e.begin
                        }).reverse(),
                        n.inschrijvingen = t
                    }),
                    this.toestemmingsService.getEntrypointCollection().then(function(t) {
                        var i = e.find(t.items, function(e) {
                            return e.persoonId === n.currentUser.relatedPersons.current.id
                        });
                        if (!i)
                            throw new Error("ToestemmingsModule: No entrypoint was returned for leerling with id " + n.currentUser.relatedPersons.current.id);
                        n.toestemmingsEntrypoint = i
                    }).catch(function(e) {
                        if (n.toestemmingsEntrypoint = null,
                        !Object(i.a)(e))
                            throw e
                    })
                }
                ,
                n.prototype.onInschrijvingSelected = function(n) {
                    var t = this;
                    this.profielService.getOvereenkomsten(n.links.overeenkomsten.href).then(function(n) {
                        t.overeenkomsten = [],
                        e.each(n, function(e) {
                            var n;
                            e.afgedruktDocument && (n = e.afgedruktDocument),
                            e.ondertekendDocument && (n = e.ondertekendDocument);
                            var i = {
                                naam: n ? n.naam : "-",
                                omschrijving: e.opleiding.omschrijving,
                                versie: e.versie,
                                inleverdatum: e.ingeleverdOp,
                                link: n ? n.links.download.href : null
                            };
                            t.overeenkomsten.push(i)
                        })
                    })
                }
                ,
                n.prototype.onEditToestemming = function() {
                    this.$location.url("/toestemming/wijzigen")
                }
                ,
                n.prototype.getHuidigeAanmelding = function() {
                    var n = this;
                    return this.aanmeldingenService.getLeerlingAanmeldingen(this.currentUser.relatedPersons.current.id).then(function(t) {
                        var i = e.first(t);
                        return n.aanmelding = i,
                        i
                    })
                }
                ,
                n.prototype.getOpleidingGegevens = function() {
                    var e = this;
                    return this.gegevensOverzichtService.getOpleidingGegevens(this.currentUser.relatedPersons.current.id).then(function(n) {
                        e.opleidingGegevens = n,
                        e.opleidingGegevens.mentoren = {
                            persoonlijkeMentor: void 0,
                            klasseMentoren: void 0
                        }
                    })
                }
                ,
                n.prototype.getPersoonlijkeMentor = function(e) {
                    var n = this;
                    return this.aanmeldingenService.getPersoonlijkeMentor(e.id).then(function(t) {
                        return n.opleidingGegevens.mentoren.persoonlijkeMentor = t,
                        e
                    })
                }
                ,
                n.prototype.getKlasseMentoren = function(e) {
                    var n = this
                      , t = e.groep.id;
                    return this.groepenService.getKlasseMentoren(t).then(function(e) {
                        n.opleidingGegevens.mentoren.klasseMentoren = e.items
                    })
                }
                ,
                n.$inject = ["currentUser", "profielService", "gegevensOverzichtService", "aanmeldingenService", "groepenService", "tabService", "toestemmingsService", "$location", n],
                n
            }()
        }
        ).call(this, t(3))
    },
    610: function(e, n, t) {
        "use strict";
        t.d(n, "a", function() {
            return i
        });
        var i = function() {
            function e() {}
            return e.prototype.profiel = function() {
                return function(e) {
                    if (e)
                        return e.profielen.map(function(e) {
                            return e.code
                        }).join("/")
                }
            }
            ,
            e
        }()
    }
}]);
