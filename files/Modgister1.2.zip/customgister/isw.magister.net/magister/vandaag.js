(window.webpackJsonp = window.webpackJsonp || []).push([[22], {
    108: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return a
        });
        var i = Contracts.Agenda.Afspraken.Enums.AfspraakInfoType
          , a = function() {
            function e() {}
            return e.prototype.toetsTypeOmschrijving = function() {
                return function(e) {
                    switch (e) {
                    case i.Proefwerk:
                        return "Proefwerk";
                    case i.Tentamen:
                        return "Tentamen";
                    case i.SchriftelijkeOverhoring:
                        return "SO";
                    case i.MondelingeOverhoring:
                        return "MO";
                    default:
                        return "onbekend"
                    }
                }
            }
            ,
            e.prototype.afspraakStatus = function() {
                return function(e) {
                    var t = "";
                    return e && (e.isWijziging && (t = "alert"),
                    (e.afspraakType === Contracts.Agenda.Afspraken.Enums.AfspraakType.Les || e.afspraakType === Contracts.Agenda.Afspraken.Enums.AfspraakType.Algemeen || e.afspraakType === Contracts.Agenda.Afspraken.Enums.AfspraakType.Kwt) && e.id < 0 && (t += " alertRed")),
                    t
                }
            }
            ,
            e
        }()
    },
    626: function(e, t, n) {
        "use strict";
        n.r(t),
        function(e) {
            n.d(t, "vandaagAMD", function() {
                return f
            });
            var i = n(108)
              , a = n(627)
              , r = n(629)
              , s = n(631)
              , o = n(633)
              , c = n(635)
              , d = n(637)
              , l = n(639)
              , g = n(641)
              , f = e.module("VandaagAMD", []);
            f.directive("cijfersLeerling", a.a.$inject).directive("cijfersOuder", r.a.$inject).directive("notificatieWidget", s.a.$inject).directive("smCijfersOuderInstellingen", o.a).directive("agendaWidget", d.a.$inject).directive("smAvailableWidget", ["$timeout", "vandaagDefaults", l.a]).directive("takenWidget", c.a.$inject),
            f.controller("vandaagController", g.a),
            f.filter("afspraakStatus", i.a.prototype.afspraakStatus)
        }
        .call(this, n(1))
    },
    627: function(e, t, n) {
        "use strict";
        (function(e) {
            n.d(t, "a", function() {
                return o
            });
            var i, a = n(98), r = (i = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    t.hasOwnProperty(n) && (e[n] = t[n])
            }
            ,
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                i(e, t),
                e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
                new n)
            }
            ), s = function() {
                function t(e, t, n, i, a, r, s, o, c) {
                    var d = this;
                    this.$scope = e,
                    this.$location = t,
                    this.$routeParams = n,
                    this.$filter = i,
                    this.cijfersServiceOud = a,
                    this.aanmeldingenService = r,
                    this.laatsteCijfersAdapter = s,
                    this.currentUser = o,
                    this.cijfersService = c;
                    var l = this.currentUser.relatedPersons.current.id;
                    e.showGradesToday = !1,
                    e.showGradesWeek = !1;
                    var g = this.laatsteCijfersAdapter.getDefaultLaatsteCijfers();
                    this.setCijfers(e, g),
                    this.getLaatsteCijfers(e, +l),
                    e.redirectToPeriodOverview = function() {
                        d.$location.path("cijfers")
                    }
                    ,
                    e.hideCijfersOverzicht = function() {
                        e.showGradesToday = !1,
                        e.showGradesWeek = !1
                    }
                    ,
                    e.showToday = function() {
                        e.gradesAvailable && 0 !== e.gradesTodayCount && (e.showGradesToday = !0)
                    }
                    ,
                    e.showWeek = function() {
                        e.gradesAvailable && 0 !== e.gradesWeekCount && (e.showGradesWeek = !0)
                    }
                    ,
                    e.showLaatsteCijfers = function() {
                        return !e.showGradesToday && !e.showGradesWeek
                    }
                    ,
                    e.widgetTitle = function() {
                        return e.showGradesToday ? "Cijfers van vandaag" : e.showGradesWeek ? "Cijfers van deze week" : "Laatste cijfers"
                    }
                }
                return t.prototype.getLaatsteCijfers = function(e, t) {
                    var n = this;
                    this.cijfersService.getLaatstBehaaldeResultaten(t, 50, 0).then(function(t) {
                        n.setCijfers(e, t)
                    })
                }
                ,
                t.prototype.setCijfers = function(t, n) {
                    var i;
                    e.isDefined(n) && e.isDefined(n.items) && null !== n.items && (i = n);
                    var a = null;
                    a = e.isDefined(i) && e.isDefined(i.items) && null !== i.items ? this.laatsteCijfersAdapter.createLaatsteCijfers(i) : this.laatsteCijfersAdapter.getDefaultLaatsteCijfers(),
                    t.gradesToday = a.vandaagCijfers,
                    t.gradesWeek = a.weekCijfers,
                    t.lastGrade = a.laatsteCijfer,
                    t.gradesTodayCount = t.gradesToday.length,
                    t.gradesWeekCount = t.gradesWeek.length;
                    var r = a.laatsteCijfer;
                    t.gradesAvailable = "-" !== r.waarde
                }
                ,
                t.$inject = ["$scope", "$location", "$routeParams", "$filter", "cijfersServiceOud", "aanmeldingenService", "laatsteCijfersAdapter", "currentUser", "cijfersService", t],
                t
            }(), o = function(e) {
                function t(t, i, a, r, o, c, d, l) {
                    var g = e.call(this) || this;
                    return g.$location = t,
                    g.$routeParams = i,
                    g.$filter = a,
                    g.cijfersServiceOud = r,
                    g.aanmeldingenService = o,
                    g.laatsteCijfersAdapter = c,
                    g.currentUser = d,
                    g.cijfersService = l,
                    g.template = n(628),
                    g.replace = !0,
                    g.link = function(e, t, n) {
                        return g.linkFn(e, t, n)
                    }
                    ,
                    g.controller = ["$scope", "$location", "$routeParams", "$filter", "cijfersServiceOud", "aanmeldingenService", "laatsteCijfersAdapter", "currentUser", "cijfersService", s],
                    g
                }
                return r(t, e),
                t.prototype.linkFn = function(t, n, i) {
                    e.prototype.linkFn.call(this, t, n, i)
                }
                ,
                t.$inject = ["$location", "$routeParams", "$filter", "cijfersServiceOud", "aanmeldingenService", "laatsteCijfersAdapter", "currentUser", "cijfersService", function(e, n, i, a, r, s, o, c) {
                    return new t(e,n,i,a,r,s,o,c)
                }
                ],
                t
            }(a.a)
        }
        ).call(this, n(1))
    },
    628: function(e, t) {
        e.exports = '<div id="cijfers-leerling" class="widget">\r\n    <div class="block grade-widget" data-sm-loading-indicator="{domain: \'aanmeldingen\', overlay: false, timeout: 1000}">\r\n        <h3 data-ng-if="showLaatsteCijfers()">\r\n            <span data-widget-resize-button data-widget-name="cijfers-leerling"></span>\r\n            <b>{{widgetTitle()}}</b>\r\n        </h3>\r\n        \r\n        <h3 data-ng-class="{\'detail\' : !showLaatsteCijfers()}" style="cursor: pointer" data-ng-if="!showLaatsteCijfers()" data-ng-click="hideCijfersOverzicht();">\r\n            <span data-ng-hide="showLaatsteCijfers()" class="grade-back icon-back" data-ng-click="hideCijfersOverzicht();"></span>\r\n            <b>{{widgetTitle()}}</b>\r\n        </h3>\r\n        <div class="content" data-ng-class="{false: \'no-data\'}[gradesAvailable]">\r\n            <div class="last-grade" data-ng-show="showLaatsteCijfers()"><span class="cijfer">{{lastGrade.waarde}}</span><span class="omschrijving" title="{{lastGrade.vak.omschrijving}}">{{lastGrade.vak.omschrijving}}</span></div>\r\n            <ul class="list arrow-list" data-ng-show="showLaatsteCijfers()">\r\n                <li data-ng-class="{true: \'unread\', false: \'no-data\'}[gradesTodayCount > 0]">\r\n                    <a href="" data-ng-click="showToday();" title=""><span class="nr">{{gradesTodayCount}}</span> vandaag</a>\r\n                </li>\r\n                <li data-ng-class="{true: \'unread\', false: \'no-data\'}[gradesWeekCount > 0]">\r\n                    <a href="" data-ng-click="showWeek();" title=""><span class="nr">{{gradesWeekCount}}</span> deze week</a>\r\n                </li>\r\n            </ul>\r\n            <ul class="list grades-list" data-ng-show="showGradesToday">\r\n                <li data-ng-repeat="today in gradesToday" data-sm-notify-complete="aanmeldingen">\r\n                    <a href="">\r\n                        <span title="{{today.waarde}}" class="student-grade-widget-grade" data-ng-class="{true: \'\', false: \'student-grade-widget-grade-insufficient\'}[{{today.isCijferVoldoende || true}}]">{{today.waarde}}</span>\r\n                        <span class="student-grade-widget-class">{{today.vak.omschrijving}}</span>\r\n                        <span class="student-grade-widget-entry-date">{{today.ingevoerdOp | date: \'d-MM HH:mm\'}}</span>\r\n                    </a>\r\n                </li>\r\n            </ul>\r\n            <ul class="list grades-list" data-ng-show="showGradesWeek">\r\n                <li data-ng-repeat="week in gradesWeek" data-sm-notify-complete="aanmeldingen">\r\n                    <a href="">\r\n                        <span title="{{week.waarde}}" class="student-grade-widget-grade" data-ng-class="{true: \'\', false: \'student-grade-widget-grade-insufficient\'}[{{week.isVoldoende || true}}]">{{week.waarde}}</span>\r\n                        <span class="student-grade-widget-class">{{week.vak.omschrijving}}</span>\r\n                        <span class="student-grade-widget-entry-date">{{week.ingevoerdOp | date: \'d-MM HH:mm\'}}</span>\r\n                    </a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n        <footer class="endlink">\r\n            <a href="#/cijfers" data-ng-click="redirectToPeriodOverview();" title="">periodeoverzicht</a>\r\n        </footer>\r\n    </div>\r\n</div>\r\n'
    },
    629: function(e, t, n) {
        "use strict";
        (function(e, i) {
            n.d(t, "a", function() {
                return c
            });
            var a, r = n(0), s = n(98), o = (a = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    t.hasOwnProperty(n) && (e[n] = t[n])
            }
            ,
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                a(e, t),
                e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
                new n)
            }
            ), c = function(t) {
                function a(e, i, a, r, s) {
                    var o = t.call(this) || this;
                    return o.$location = e,
                    o.cijfersServiceOud = i,
                    o.gemiddeledCijfersAdapter = a,
                    o.instellingService = r,
                    o.currentUser = s,
                    o.CIJFERKOLOM_INSTELLINGEN_KEY = "cijferKolommenVoorOuder",
                    o.template = n(630),
                    o.replace = !0,
                    o.link = function(e, t, n) {
                        return o.linkFn(e, t, n)
                    }
                    ,
                    o
                }
                return o(a, t),
                a.prototype.linkFn = function(n, a, s) {
                    var o = this;
                    t.prototype.linkFn.call(this, n, a, s),
                    n.instellingVisible = !1,
                    n.data = {
                        kolommen: [],
                        vakken: [],
                        emptyData: ""
                    },
                    n.toggleVisibilityInstelling = function() {
                        0 === n.vakken.length ? n.instellingVisible = !1 : n.instellingVisible = !n.instellingVisible
                    }
                    ;
                    var c = this.currentUser.relatedPersons.current.id;
                    n.titleCijferVanKind = this.currentUser.relatedPersons.current.fullName,
                    n.$broadcast("START-LOADING"),
                    this.cijfersServiceOud.getGemiddeldeCijfers(c).then(function(t) {
                        var a;
                        e.isDefined(t) && t.length > 0 ? (a = o.gemiddeledCijfersAdapter.createGemiddeldeCijfersTabel(t),
                        n.data.kolommen = a.kolommen,
                        n.data.vakken = a.vakken,
                        n.data.emptyData = a.emptyData) : (a = o.gemiddeledCijfersAdapter.getDefaultGemiddeldeCijfers(),
                        n.data.kolommen = a.kolommen,
                        n.data.vakken = a.vakken,
                        n.data.emptyData = a.emptyData),
                        o.instellingService.getForRelatedPerson(o.currentUser.person.id, o.currentUser.relatedPersons.current.id, o.CIJFERKOLOM_INSTELLINGEN_KEY).then(function(e) {
                            e = Object(r.w)(e) ? [] : e,
                            n.vakken = i.uniq(i.map(t, function(t) {
                                var n = {
                                    afkorting: t.Vak.Afkorting,
                                    id: t.Vak.Id,
                                    omschrijving: t.Vak.Omschrijving,
                                    volgnr: t.Vak.Volgnr,
                                    IsChecked: !0
                                }
                                  , a = i.first(e);
                                Object(r.w)(Object(r.w)(a) || a.IsChecked) && (n.IsChecked = !1);
                                var s = i.find(e, function(e) {
                                    return e.Id === n.id || e.id === n.id
                                });
                                return s && (n.IsChecked = s.IsChecked || Object(r.w)(s.IsChecked)),
                                n
                            }), function(e) {
                                return e.omschrijving
                            })
                        }),
                        n.$broadcast("STOP-LOADING")
                    }),
                    n.redirectToPeriodOverview = function() {
                        o.$location.path("cijfers")
                    }
                    ,
                    n.filteredVakken = function() {
                        var t = n.vakken;
                        if (e.isDefined(t) && null !== t) {
                            var i = t.filter(function(e) {
                                return e.IsChecked
                            });
                            if (Object(r.t)(n.data) && Object(r.t)(n.data.vakken))
                                return n.data.vakken.filter(function(e) {
                                    return i.some(function(t) {
                                        return t.omschrijving === e.omschrijving
                                    })
                                })
                        }
                        return []
                    }
                }
                ,
                a.DIRECTIVE_NAME = "cijfersOuder",
                a.$inject = ["$location", "cijfersServiceOud", "gemiddeldeCijfersAdapter", "instellingService", "currentUser", function(e, t, n, i, r) {
                    return new a(e,t,n,i,r)
                }
                ],
                a
            }(s.a)
        }
        ).call(this, n(1), n(3))
    },
    630: function(e, t) {
        e.exports = '<div id="cijfers-ouder" class="widget">\r\n    <div class="block grade-widget">\r\n        <h3>\r\n            <span class="block-menu icon-settings" data-ng-click="toggleVisibilityInstelling()" data-ng-class="{\'disabled\': vakken.length === 0}"></span>\r\n            <div data-loading-indicator="" image="assets/images/throbber-forward-concept1.png"></div>\r\n            <span data-widget-resize-button data-widget-name="cijfers-ouder"></span>\r\n            <b>Laatste gemiddelde cijfers</b>\r\n        </h3>\r\n        <div data-sm-cijfers-ouder-instellingen="instellingen" vakken="vakken" on-saved="toggleVisibilityInstelling()" class="ng-hide" data-ng-show="instellingVisible"></div>\r\n        <div class="content">\r\n            <table class="table-grid-layout grades-overview" data-ng-show="filteredVakken().length">\r\n                <colgroup>\r\n                    <col width="100%" />\r\n                    <col width="135" />\r\n                </colgroup>\r\n                <tbody>\r\n                    <tr>\r\n                        <th>&nbsp;</th>\r\n                        <th data-ng-repeat="kolom in data.kolommen"><strong title="{{kolom.KolomOmschrijving}}">{{kolom.KolomOmschrijving}}</strong></th>\r\n                    </tr>\r\n\r\n                    <tr data-ng-repeat="vak in filteredVakken() track by $index">\r\n                        <td><strong>{{vak.omschrijving}}</strong></td>\r\n                        <td data-ng-class="{true: \'\', false: \'onvoldoende\'}[cijfer.IsVoldoende]" data-ng-repeat="cijfer in vak.cijfers track by $index">{{cijfer.CijferStr || \'-\'}}</td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            <div class="block-empty" data-ng-hide="filteredVakken().length">\r\n                <em>Er zijn geen cijfers van {{titleCijferVanKind}}.</em>\r\n            </div>\r\n        </div>\r\n        <footer class="endlink"><a href="" data-ng-click="redirectToPeriodOverview();" title="">Periode overzicht</a></footer>\r\n    </div>\r\n</div>\r\n'
    },
    631: function(e, t, n) {
        "use strict";
        (function(e, i, a) {
            n.d(t, "a", function() {
                return c
            });
            var r, s = n(98), o = (r = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    t.hasOwnProperty(n) && (e[n] = t[n])
            }
            ,
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                r(e, t),
                e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
                new n)
            }
            ), c = function(t) {
                function r(e, i, a, r, s) {
                    var o = t.call(this) || this;
                    return o.notificatieService = e,
                    o.$rootScope = i,
                    o.applicationService = a,
                    o.aanmeldingenService = r,
                    o.currentUser = s,
                    o.replace = !0,
                    o.template = n(632),
                    o.link = function(e, t, n) {
                        return o.linkFn(e, t, n)
                    }
                    ,
                    o
                }
                return o(r, t),
                r.prototype.linkFn = function(e, n, i) {
                    t.prototype.linkFn.call(this, e, n, i),
                    this.processNotificationItems(e)
                }
                ,
                r.prototype.processNotificationItems = function(t) {
                    var n = this;
                    this.aanmeldingenService.getLeerlingAanmeldingen(this.currentUser.relatedPersons.current.id).then(function(r) {
                        var s, o = e((new Date).setHours(0, 0, 0, 0));
                        if (i.each(r, function(t) {
                            e(n.toCrossBrowserDateString("" + t.begin)) <= o && e(n.toCrossBrowserDateString("" + t.einde)) >= o && (s = t)
                        }),
                        a.isDefined(s)) {
                            var c = e(n.toCrossBrowserDateString("" + s.begin)).format("YYYY-MM-DD")
                              , d = e(n.toCrossBrowserDateString("" + s.einde)).format("YYYY-MM-DD");
                            t.notificatieData = n.notificatieService.getNotificatieItems(c, d)
                        }
                        n.$rootScope.$broadcast("NG_REPEAT_FINISHED", "notificatie")
                    })
                }
                ,
                r.prototype.toCrossBrowserDateString = function(e) {
                    return e.replace("0000Z", "Z")
                }
                ,
                r.$inject = ["notificatieService", "$rootScope", "applicationService", "aanmeldingenService", "currentUser", function(e, t, n, i, a) {
                    return new r(e,t,n,i,a)
                }
                ],
                r
            }(s.a)
        }
        ).call(this, n(14), n(3), n(1))
    },
    632: function(e, t) {
        e.exports = '<div id="notificatie-widget" class="widget">\r\n    <div class="block" data-sm-loading-indicator="{domain: \'notificatie\', hideEvent: \'NG_REPEAT_FINISHED\', overlay: false, timeout: 1000}">\r\n        <h3>\r\n            <span data-widget-resize-button data-widget-name="notificatie-widget"></span>\r\n            <b>Notificaties</b>\r\n        </h3>\r\n        <div class="content" data-sm-scrollbar="scrollbar" data-horizontal-scroll="false">\r\n            <ul class="list">\r\n                <li data-ng-repeat="notificatieItem in notificatieData.notificatieItems" data-ng-class="{\'unread\' : notificatieItem.count !== 0, \'no-data\': notificatieItem.count === 0}" data-sm-notify-complete="opdrachten">\r\n                    <a data-ng-href="{{notificatieItem.link}}" title=""><span>{{notificatieItem.countDescription}}</span> {{notificatieItem.name}}</a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n        <footer class="endlink"></footer>\r\n    </div>\r\n</div>'
    },
    633: function(e, t, n) {
        "use strict";
        (function(e) {
            n.d(t, "a", function() {
                return a
            });
            var i = function() {
                function t(e, t) {
                    this.instellingService = e,
                    this.currentUser = t
                }
                return t.prototype.saveInstellingen = function() {
                    var t = this
                      , n = e.map(this.vakken, function(e) {
                        return {
                            Id: e.id,
                            IsChecked: e.IsChecked
                        }
                    });
                    this.instellingService.setForRelatedPerson(this.currentUser.person.id, this.currentUser.relatedPersons.current.id, "cijferKolommenVoorOuder", n).then(function(e) {
                        t.onSaved()
                    })
                }
                ,
                t
            }();
            function a() {
                return {
                    template: n(634),
                    restrict: "A",
                    replace: !1,
                    scope: {
                        vakken: "<",
                        onSaved: "&"
                    },
                    controller: ["instellingService", "currentUser", i],
                    controllerAs: "ctrl",
                    bindToController: !0
                }
            }
        }
        ).call(this, n(3))
    },
    634: function(e, t) {
        e.exports = '<div class="mask"></div>\r\n<div class="quick-menu">\r\n    <span class="arrow"></span>\r\n    <h3><b>Vakkeuze</b></h3>\r\n    <form action="#">\r\n        <div class="filter-content">\r\n            <ul class="list">\r\n                <li ng-repeat="vak in ctrl.vakken">\r\n                    <span class="check">\r\n                        <input type="checkbox" class="checkbox" name="VAK-{{vak.id}}" ng-model="vak.IsChecked" id="VAK-{{vak.id}}">\r\n                        <label for="VAK-{{vak.id}}"><span></span>{{vak.omschrijving}}</label>\r\n                    </span>                    \r\n                </li>\r\n            </ul>\r\n        </div>\r\n    </form>\r\n    <footer class="endlink">\r\n        <a href="" ng-click="ctrl.saveInstellingen();" class="btn-pri">opslaan</a>\r\n    </footer>\r\n</div>\r\n'
    },
    635: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var i, a = n(98), r = (i = Object.setPrototypeOf || {
            __proto__: []
        }instanceof Array && function(e, t) {
            e.__proto__ = t
        }
        || function(e, t) {
            for (var n in t)
                t.hasOwnProperty(n) && (e[n] = t[n])
        }
        ,
        function(e, t) {
            function n() {
                this.constructor = e
            }
            i(e, t),
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
            new n)
        }
        ), s = function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.template = n(636),
                t.replace = !0,
                t.link = function(e, n, i) {
                    return t.linkFn(e, n, i)
                }
                ,
                t
            }
            return r(t, e),
            t.prototype.linkFn = function(t, n, i) {
                e.prototype.linkFn.call(this, t, n, i)
            }
            ,
            t.$inject = [function() {
                return new t
            }
            ],
            t
        }(a.a)
    },
    636: function(e, t) {
        e.exports = '<div id="taken-widget" class="widget">\r\n    <div class="block">\r\n        <h3><b>Taken</b></h3>\r\n        <div class="content no-data">\r\n            <em>Er zijn geen taken op dit moment.</em>\r\n        </div>\r\n        <footer class="endlink no-link">alle taken</footer>\r\n    </div>\r\n</div>\r\n'
    },
    637: function(e, t, n) {
        "use strict";
        (function(e, i, a) {
            n.d(t, "a", function() {
                return g
            });
            var r, s = n(4), o = n(0), c = n(98), d = (r = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var n in t)
                    t.hasOwnProperty(n) && (e[n] = t[n])
            }
            ,
            function(e, t) {
                function n() {
                    this.constructor = e
                }
                r(e, t),
                e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype,
                new n)
            }
            ), l = Object.assign || function(e) {
                for (var t, n = 1, i = arguments.length; n < i; n++)
                    for (var a in t = arguments[n])
                        Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
                return e
            }
            , g = function(t) {
                function r(e, i, a, r, s, o, c) {
                    var d = t.call(this) || this;
                    return d.$anchorScroll = e,
                    d.$location = i,
                    d.$timeout = a,
                    d.agendaService = r,
                    d.roosterwijzigingenService = s,
                    d.applicationService = o,
                    d.currentUser = c,
                    d.template = n(638),
                    d.replace = !0,
                    d.link = function(e, t, n) {
                        return d.linkFn(e, t, n)
                    }
                    ,
                    d
                }
                return d(r, t),
                r.prototype.linkFn = function(e, n, i) {
                    t.prototype.linkFn.call(this, e, n, i),
                    this.getAfspraken(e)
                }
                ,
                r.prototype.getAfspraken = function(t) {
                    var n = this
                      , i = e().format("YYYY-MM-DD")
                      , a = e().day(e().day() + 1).format("YYYY-MM-DD")
                      , r = this.currentUser.relatedPersons.current.id;
                    t.$broadcast("START-LOADING"),
                    this.agendaService.getAfspraken(r, i, a, !0, "1,2,3,4,6,7,8,9").then(function(e) {
                        var i = e.filter(function(e) {
                            return n.filterItemsOpVervallenStatus
                        });
                        n.roosterwijzigingenService.get(r).then(function(e) {
                            i && n.updateScope(t, i, e.agendaItems),
                            t.$broadcast("STOP-LOADING"),
                            t.isDoneLoading = !0
                        })
                    })
                }
                ,
                r.prototype.filterItemsOpVervallenStatus = function(e) {
                    return e.status !== Contracts.Agenda.Afspraken.Enums.AfspraakStatus.VervallenAutomatisch && e.status !== Contracts.Agenda.Afspraken.Enums.AfspraakStatus.VervallenHandmatig
                }
                ,
                r.prototype.mapToVandaagAgendaItem = function(e) {
                    var t = this;
                    return this.agendaService.mapItemsToViewModel(e).map(function(e) {
                        return l({}, e, {
                            omschrijvingSummary: t.getOmschrijvingSummary(e),
                            dashboardUrl: t.getDashboardUrl(e)
                        })
                    }).sort(function(e, t) {
                        return e.begin < t.begin ? -1 : e.begin > t.begin ? 1 : 0
                    })
                }
                ,
                r.prototype.getOmschrijvingSummary = function(e) {
                    var t = this.currentUser.isInRole(s.a.Ouder)
                      , n = e.status === Contracts.Agenda.Afspraken.Enums.AfspraakStatus.VervallenHandmatig || e.status === Contracts.Agenda.Afspraken.Enums.AfspraakStatus.VervallenAutomatisch
                      , i = e.afspraakType === Contracts.Agenda.Afspraken.Enums.AfspraakType.Persoonlijk
                      , a = e.locatie && !!e.locatie.length
                      , r = e.lokaal && !!e.lokaal.length;
                    return a && !n ? t && i ? e.omschrijving : Object(o.h)("{0} ({1})", e.omschrijving, e.locatie) : a || !r || n ? a || r || n ? n ? "-" : "" : e.omschrijving : t && i ? e.omschrijving : Object(o.h)("{0} ({1})", e.omschrijving, e.lokaal)
                }
                ,
                r.prototype.getCurrentItemId = function(t) {
                    var n, a = e();
                    return (n = i.filter(t, function(e) {
                        return e.einde <= a
                    })).length ? i.last(n).id : 0
                }
                ,
                r.prototype.scrollTo = function(e) {
                    var t = this;
                    this.$timeout(function() {
                        var n = t.$location.hash();
                        t.$location.hash("afspraak" + e),
                        t.$anchorScroll(),
                        t.$location.hash("vandaagschermtop"),
                        t.$anchorScroll(),
                        t.$location.hash("ng-app"),
                        t.$anchorScroll(),
                        t.$location.hash(n)
                    }, 500)
                }
                ,
                r.prototype.updateScope = function(t, n, i) {
                    var r, s, o = e(e().format("YYYY-MM-DD"), "YYYY-MM-DD");
                    r = this.agendaService.mergeAfsprakenArrays(this.agendaService.getByDay(n, o), this.agendaService.getByDay(i, o)),
                    o = 5 === e(o).day() ? e(o).day(e(o).day() + 3) : e(o).day(e(o).day() + 1),
                    t.morgen = new Date(o.format("YYYY-MM-DD")),
                    s = this.agendaService.mergeAfsprakenArrays(this.agendaService.getByDay(n, o), this.agendaService.getByDay(i, o), !0);
                    var c = this.mapToVandaagAgendaItem(r)
                      , d = this.mapToVandaagAgendaItem(s)
                      , l = "";
                    a.isUndefined(this.currentUser.relatedPersons.current) || this.currentUser.person === this.currentUser.relatedPersons.current || (l = "Agenda van " + this.getFirstName(this.currentUser.relatedPersons.current.fullName)),
                    t.agendaData = {
                        titel: l,
                        titelMorgen: "Wijzigingen voor " + o.format("dddd"),
                        agendaItemsVandaag: c,
                        agendaItemsMorgen: d
                    };
                    var g = this.getCurrentItemId(t.agendaData.agendaItemsVandaag);
                    this.scrollTo(g.toString())
                }
                ,
                r.prototype.getDashboardUrl = function(e) {
                    return e.id < 0 ? "" : "#/agenda/" + (e.afspraakType === Contracts.Agenda.Afspraken.Enums.AfspraakType.Les || e.afspraakType === Contracts.Agenda.Afspraken.Enums.AfspraakType.Kwt ? "huiswerk" : "afspraak") + "/" + e.id
                }
                ,
                r.prototype.getFirstName = function(e) {
                    return e.split(" ")[0]
                }
                ,
                r.$inject = ["$anchorScroll", "$location", "$timeout", "agendaService", "roosterwijzigingenService", "applicationService", "currentUser", function(e, t, n, i, a, s, o) {
                    return new r(e,t,n,i,a,s,o)
                }
                ],
                r
            }(c.a)
        }
        ).call(this, n(14), n(3), n(1))
    },
    638: function(e, t) {
        e.exports = '<div id="agenda-widget" class="widget agenda-widget">\r\n    <div class="block" data-sm-loading-indicator="{domain: \'afspraken\', hideEvent: \'NG_REPEAT_FINISHED\', overlay: false, timeout: 1000}">\r\n        <h3>\r\n            <span data-widget-resize-button data-widget-name="agenda-widget"></span>\r\n            <b>Vandaag</b>\r\n        </h3>\r\n        <div class="content">\r\n            <div data-ng-show="isDoneLoading" id="agendawidgetlistcontainer">\r\n                <ul class="list agenda-list" data-ng-show="agendaData.agendaItemsVandaag.length">\r\n                    <li data-ng-repeat="afspraak in agendaData.agendaItemsVandaag" class="{{afspraak | afspraakStatus}}" data-sm-notify-complete="afspraken">\r\n                        <a data-ng-href="{{afspraak.dashboardUrl}}" title="" id="afspraak{{afspraak.id}}">\r\n                            <span class="time" data-ng-bind-template="hele dag" data-ng-if="afspraak.isHeleDag"></span>\r\n                            <span class="time" data-ng-bind-template="{{afspraak.beginString |date:\'HH:mm\'}} - {{afspraak.eindString | date:\'HH:mm\'}}" data-ng-if="!afspraak.isHeleDag"></span>\r\n                            \r\n                            <div class="les-bottom"> \r\n                                <div class="les-info">\r\n                                    <span data-ng-show="{{afspraak.lesuur != \'\'}}" class="nrblock" data-ng-bind="afspraak.lesuur"></span>\r\n                                    <span data-ng-if="::afspraak.isOnlineDeelname" class="video-icon">\r\n                                        <i class="fas fa-video"></i>\r\n                                    </span>\r\n                                    <span class="classroom" data-ng-bind-template="{{afspraak.omschrijvingSummary}}" ></span> \r\n                                </div>\r\n                                <div class="icon-block">\r\n                                    <span data-ng-if="afspraak.heeftBijlagen" class="text-icon icon-only">\r\n                                        <i class="far fa-paperclip"></i>\r\n                                    </span>\r\n                                    <span data-ng-if="afspraak.isHerhalend" class="text-icon icon-only">\r\n                                        <i class="fas fa-repeat-alt"></i>\r\n                                    </span>\r\n                                \r\n                                    \x3c!--huiswerk--\x3e\r\n                                    <span data-ng-if="(!afspraak.heeftProefwerk && !afspraak.heeftTussentijdseToets && !afspraak.heeftSchriftelijkeOverhoring\r\n                                        && !afspraak.heeftMondelingeOverhoring && !afspraak.isExamen) \r\n                                        && (afspraak.heeftOnafgerondHuiswerk || afspraak.heeftAfgerondHuiswerk)" class="agenda-text-icon"\r\n                                            ng-class="{\'outline\': !afspraak.heeftAfgerondHuiswerk}"\r\n                                            icon-type="{{afspraak.heeftAfgerondHuiswerk ? \'ok\': \'information\'}}">Huiswerk</span>\r\n                    \r\n                                    <span data-ng-if="afspraak.heeftInformatie" class="agenda-text-icon outline" icon-type="information">Informatie</span>\r\n                                \r\n                                    \x3c!--toetsen--\x3e\r\n                                    <span data-ng-if="afspraak.heeftProefwerk" class="text-icon" icon-type="information">Proefwerk</span>\r\n                                    <span data-ng-if="afspraak.heeftTussentijdseToets" class="text-icon" icon-type="information">Tentamen</span>\r\n                                    <span data-ng-if="afspraak.heeftSchriftelijkeOverhoring" class="text-icon" icon-type="information">SO</span>\r\n                                    <span data-ng-if="afspraak.heeftMondelingeOverhoring" class="text-icon" icon-type="information">MO</span>\r\n                                    <span data-ng-if="afspraak.isExamen" class="text-icon" icon-type="information">Examen</span>\r\n                                </div>\r\n                            </div>\r\n                        </a>\r\n                    </li>\r\n                </ul>\r\n                <ul class="list agenda-list" data-ng-hide="agendaData.agendaItemsVandaag.length">\r\n                    <li class="no-data">\r\n                        <em>Er zijn geen afspraken op dit moment.</em>\r\n                    </li>\r\n                </ul>\r\n                <h4 data-ng-show="agendaData.agendaItemsMorgen.length" data-ng-bind-template="{{agendaData.titelMorgen}}"></h4>\r\n                <ul class="list agenda-list roosterwijziging" data-ng-show="agendaData.agendaItemsMorgen.length">\r\n                    <li data-ng-repeat="wijziging in agendaData.agendaItemsMorgen" class="{{wijziging | afspraakStatus}}" data-sm-notify-complete="afspraken">\r\n                        <a data-ng-href="{{wijziging.dashboardUrl}}" title="">\r\n                            <span class="time" data-ng-bind-template="{{wijziging.beginString | date:\'HH:mm\'}} - {{wijziging.eindString | date:\'HH:mm\'}}"></span>\r\n                            \r\n                            <div class="les-bottom">\r\n                                <div class="les-info">\r\n                                    <span data-ng-show="{{wijziging.lesuur != \'\'}}" class="nrblock" data-ng-bind="wijziging.lesuur"></span>\r\n                                    <span data-ng-if="::wijziging.isOnlineDeelname" class="video-icon">\r\n                                        <i class="fas fa-video"></i>\r\n                                    </span>\r\n                                    <span class="classroom" data-ng-if="wijziging.locatie && (wijziging.status != 4 && wijziging.status != 5) && isOuder" data-ng-bind-template="{{wijziging.omschrijving}}"></span>\r\n                                    <span class="classroom" data-ng-if="wijziging.locatie && (wijziging.status != 4 && wijziging.status != 5) && !isOuder" data-ng-bind-template="{{wijziging.omschrijving}} ({{wijziging.locatie}})"></span>\r\n                                    <span class="classroom" data-ng-if="(!wijziging.locatie.length && wijziging.lokaal.length) && (wijziging.status != 4 && wijziging.status != 5) && isOuder" data-ng-bind-template="{{wijziging.omschrijving}}"></span>\r\n                                    <span class="classroom" data-ng-if="(!wijziging.locatie.length && wijziging.lokaal.length) && (wijziging.status != 4 && wijziging.status != 5) && !isOuder" data-ng-bind-template="{{wijziging.omschrijving}} ({{wijziging.lokaal}})"></span>\r\n                                    <span class="classroom" data-ng-if="(!wijziging.locatie.length && !wijziging.lokaal.length) && (wijziging.status != 4 && wijziging.status != 5)" data-ng-bind="wijziging.omschrijving"></span>\r\n                                    <span class="classroom" data-ng-if="wijziging.status == 4 || wijziging.status == 5">-</span>\r\n                                </div>\r\n                                <div class="icon-block">\r\n                                    <span data-ng-if="wijziging.heeftBijlagen" class="text-icon icon-only">\r\n                                        <i class="far fa-paperclip"></i>\r\n                                    </span>\r\n                                    <span data-ng-if="wijziging.isHerhalend" class="text-icon icon-only">\r\n                                        <i class="fas fa-repeat-alt"></i>\r\n                                    </span>\r\n                                \r\n                                    \x3c!--huiswerk--\x3e\r\n                                    <span data-ng-if="(!wijziging.heeftProefwerk && !wijziging.heeftTussentijdseToets && !wijziging.heeftSchriftelijkeOverhoring\r\n                                        && !wijziging.heeftMondelingeOverhoring && !wijziging.isExamen) \r\n                                        && (wijziging.heeftOnafgerondHuiswerk || wijziging.heeftAfgerondHuiswerk)" class="agenda-text-icon"\r\n                                            ng-class="{\'outline\': !wijziging.heeftAfgerondHuiswerk}"\r\n                                            icon-type="{{wijziging.heeftAfgerondHuiswerk ? \'ok\': \'information\'}}">Huiswerk</span>\r\n                    \r\n                                    <span data-ng-if="wijziging.heeftInformatie" class="agenda-text-icon outline" icon-type="information">Informatie</span>\r\n                                    \r\n                                    \x3c!--toetsen--\x3e\r\n                                    <span data-ng-if="wijziging.heeftProefwerk" class="text-icon" icon-type="information">Proefwerk</span>\r\n                                    <span data-ng-if="wijziging.heeftTussentijdseToets" class="text-icon" icon-type="information">Tentamen</span>\r\n                                    <span data-ng-if="wijziging.heeftSchriftelijkeOverhoring" class="text-icon" icon-type="information">SO</span>\r\n                                    <span data-ng-if="wijziging.heeftMondelingeOverhoring" class="text-icon" icon-type="information">MO</span>\r\n                                    <span data-ng-if="wijziging.isExamen" class="text-icon" icon-type="information">Examen</span>\r\n                                </div>\r\n                            </div>\r\n                        </a>\r\n                    </li>\r\n                </ul>\r\n            </div>\r\n        </div>\r\n        <footer class="endlink"><a href="#/agenda/week" title="">weekoverzicht</a></footer>\r\n    </div>\r\n</div>\r\n'
    },
    639: function(e, t, n) {
        "use strict";
        (function(e) {
            function i(t, i) {
                return {
                    template: n(640),
                    scope: {
                        dragstart: "&",
                        dragend: "&",
                        dropTrashcan: "&",
                        canDelete: "=",
                        widgets: "="
                    },
                    link: function(n, i, a) {
                        n.handleDragStart = function(e) {
                            var t = n.dragstart();
                            void 0 !== t && t(e)
                        }
                        ,
                        n.handleDragEnd = function(e) {
                            t(function() {
                                var t = n.dragend();
                                void 0 !== t && t(e)
                            }, 0)
                        }
                        ,
                        n.handleDrop = function(i) {
                            e.isDefined(n.canDelete) && n.canDelete && t(function() {
                                var e = n.dropTrashcan(i);
                                void 0 !== e && e(i)
                            }, 0)
                        }
                        ,
                        n.createHintElement = function(t) {
                            var n = e.element(document.createElement(t.get(0).tagName));
                            return n.html(t.html()),
                            n.width(t.context.clientWidth),
                            n.height(t.context.clientHeight),
                            n.attr("id", t.attr("id")),
                            n.attr("class", t.attr("class")),
                            n.addClass("widget-drag-hint"),
                            n
                        }
                    }
                }
            }
            n.d(t, "a", function() {
                return i
            })
        }
        ).call(this, n(1))
    },
    640: function(e, t) {
        e.exports = '<div class="widget available-widgets">\r\n    <div class="block">\r\n        <h3><b>Beschikbare widgets</b></h3>\r\n        <div class="content projects draggable">\r\n            <ul>\r\n                <li data-ng-repeat="widget in widgets"\r\n                    data-sm-drag-drop="{drag: true}"\r\n                    data-hint-element="createHintElement"\r\n                    data-dragstart="handleDragStart(widget)"\r\n                    data-dragend="handleDragEnd()" id="drag-available-{{$index}}"\r\n                    class="disable-selection">\r\n                    <span data-ng-class="widget.icon" class="widget-icon"></span>\r\n                    <span data-ng-bind="widget.Titel"></span>\r\n                </li>\r\n            </ul>\r\n            <div class="content recyclebin" ng-class="{\'candelete\': canDelete}" data-sm-drag-drop="{drop: true}" data-drag-enabled="editMode" data-drop="handleDrop">\r\n                <span class="icon-recyclebin"></span>\r\n            </div>\r\n        </div>\r\n        <footer class="endlink"></footer>\r\n    </div>\r\n</div>\r\n'
    },
    641: function(e, t, n) {
        "use strict";
        (function(e, i, a) {
            n.d(t, "a", function() {
                return l
            });
            var r = n(8)
              , s = n(5)
              , o = n(6)
              , c = n(11)
              , d = n(0)
              , l = function() {
                function t(t, n, a, r, s, o, c, d, l, g, f, u, p) {
                    var h = this;
                    this.$q = t,
                    this.$scope = n,
                    this.$rootScope = a,
                    this.$routeParams = r,
                    this.$timeout = s,
                    this.applicationService = o,
                    this.instellingService = c,
                    this.vandaagDefaults = d,
                    this.magisterLocale = l,
                    this.currentUser = g,
                    this.tabService = f,
                    this.schoolConfiguratieService = u,
                    this.profielResource = p,
                    this.VANDAAG_SCHERM_ALGEMEEN = "VANDAAG_SCHERM",
                    this.HIDE_TOUR_COOKIE = "HIDE_TOUR_COOKIE",
                    this.HIDE_INVALID_TIMEZONE = "HIDE_INVALID_TIMEZONE",
                    n.editMode = !1,
                    n.tabState = this.tabService.tabState,
                    this.tabService.subscribeTabAdded(this.tabAdded, this),
                    n.editButtonTitle = "schermindeling",
                    n.hideTour = this.applicationService.readSessionCookie(this.HIDE_TOUR_COOKIE) || globalSettings.featureFlags.hideProductTour,
                    n.hideInvalidTimezoneToast = this.applicationService.readSessionCookie(this.HIDE_INVALID_TIMEZONE),
                    this.applicationService.hideMessage(),
                    n.columns = [{
                        name: "column0",
                        order: 0
                    }, {
                        name: "column1",
                        order: 1
                    }, {
                        name: "column2",
                        order: 2
                    }],
                    n.$watch("hideTour", function() {
                        e.isDefined(n.hideTour) && h.applicationService.createSessionCookie(h.HIDE_TOUR_COOKIE, n.hideTour)
                    }),
                    this.showInvalidTimezoneToast(),
                    n.handleDrop = function(e) {
                        return h.handleDrop(e)
                    }
                    ,
                    n.dropTrash = function(e) {
                        return h.dropTrash(e)
                    }
                    ,
                    n.dragStartNewWidget = function(e) {
                        return h.handleDragStart(e)
                    }
                    ,
                    n.dragStartExistingWidget = function() {
                        n.canDelete = !0
                    }
                    ,
                    n.dragEndExistingWidget = function(e) {
                        n.canDelete = !1
                    }
                    ,
                    n.toggleEditMode = function() {
                        return h.toggleEditMode()
                    }
                    ,
                    n.closeOudersToestemmingDialog = function() {
                        n.toonOudersToestemmingDialog = !1
                    }
                    ,
                    n.toonOudersToestemmingDialog = !1,
                    n.createHintElement = function(t) {
                        var n = e.element(document.createElement(t.get(0).tagName));
                        return n.html(t.html()),
                        n.width(t.width()),
                        n.height(t.height()),
                        n.attr("id", t.attr("id")),
                        n.attr("class", t.attr("class")),
                        n.addClass("vandaag-drag-hint"),
                        n
                    }
                    ,
                    n.$on("widgetResized", function(e, t) {
                        i.each(n.columnedWidgets, function(e) {
                            i.each(e, function(e) {
                                e.Naam === t && n.$evalAsync(function() {
                                    e.widgetHigh = !e.widgetHigh
                                })
                            })
                        })
                    }),
                    this.getSettings(n)
                }
                return t.prototype.tabAdded = function(e) {
                    "idWidgets" === e.id && this.tabService.openTab(e)
                }
                ,
                t.prototype.getSettings = function(t) {
                    var n = this;
                    this.instellingService.get(this.currentUser.person.id, this.VANDAAG_SCHERM_ALGEMEEN).then(function(a) {
                        var r = a.widgets;
                        n.$scope.hideTourNextTime = !!a.hideTourNextTime,
                        n.$scope.hideTourNextTimeSetting = !!a.hideTourNextTime,
                        n.$scope.availableWidgets = [],
                        i.each(n.vandaagDefaults.vandaagSchermAlgemeen, function(e) {
                            var t = i.find(r, function(t) {
                                return t.Directive === e.Directive
                            });
                            Object(d.w)(t) && n.currentUser.isInRoles(e.roles, c.a.One) && n.$scope.availableWidgets.push(e),
                            Object(d.t)(t) && Object(d.w)(t.widgetHigh) && (t.widgetHigh = e.widgetHigh)
                        }),
                        r = n.applyGroepFilter(n.applyPrivileges(r)),
                        n.$scope.columnedWidgets = i.groupBy(r, function(e) {
                            return e.Positie.Kolom
                        }),
                        t.$watch("hideTourNextTime", function(a, r) {
                            a !== r && e.isDefined(t.hideTourNextTime) && n.saveSettings(i.flatten(i.toArray(n.$scope.columnedWidgets)))
                        }),
                        n.vraagToestemmingGegevensOuders().then(function(e) {
                            t.toonOudersToestemmingDialog = e
                        }),
                        n.$scope.areSettingsLoaded = !0
                    })
                }
                ,
                t.prototype.vraagToestemmingGegevensOuders = function() {
                    var e = this
                      , t = this.$q.defer()
                      , n = a()
                      , i = a(this.currentUser.person.birthday)
                      , r = i.clone();
                    return r = r.add("years", 18),
                    n.diff(i, "years") < 18 && r.diff(n, "months") <= 2 ? this.profielResource.get(this.currentUser.person.id).then(function(i) {
                        i.oudersMogenGegevensZien ? t.resolve(!1) : e.instellingService.get(e.currentUser.person.id, "toestemmingOudersMaanden").then(function(i) {
                            i && 3 === i.length ? (r.diff(n, "months") <= 2 && !i[2] || r.diff(n, "months") <= 1 && !i[1] || r.diff(n, "months") <= 0 && !i[0]) && t.resolve(!0) : e.instellingService.set(e.currentUser.person.id, "toestemmingOudersMaanden", [!1, !1, !1]).then(function() {
                                t.resolve(!0)
                            })
                        }).catch(function() {
                            t.resolve(!1)
                        })
                    }).catch(function() {
                        t.resolve(!1)
                    }) : t.resolve(!1),
                    t.promise
                }
                ,
                t.prototype.toggleEditMode = function() {
                    this.$scope.editMode = !this.$scope.editMode,
                    this.$scope.editMode ? this.tabService.tabState.tabContainerVisible = !0 : this.tabService.tabState.tabContainerVisible = !1,
                    this.$scope.editButtonTitle = this.$scope.editMode ? "opslaan" : "schermindeling",
                    this.$scope.editMode || (i.forEach(this.$scope.columnedWidgets, function(e) {
                        return i.forEach(e, function(e) {
                            return e.Draggable = !1
                        })
                    }),
                    this.saveSettings(i.flatten(i.toArray(this.$scope.columnedWidgets))),
                    this.$scope.columnedWidgets = e.copy(this.$scope.columnedWidgets))
                }
                ,
                t.prototype.handleDragStart = function(e) {
                    this.$scope.canDelete = !1,
                    this.currentWidget = e
                }
                ,
                t.prototype.dropTrash = function(t) {
                    var n = t.draggable.currentTarget.attr("id").split("-");
                    e.isArray(n) && 3 === n.length && this.$scope.availableWidgets.push(this.$scope.columnedWidgets[+n[1]][+n[2]]),
                    this.$scope.columnedWidgets[+n[1]].splice(+n[2], 1)
                }
                ,
                t.prototype.handleDrop = function(t) {
                    var n, a = t.dropTarget.attr("id"), r = t.draggable.currentTarget.attr("id"), s = !1, o = a.split("-"), c = [];
                    if (null != this.currentWidget && e.isDefined(this.currentWidget))
                        n = {
                            Titel: this.currentWidget.Titel,
                            Naam: this.currentWidget.Naam,
                            Directive: this.currentWidget.Directive,
                            Privilege: this.currentWidget.Privilege,
                            Positie: {
                                Kolom: +o[1],
                                Volgnummer: +o[2]
                            },
                            Draggable: !0,
                            icon: this.currentWidget.icon,
                            roles: this.currentWidget.roles
                        },
                        e.isDefined(this.$scope.columnedWidgets[+o[1]]) ? this.$scope.columnedWidgets[+o[1]].splice(+o[2], 0, n) : this.$scope.columnedWidgets[+o[1]] = [n],
                        this.$scope.availableWidgets = i.without(this.$scope.availableWidgets, this.currentWidget),
                        this.currentWidget = void 0;
                    else {
                        var d, l = r.split("-"), g = (d = "available" === l[1] ? this.$scope.availableWidgets : this.$scope.columnedWidgets[+l[1]])[+l[2]];
                        n = {
                            Titel: g.Titel,
                            Naam: g.Naam,
                            Directive: g.Directive,
                            Privilege: g.Privilege,
                            Positie: {
                                Kolom: g.Positie.Kolom,
                                Volgnummer: g.Positie.Volgnummer
                            },
                            Draggable: !0,
                            icon: g.icon,
                            roles: g.roles
                        },
                        d.splice(+l[2], 1);
                        var f = 0
                          , u = this.$scope.columnedWidgets[+o[1]];
                        i.forEach(u, function(e) {
                            !s && e.Positie.Volgnummer >= +o[2] && (n.Positie.Kolom = +o[1],
                            n.Positie.Volgnummer = f++,
                            c.push(n),
                            s = !0),
                            e.Positie.Volgnummer = f++,
                            c.push(e)
                        }),
                        s || (n.Positie.Kolom = +o[1],
                        n.Positie.Volgnummer = f,
                        c.push(n)),
                        this.$scope.columnedWidgets[+o[1]] = c
                    }
                }
                ,
                t.prototype.saveSettings = function(e) {
                    var t = {
                        widgets: e,
                        hideTourNextTime: this.$scope.hideTourNextTime,
                        versie: 1
                    };
                    this.instellingService.set(this.currentUser.person.id, this.VANDAAG_SCHERM_ALGEMEEN, t).then(function() {})
                }
                ,
                t.prototype.applyPrivileges = function(t) {
                    var n = this;
                    return i.filter(t, function(t) {
                        return !!e.isDefined(t.Privilege) && (n.currentUser.hasPrivilege(t.Privilege, o.a.Read) || t.Privilege === s.a.NoPrivilege)
                    })
                }
                ,
                t.prototype.showInvalidTimezoneToast = function() {
                    var t = this;
                    e.isUndefined(this.$scope.hideInvalidTimezoneToast) && (this.applicationService.createSessionCookie(this.HIDE_INVALID_TIMEZONE, !0),
                    this.schoolConfiguratieService.getSchoolinformatie().then(function(e) {
                        var n = -1 * e.OffsetLokaleTijdMetUTCInMinuten;
                        (new Date).getTimezoneOffset() !== n && t.applicationService.showMessage("Voor een goede werking van Magister moet het apparaat ingesteld zijn op de tijdzone '" + e.IANATijdZoneNaam + "'.", r.j.ERROR, 1e4, "Afwijkende tijdzone geconstateerd!")
                    }))
                }
                ,
                t.prototype.applyGroepFilter = function(t) {
                    var n = this;
                    return i.filter(t, function(t) {
                        if (!e.isDefined(t.roles)) {
                            var a = i.find(n.vandaagDefaults.vandaagSchermAlgemeen, function(e) {
                                return t.Directive === e.Directive && t.Titel === e.Titel
                            });
                            Object(d.w)(a) || (t.roles = a.roles)
                        }
                        return n.currentUser.isInRoles(t.roles, c.a.One)
                    })
                }
                ,
                t.$inject = ["$q", "$scope", "$rootScope", "$routeParams", "$timeout", "applicationService", "instellingService", "vandaagDefaults", "magisterLocale", "currentUser", "tabService", "schoolConfiguratieService", "profielResource"],
                t
            }()
        }
        ).call(this, n(1), n(3), n(14))
    }
}]);
