window.globalSettings = {
  apiKey: '4AF1',
  apiKeyHeader: 'API-Client-ID',
  apiHost: window.location.origin + '/',
  applicationLoUrl: '/magister',
  applicationOpUrl: '/op',
  clientVersion: '6.2.13',
  modgisterBuild: '9001',
  modgisterRelease: '1.2',
  deviceType: 'desktop',
  featureFlags: {
      m6LoggingEnabled: false,
      hideProductTour: true,
      plagiaatCDS: true
  },
  kennisnetLogin: true,
  showOnedriveConnectionWarning: true,
};
