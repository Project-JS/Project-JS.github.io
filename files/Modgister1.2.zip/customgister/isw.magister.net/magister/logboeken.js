(window.webpackJsonp = window.webpackJsonp || []).push([[9], {
    584: function(e, t, o) {
        "use strict";
        o.r(t),
        function(e) {
            o.d(t, "logboekenAMD", function() {
                return s
            });
            var r = o(585)
              , n = o(586)
              , i = o(587)
              , c = o(645)
              , a = o(589)
              , l = o(590)
              , s = e.module("LogboekenAMD", ["ngResource"]);
            s.service("logboekResource", r.a.$inject).service("logboekenResource", n.a.$inject).service("logboekenService", i.a.$inject).service("logboekenFactory", c.a.$inject),
            s.filter("bronIconContentType", l.a.prototype.bronIconContentType).filter("getBronTypeFromContentType", l.a.prototype.getBronTypeFromContentType),
            s.controller("logboekenController", a.a.$inject)
        }
        .call(this, o(1))
    },
    585: function(e, t, o) {
        "use strict";
        o.d(t, "a", function() {
            return n
        });
        var r = o(0)
          , n = function() {
            function e(e) {
                this.$resource = e,
                this.apiHost = globalSettings.apiHost
            }
            return e.prototype.getCollectionWithLink = function(e) {
                return this.$resource(this.apiHost + e, {}, {
                    execute: {
                        method: "GET"
                    }
                }).execute({}).$promise
            }
            ,
            e.prototype.getWithLink = function(e) {
                return this.$resource(this.apiHost + e, {}, {
                    execute: {
                        method: "GET"
                    }
                }).execute({}).$promise
            }
            ,
            e.prototype.get = function(e, t) {
                return void 0 === t && (t = "self"),
                this.$resource(this.apiHost + this.getSoortLink(e, t), {}, {
                    execute: {
                        method: "GET"
                    }
                }).execute({}).$promise
            }
            ,
            e.prototype.getSoortLink = function(e, t) {
                return this.getLink(Object(r.k)(e.links, t))
            }
            ,
            e.prototype.getLink = function(e) {
                return Object(r.u)(e) || 0 !== e.indexOf("/") || (e = e.substring(1, e.length)),
                e
            }
            ,
            e.$inject = ["$resource", e],
            e
        }()
    },
    586: function(e, t, o) {
        "use strict";
        o.d(t, "a", function() {
            return n
        });
        var r = o(0)
          , n = function() {
            function e(e) {
                this.$resource = e,
                this.apiHost = globalSettings.apiHost,
                this.baseUrl = "api/leerlingen/:persoonId/logboeken"
            }
            return e.prototype.get = function(e, t, o) {
                if (!Object(r.v)(e))
                    return this.getCollection(e, this.baseUrl);
                var n = this.getCollectionLink(t, o);
                return this.getCollection(null, n)
            }
            ,
            e.prototype.getCollection = function(e, t) {
                return this.$resource(this.apiHost + this.getLink(t), {
                    persoonId: e
                }, {
                    execute: {
                        method: "GET"
                    }
                }).execute().$promise
            }
            ,
            e.prototype.getCollectionLink = function(e, t) {
                return this.getLink(Object(r.k)(e, t))
            }
            ,
            e.prototype.getLink = function(e) {
                return Object(r.u)(e) || 0 !== e.indexOf("/") || (e = e.substring(1, e.length)),
                e
            }
            ,
            e.$inject = ["$resource", e],
            e
        }()
    },
    587: function(e, t, o) {
        "use strict";
        o.d(t, "a", function() {
            return r
        });
        var r = function() {
            function e(e, t, o, r, n) {
                this.$q = e,
                this.$http = t,
                this.cacheService = o,
                this.logboekResource = r,
                this.logboekenResource = n,
                this.logboekformulierenCacheKey = "logboekformulieren"
            }
            return e.prototype.getLogboekformulieren = function(e) {
                var t = this
                  , o = this.cacheService.get(this.logboekformulierenCacheKey);
                return o ? this.$q.resolve(o) : this.$http.get(e).then(function(e) {
                    return t.cacheService.put(t.logboekformulierenCacheKey, e.data),
                    e.data
                })
            }
            ,
            e.prototype.getLogboekformulierDetail = function(e) {
                var t = this
                  , o = this.cacheService.get(e);
                return o ? this.$q.resolve(o) : this.$http.get(e).then(function(o) {
                    return t.cacheService.put(e, o.data),
                    o.data
                })
            }
            ,
            e.prototype.getFormulierType = function(e) {
                var t = this
                  , o = this.cacheService.get(e);
                return o ? this.$q.resolve(o) : this.$http.get(e).then(function(o) {
                    return t.cacheService.put(e, o.data),
                    o.data
                })
            }
            ,
            e.prototype.getLogboekformulierBijlage = function(e) {
                var t = this
                  , o = this.cacheService.get(e);
                return o ? this.$q.resolve(o) : this.$http.get(e).then(function(o) {
                    return t.cacheService.put(e, o.data),
                    o.data
                })
            }
            ,
            e.$inject = ["$q", "$http", "cacheService", "logboekResource", "logboekenResource", e],
            e
        }()
    },
    588: function(e, t, o) {
        "use strict";
        (function(e) {
            o.d(t, "a", function() {
                return r
            });
            var r = function() {
                function t(e, t, o) {
                    this.$q = e,
                    this.logboekenService = t,
                    this.logboekFactory = o,
                    this.inhoudTonen = !1,
                    this.magOmschrijvingWijzigen = !1,
                    this.magRechtenWijzigen = !1,
                    this.moetRechtenStandaardAanzetten = !1,
                    this.layout = []
                }
                return t.prototype.hasOptie = function(e) {
                    return (this.opties & e) === e
                }
                ,
                t.prototype.load = function(e) {
                    var t = this;
                    return this.logboekenService.getFormulierType(e).then(function(e) {
                        t.id = e.id,
                        t.opties = e.opties,
                        t.naam = e.naam,
                        t.omschrijving = e.omschrijving,
                        t.inhoudTonen = t.hasOptie(16),
                        t.magOmschrijvingWijzigen = t.hasOptie(1),
                        t.magRechtenWijzigen = t.hasOptie(4),
                        t.moetRechtenStandaardAanzetten = t.hasOptie(32),
                        t.setLayout(e.layout)
                    })
                }
                ,
                t.prototype.setLayout = function(t) {
                    var o = this;
                    t && t[0] && e.each(t[0].properties, function(e) {
                        var t = o.addControl(e);
                        o.layout.push(t)
                    })
                }
                ,
                t.prototype.addControl = function(t) {
                    var o, r = this;
                    switch (t.type) {
                    case "Bedrag":
                        o = this.logboekFactory.createFormulierBedragModel(t);
                        break;
                    case "Bestand":
                        o = this.logboekFactory.createFormulierBestandModel(t);
                        break;
                    case "Datum":
                        o = this.logboekFactory.createFormulierDatumModel(t);
                        break;
                    case "Getal":
                        o = this.logboekFactory.createFormulierGetalModel(t);
                        break;
                    case "Geen":
                    case "Groep":
                        o = this.logboekFactory.createFormulierGroepModel(t),
                        e.each(t.properties, function(e) {
                            o.properties.push(r.addControl(e))
                        });
                        break;
                    case "Keuzelijst":
                        o = this.logboekFactory.createFormulierKeuzelijstModel(t);
                        break;
                    case "Logisch":
                        o = this.logboekFactory.createFormulierLogischModel(t);
                        break;
                    case "LookupC":
                        o = this.logboekFactory.createFormulierLookupModel(t);
                        break;
                    case "Tekst":
                        o = this.logboekFactory.createFormulierTekstModel(t);
                        break;
                    case "Tijd":
                        o = this.logboekFactory.createFormulierTijdModel(t);
                        break;
                    case "Lookup":
                        o = this.logboekFactory.createFormulierLookupModel(t);
                        break;
                    case "Memo":
                        o = this.logboekFactory.createFormulierMemoModel(t)
                    }
                    return o.datafield = t.datafield,
                    o
                }
                ,
                t
            }()
        }
        ).call(this, o(3))
    },
    589: function(e, t, o) {
        "use strict";
        (function(e) {
            o.d(t, "a", function() {
                return n
            });
            var r = o(0)
              , n = function() {
                function t(e, t, o, r, n, i, c, a) {
                    this.$rootScope = e,
                    this.$scope = t,
                    this.$routeParams = o,
                    this.$timeout = r,
                    this.currentUser = n,
                    this.lesperiodeService = i,
                    this.logboekenService = c,
                    this.logboekenFactory = a,
                    this.gelezenFilterOptions = ["gelezen/ongelezen", "ongelezen"],
                    this.logboekenTreeData = new kendo.data.HierarchicalDataSource({
                        schema: {
                            model: {
                                id: "data.id",
                                hasChildren: "hasChildren"
                            }
                        },
                        sort: {
                            field: "data.aangemaaktOp",
                            dir: "desc"
                        }
                    }),
                    this.selectedGelezenFilter = this.gelezenFilterOptions[0]
                }
                return t.prototype.onSelectLogboek = function() {
                    var e = this;
                    return function(t) {
                        var o = e.$scope.logboekenTree.dataItem(t.node);
                        Object(r.t)(e.selectedLogboekNode) && e.selectedLogboekNode.id !== o.id && e.setLogboekGelezen(e.selectedLogboekNode),
                        e.getLogboekDetail(o)
                    }
                }
                ,
                t.prototype.onSelectGelezenFilter = function(e) {
                    this.setLogboekGelezen(this.selectedLogboekNode);
                    var t = e.sender.value();
                    this.filterTreeData(t)
                }
                ,
                t.prototype.setLogboekGelezen = function(e) {
                    Object(r.t)(e) && (e.data.isGelezen = !0,
                    e.alert = this.getLogboekNodeAlert(e))
                }
                ,
                t.prototype.filterTreeData = function(e, t) {
                    void 0 === t && (t = !0);
                    var o = {
                        field: "alert",
                        operator: "neq"
                    };
                    switch (e) {
                    case this.gelezenFilterOptions[0]:
                        o = null;
                        break;
                    case this.gelezenFilterOptions[1]:
                        o.value = !1;
                        break;
                    default:
                        o = null
                    }
                    if (this.logboekenTreeData.filter(o),
                    t) {
                        var r = this.getFirstInView();
                        this.selectLogboekNode(r)
                    }
                }
                ,
                t.prototype.onLogboekenTreeDataBound = function() {
                    var e = this
                      , t = !1;
                    return function() {
                        t || (e.lesperiodeService.getLesperioden().then(function() {
                            var t = (new Date).getFullYear()
                              , o = t - 10 + "-01-01"
                              , n = t + 1 + "-07-31";
                            e.logboekenService.getLogboekformulieren("/api/leerlingen/" + e.currentUser.relatedPersons.current.id + "/lvs/logboekformulieren?begin=" + o + "&einde=" + n).then(function(t) {
                                e.logboeken = t.items,
                                e.createTree(),
                                e.$rootScope.$broadcast("lvs", "lvs");
                                var o = e.$routeParams.ongelezen;
                                Object(r.t)(o) && ("true" === o.toString().toLowerCase() && (e.selectedGelezenFilter = e.gelezenFilterOptions[1]));
                                e.filterTreeData(e.selectedGelezenFilter)
                            })
                        }),
                        t = !0)
                    }
                }
                ,
                t.prototype.selectLogboekNode = function(e) {
                    var t = this;
                    Object(r.t)(this.selectedLogboekNode) && this.selectedLogboekNode.set("selected", !1),
                    this.$timeout(function() {
                        t.selectedLogboekNode = e,
                        Object(r.t)(e) ? (e.set("selected", !0),
                        t.getLogboekDetail(e)) : t.selectedLogboekDetails = null
                    }, 0, !0)
                }
                ,
                t.prototype.getLogboekDetail = function(e) {
                    this.selectedLogboekNode = e,
                    this.selectedLogboekDetails = this.logboekenFactory.createLogboekformulierDetailModel(),
                    this.selectedLogboekDetails.load(e.data.links.self.href)
                }
                ,
                t.prototype.createTree = function(t) {
                    var o, r = this;
                    if (void 0 === t && (t = 0),
                    0 === t)
                        o = this.getLogboekChildNodes();
                    else {
                        var n = this.getTreeNode(t);
                        o = this.getLogboekChildNodes(n)
                    }
                    e.each(o, function(e) {
                        if (0 === t)
                            r.logboekenTreeData.add(e);
                        else if (r.getTreeNode(t).append(e),
                        !0 === e.alert) {
                            var o = r.getTreeNode(e.data.id);
                            r.setParentAlert(o, !0)
                        }
                        r.createTree(e.data.id)
                    })
                }
                ,
                t.prototype.setParentAlert = function(e, t) {
                    var o = e.parentNode();
                    Object(r.t)(o) && (o.alert = !0,
                    this.setParentAlert(o, t))
                }
                ,
                t.prototype.getTreeNode = function(e) {
                    return this.logboekenTreeData.get(e)
                }
                ,
                t.prototype.getLogboekChildNodes = function(t) {
                    var o = this
                      , n = []
                      , i = 0;
                    return Object(r.t)(t) && (i = t.data.id),
                    0 === i && e.each(this.logboeken, function(t) {
                        0 !== t.bovenliggendeId && (e.any(o.logboeken, function(e) {
                            return t.bovenliggendeId === e.id
                        }) || n.push(t))
                    }),
                    e.chain(this.logboeken).where({
                        bovenliggendeId: i
                    }).union(n).map(function(e) {
                        return {
                            data: e,
                            hasChildren: !1,
                            alert: !e.isGelezen
                        }
                    }).value()
                }
                ,
                t.prototype.expandTreeNode = function(e) {
                    Object(r.t)(this.selectedLogboekNode) && this.selectedLogboekNode.id === e.id && e.set("expanded", !e.expanded)
                }
                ,
                t.prototype.getLogboekNodeAlert = function(e, t, o) {
                    if (!0 === e.hasChildren)
                        for (var n = e.children.data(), i = 0; i < n.length; i++) {
                            var c = n[i];
                            if (!0 === c.alert && c.id !== t && (Object(r.w)(o) || c.id !== o.id))
                                return !0
                        }
                    return this.setNodeAlert(e, t),
                    !1
                }
                ,
                t.prototype.setNodeAlert = function(e, t) {
                    e.hasChildren || e.id !== t || (e.alert = !1);
                    var o = e.parentNode();
                    Object(r.t)(o) && !0 === o.data.isGelezen && (o.alert = this.getLogboekNodeAlert(o, t || e.id, e))
                }
                ,
                t.prototype.getFirstInView = function() {
                    if (Object(r.t)(this.logboekenTreeData)) {
                        var e = this.logboekenTreeData.view();
                        if (Object(r.t)(e))
                            return e[0]
                    }
                    return null
                }
                ,
                t.$inject = ["$rootScope", "$scope", "$routeParams", "$timeout", "currentUser", "lesperiodeService", "logboekenService", "logboekenFactory", t],
                t
            }()
        }
        ).call(this, o(3))
    },
    590: function(e, t, o) {
        "use strict";
        o.d(t, "a", function() {
            return r
        });
        var r = function() {
            function e() {}
            return e.prototype.bronIconContentType = function() {
                return function(t) {
                    return e.findLabelInHashTable(e.contentTypeHash, t, e.BronIcon.overig)
                }
            }
            ,
            e.prototype.getBronTypeFromContentType = function() {
                return function(t) {
                    return e.findLabelInHashTable(e.contentTypeStringHash, t, "document")
                }
            }
            ,
            e.findLabelInHashTable = function(e, t, o) {
                if (null == t)
                    return o;
                for (var r in e)
                    if (t.indexOf(r) > -1)
                        return e[r];
                return o
            }
            ,
            e.BronIcon = {
                image: "ico-file-image",
                video: "ico-play-circle",
                audio: "ico-audio-file",
                text: "ico-file-text",
                zip: "ico-file-zip",
                folder: "ico-folder",
                url: "ico-link",
                word: "ico-file-word",
                pdf: "ico-file-pdf",
                excel: "ico-excel-file",
                xml: "ico-xml-file",
                powerpoint: "ico-powerpoint-file",
                overig: "ico-file",
                opdracht: "ico-edit-document"
            },
            e.contentTypeHash = {
                video: e.BronIcon.video,
                image: e.BronIcon.image,
                audio: e.BronIcon.audio,
                zip: e.BronIcon.zip,
                word: e.BronIcon.word,
                pdf: e.BronIcon.pdf,
                excel: e.BronIcon.excel,
                spreadsheet: e.BronIcon.excel,
                xml: e.BronIcon.xml,
                powerpoint: e.BronIcon.powerpoint,
                text: e.BronIcon.text
            },
            e.contentTypeStringHash = {
                video: "video",
                image: "afbeelding",
                audio: "audio",
                zip: "zip",
                word: "word",
                pdf: "pdf",
                excel: "excel",
                spreadsheet: "excel",
                xml: "video",
                powerpoint: "powerpoint",
                text: "text"
            },
            e
        }()
    },
    645: function(e, t, o) {
        "use strict";
        var r, n = o(588), i = (r = Object.setPrototypeOf || {
            __proto__: []
        }instanceof Array && function(e, t) {
            e.__proto__ = t
        }
        || function(e, t) {
            for (var o in t)
                t.hasOwnProperty(o) && (e[o] = t[o])
        }
        ,
        function(e, t) {
            function o() {
                this.constructor = e
            }
            r(e, t),
            e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype,
            new o)
        }
        ), c = function() {
            return function(e) {
                this.type = "",
                this.titel = e.titel,
                this.required = !!e.required && e.required
            }
        }(), a = function() {
            return function(e) {
                this.type = "groep",
                this.properties = [],
                this.caption = e.caption,
                this.showcaption = e.showcaption
            }
        }(), l = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.type = "bedrag",
                t
            }
            return i(t, e),
            t
        }(c), s = function(e) {
            function t(t, o) {
                var r = e.call(this, o) || this;
                return r.logboekenService = t,
                r.properties = o,
                r.type = "bestand",
                r
            }
            return i(t, e),
            t.prototype.getFormulierBijlage = function(e) {
                return this.logboekenService.getLogboekformulierBijlage(e)
            }
            ,
            t
        }(c), u = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.type = "datum",
                t
            }
            return i(t, e),
            t
        }(c), p = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.type = "getal",
                t
            }
            return i(t, e),
            t
        }(c), h = function(e) {
            function t(t, o) {
                var r = e.call(this, o) || this;
                return r.logboekenService = t,
                r.properties = o,
                r.type = "keuzelijst",
                r.links = o.links,
                r
            }
            return i(t, e),
            t
        }(c), d = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.type = "logisch",
                t
            }
            return i(t, e),
            t
        }(c), g = function(e) {
            function t(t) {
                var o = e.call(this, t) || this;
                return o.properties = t,
                o.type = "lookup",
                o.links = t.links,
                o.readonly = !!t.readonly && t.readonly,
                o
            }
            return i(t, e),
            t.prototype.getLookupLijst = function(e) {}
            ,
            t
        }(c), f = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.type = "memo",
                t
            }
            return i(t, e),
            t
        }(c), b = function(e) {
            function t(t) {
                var o = e.call(this, t) || this;
                return o.type = "tekst",
                o.maxLengte = t.lengte,
                o
            }
            return i(t, e),
            t
        }(c), k = function(e) {
            function t() {
                var t = null !== e && e.apply(this, arguments) || this;
                return t.type = "tijd",
                t
            }
            return i(t, e),
            t
        }(c), y = function() {
            function e(e, t, o) {
                this.$q = e,
                this.logboekFactory = t,
                this.logboekenService = o
            }
            return e.prototype.load = function(e) {
                var t = this;
                return this.logboekenService.getLogboekformulierDetail(e).then(function(e) {
                    return t.id = e.id,
                    t.bovenliggendeId = e.bovenliggendeId,
                    t.eigenaar = e.eigenaar,
                    t.inhoud = e.inhoud && e.inhoud.length > 0 ? e.inhoud : "-",
                    t.aangemaaktOp = e.aangemaaktOp,
                    t.gewijzigdOp = e.gewijzigdOp,
                    t.verlooptOp = e.verlooptOp,
                    t.omschrijving = e.omschrijving,
                    t.isGelezen = e.isGelezen,
                    t.isGeautoriseerd = e.isGeautoriseerd,
                    t.heeftPrioriteit = e.heeftPrioriteit,
                    t.isAfgerond = e.isAfgerond,
                    t.soort = e.soort,
                    t.waarden = e.waarden,
                    t.formulier = t.logboekFactory.createFormulierModel(),
                    t.links = {
                        type: e.links.type
                    },
                    t.formulier.load(e.links.type.href).then(function() {
                        t.initRootGroep()
                    })
                })
            }
            ,
            e.prototype.initRootGroep = function() {
                this.formulier.layout.length > 0 && (this.rootGroep = "groep" === this.formulier.layout[0].type)
            }
            ,
            e
        }();
        o.d(t, "a", function() {
            return v
        });
        var v = function() {
            function e(e, t) {
                this.$q = e,
                this.logboekenService = t
            }
            return e.prototype.createFormulierGroepModel = function(e) {
                return new a(e)
            }
            ,
            e.prototype.createFormulierBedragModel = function(e) {
                return new l(e)
            }
            ,
            e.prototype.createFormulierBestandModel = function(e) {
                return new s(this.logboekenService,e)
            }
            ,
            e.prototype.createFormulierDatumModel = function(e) {
                return new u(e)
            }
            ,
            e.prototype.createFormulierGetalModel = function(e) {
                return new p(e)
            }
            ,
            e.prototype.createFormulierKeuzelijstModel = function(e) {
                return new h(this.logboekenService,e)
            }
            ,
            e.prototype.createFormulierLogischModel = function(e) {
                return new d(e)
            }
            ,
            e.prototype.createFormulierLookupModel = function(e) {
                return new g(e)
            }
            ,
            e.prototype.createFormulierMemoModel = function(e) {
                return new f(e)
            }
            ,
            e.prototype.createFormulierTekstModel = function(e) {
                return new b(e)
            }
            ,
            e.prototype.createFormulierTijdModel = function(e) {
                return new k(e)
            }
            ,
            e.prototype.createFormulierModel = function() {
                return new n.a(this.$q,this.logboekenService,this)
            }
            ,
            e.prototype.createLogboekformulierDetailModel = function() {
                return new y(this.$q,this,this.logboekenService)
            }
            ,
            e.$inject = ["$q", "logboekenService", e],
            e
        }()
    }
}]);
