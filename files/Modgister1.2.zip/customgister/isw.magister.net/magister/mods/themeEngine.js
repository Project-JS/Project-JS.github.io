function setCookie(cname,cvalue,exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
  var expires = "expires=" + d.toGMTString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function loadTheme() {
  var theme=getCookie("themename");
  if (theme != "") {
    LoadCSS("./themes/" + theme + ".css")
  } else {
    alert("Er is een thema nodig om Modgister te gebruiken.\nEen thema bepaalt hoe alles in Modgister eruit ziet.")
     theme = prompt("Voer de naam van de thema in:","mint");
     if (theme != "" && theme != null) {
       setCookie("themename", theme, 30);
       location.reload();
     }
  }
}

function LoadCSS( cssURL ) {
    return new Promise( function( resolve, reject ) {
        var link = document.createElement( 'link' );
        link.rel  = 'stylesheet';
        link.href = cssURL;
        document.head.appendChild( link );
       link.onerror = function() {
            LoadCSS("./fallback.MGtheme");
            alert("Er is iets misgegaan tijdens het laden van de thema.\nControleer op spelfouten of kies een andere thema.");
            switchtheme();
};
        link.onload = function() { 
            resolve(); 
            console.log('Theme Loaded!'); 
        };
    } );
}

function switchtheme() {
  theme = prompt("Voer de naam van de thema in:","");
  if (theme != "" && theme != null) {
       setCookie("themename", theme, 30);
  location.reload();
}
}