(window.webpackJsonp = window.webpackJsonp || []).push([[4], {
    461: function(e, t, i) {
        "use strict";
        i.r(t),
        function(e) {
            i.d(t, "berichtenAMD", function() {
                return r
            });
            var n = i(462)
              , r = e.module("BerichtenAMD", []);
            r.controller("BerichtenController", n.a.$inject)
        }
        .call(this, i(1))
    },
    462: function(e, t, i) {
        "use strict";
        (function(e) {
            i.d(t, "a", function() {
                return s
            });
            var n, r = i(463), o = (n = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var i in t)
                    t.hasOwnProperty(i) && (e[i] = t[i])
            }
            ,
            function(e, t) {
                function i() {
                    this.constructor = e
                }
                n(e, t),
                e.prototype = null === t ? Object.create(t) : (i.prototype = t.prototype,
                new i)
            }
            ), s = function(t) {
                function i(i, n, r, o, s, c) {
                    var a = t.call(this, i, n, r) || this;
                    return a.$window = i,
                    a.$scope = n,
                    a.applicationService = o,
                    a.instellingService = s,
                    a.currentUser = c,
                    a.HIDE_TOUR_COOKIE = "HIDE_TOUR_COOKIE",
                    a.VANDAAG_SCHERM_ALGEMEEN = "VANDAAG_SCHERM",
                    a.currentUser.noConsentWithBerichten && (n.hideTour = a.applicationService.readSessionCookie(a.HIDE_TOUR_COOKIE),
                    n.hideTourNextTime = !1,
                    n.$watch("hideTour", function() {
                        e.isDefined(n.hideTour) && a.applicationService.createSessionCookie(a.HIDE_TOUR_COOKIE, n.hideTour)
                    }),
                    a.getSettings()),
                    a
                }
                return o(i, t),
                i.prototype.getSettings = function() {
                    var t = this;
                    this.instellingService.get(this.currentUser.person.id, this.VANDAAG_SCHERM_ALGEMEEN).then(function(i) {
                        t.$scope.hideTourNextTime = !!i.hideTourNextTime,
                        t.$scope.hideTourNextTimeSetting = !!i.hideTourNextTime,
                        t.$scope.$watch("hideTourNextTime", function(i, n) {
                            i !== n && e.isDefined(t.$scope.hideTourNextTime) && t.saveSettings()
                        }),
                        t.$scope.areSettingsLoaded = !0
                    })
                }
                ,
                i.prototype.saveSettings = function() {
                    var e = {
                        widgets: [],
                        hideTourNextTime: this.$scope.hideTourNextTime,
                        versie: 1
                    };
                    this.instellingService.set(this.currentUser.person.id, this.VANDAAG_SCHERM_ALGEMEEN, e).then(function() {})
                }
                ,
                i.$inject = ["$window", "$scope", "unreadMessageService", "applicationService", "instellingService", "currentUser", i],
                i
            }(r.a)
        }
        ).call(this, i(1))
    },
    463: function(e, t, i) {
        "use strict";
        i.d(t, "a", function() {
            return n
        });
        var n = function() {
            function e(e, t, i) {
                var n = this;
                this.$window = e,
                this.$scope = t,
                this.unreadMessageService = i,
                this.messageEventHandler = function(e) {
                    return n.handleGuestMessage(e)
                }
                ,
                this.$window.addEventListener("message", this.messageEventHandler),
                this.$scope.$on("$destroy", function() {
                    n.$window.removeEventListener("message", n.messageEventHandler)
                })
            }
            return e.prototype.handleGuestMessage = function(e) {
                if (e.origin === this.$window.location.origin && e.data && "string" == typeof e.data.type)
                    switch (e.data.type) {
                    case "Number of unread messages":
                        this.unreadMessageService.setUnread(e.data.count)
                    }
            }
            ,
            e
        }()
    }
}]);
