(window.webpackJsonp = window.webpackJsonp || []).push([[5], {
    109: function(e, n) {
        e.exports = '<div class="new-message-block"> \x3c!--TODO: andere class naam--\x3e\r\n    <ul>\r\n        <li class="text-input">\r\n            <label for="Naam">Naam </label>\r\n            <input type="text" required="required" data-ng-model="vm.caption" data-ng-class="{\'invalid-field\': vm.captionIsInValid}" />\r\n        </li>\r\n        <li class="text-input">\r\n            <label for="Naam">Url </label>\r\n            <input type="text" required="required" data-ng-model="vm.url" data-ng-class="{\'invalid-field\': vm.urlIsInValid}" />\r\n        </li>\r\n    </ul>\r\n</div>'
    },
    501: function(e, n, t) {
        "use strict";
        t.r(n),
        function(e) {
            t.d(n, "bronnenAMD", function() {
                return h
            });
            var r = t(96)
              , i = t(93)
              , o = t(502)
              , a = t(125)
              , s = t(503)
              , c = t(504)
              , d = t(506)
              , l = t(508)
              , p = t(510)
              , u = t(511)
              , h = e.module("BronnenAMD", []);
            h.service("utilitiesResource", o.a.$inject).service("oneDriveForBusinessResource", r.a.$inject).service("fileUploadService", p.a.$inject).service("internalDragDropService", u.a.$inject).service("utilitiesService", a.a.$inject).service("bronHelper", i.a.$inject),
            h.directive("smMappenDirective", c.a).directive("smBestandenDirective", d.a).directive("smPermissiesPanelDirective", l.a),
            h.controller("bronnenOverzichtController", s.a.$inject)
        }
        .call(this, t(1))
    },
    502: function(e, n, t) {
        "use strict";
        t.d(n, "a", function() {
            return r
        });
        var r = function() {
            function e(e, n) {
                this.$resource = e,
                this.downloadTokenService = n,
                this.utilitiesUrl = globalSettings.apiHost + "api/leerlingen/leermiddelen/extern",
                this.utilityRedirectUrl = globalSettings.apiHost + "api/leerlingen/leermiddelen/extern/:utilityId/redirect"
            }
            return e.prototype.get = function() {
                return this.$resource(this.utilitiesUrl, {}, {
                    execute: {
                        method: "GET",
                        isArray: !0
                    }
                }).execute({}).$promise
            }
            ,
            e.prototype.redirect = function(e) {
                this.downloadTokenService.openTabToLocation(this.utilityRedirectUrl.replace(new RegExp(":utilityId"), e.toString()))
            }
            ,
            e.$inject = ["$resource", "downloadTokenService", e],
            e
        }()
    },
    503: function(e, n, t) {
        "use strict";
        (function(e, r, i) {
            t.d(n, "a", function() {
                return f
            });
            var o = t(5)
              , a = t(8)
              , s = t(85)
              , c = t(89)
              , d = t(124)
              , l = t(6)
              , p = t(86)
              , u = t(0)
              , h = Contracts.Bronnen
              , m = Contracts.Bronnen.Enums.BronType
              , f = function() {
                function n(n, t, r, i, a, s, c, p, u, h, m, f, v, g, b, I) {
                    var B = this;
                    this.$scope = n,
                    this.$q = t,
                    this.$timeout = r,
                    this.$filter = i,
                    this.bronnenService = a,
                    this.dialogService = s,
                    this.applicationService = c,
                    this.currentUser = p,
                    this.settingsService = u,
                    this.fileUploadService = h,
                    this.internalDragDropService = m,
                    this.folderValidator = f,
                    this.magisterLocale = v,
                    this.profielService = g,
                    this.utilitiesService = b,
                    this.downloadTokenService = I,
                    this.BRON_TYPE_MAP = 255,
                    this.KENNISNET_ID = -1e3,
                    this.useRecycleBin = !0,
                    this.heeftSchrijfRechten = this.currentUser.hasPrivilege(o.a.Bronnen, l.a.Create),
                    this.$scope.bibliothekenFolder = a.createFolder("Bibliotheken", -1),
                    this.$scope.bibliothekenFolder.map.Id = 0;
                    var y = a.createFolder("Hulpprogramma's", 0)
                      , w = [];
                    b.getUtilities().then(function(n) {
                        e.each(n, function(e) {
                            var n = a.createFolder(e.titel, 0);
                            n.map.Id = B.createUtilityId(e.id),
                            n.parent = y,
                            w.push(n)
                        })
                    });
                    var $ = a.createFolder("Kennisnet", 0);
                    $.map.Id = this.KENNISNET_ID,
                    $.parent = y,
                    w.push($),
                    y.mappen = w,
                    this.$scope.hulpprogrammasRootBron = y,
                    this.$scope.urlAanmaken = function() {
                        return B.openUrlAanmakenDialog()
                    }
                    ,
                    this.$scope.clickFileUpload = function() {
                        return B.clickFileUpload(B.$scope)
                    }
                    ,
                    this.$scope.bronHernoemen = function() {
                        return B.openBronHernoemenDialog()
                    }
                    ,
                    this.$scope.viewOnChange = function(e) {
                        return B.updateBronnenView(B.$scope, e.sender.value())
                    }
                    ;
                    var S = {
                        size: this.$scope.sizeOption
                    };
                    this.getUserSettings(this.$scope, S),
                    this.profielService.oneDriveForBusinessGekoppeld().then(function(e) {
                        B.$scope.oneDriveForBusinessCoupled = e.isCoupled,
                        B.$scope.oneDriveForBusinessEnabled = e.isEnabled
                    }),
                    this.getBronnen(null, null).then(function(e) {
                        e.length > 0 && B.onSelectedMapChanged(B.$scope.bibliothekenFolder.mappen[0], B.$scope.treeViewHasFocus)
                    }),
                    n.verwijderBron = function() {
                        return B.showVerwijderBronDialog(B.getFocusedBron())
                    }
                    ,
                    n.downloadBron = function() {
                        return B.downloadBron(B.getFocusedBron())
                    }
                    ,
                    n.haalKennisnetDienstenOp = function() {
                        return B.getKennisnetDiensten(B.$scope.selectedMap)
                    }
                    ,
                    n.bronnenTab = d.a.Weergave,
                    n.bronnenTabTitle = this.getBronnenTabTitle(d.a.Weergave),
                    n.changeTab = function(e) {
                        n.bronnenTab = e,
                        n.bronnenTabTitle = B.getBronnenTabTitle(e),
                        B.openTabContainer()
                    }
                    ,
                    n.closeTabContainer = this.closeTabContainer,
                    n.isVideo = !0,
                    n.videoSource = "",
                    n.treeViewHasFocus = !0,
                    n.handleKeyboardEvent = function(e) {
                        return B.handleKeyboardEvent(e)
                    }
                    ,
                    n.getPrivilegeNaam = function() {
                        return B.getPrivilegeNaam()
                    }
                    ,
                    n.sizeOptions = [{
                        name: "Klein",
                        value: "klein"
                    }, {
                        name: "Normaal",
                        value: "normaal"
                    }, {
                        name: "Groot",
                        value: "groot"
                    }],
                    n.sizeOption = n.sizeOptions[1],
                    n.viewOptions = [{
                        name: "Lijst",
                        type: "lijst"
                    }, {
                        name: "Tegels",
                        type: "tegels"
                    }],
                    n.viewOption = n.viewOptions[0],
                    this.$scope.viewClass = "list",
                    this.$scope.handleDrop = function(e, n) {
                        return B.handleDrop(e, n)
                    }
                    ,
                    this.$scope.handleFileDrop = function(e, n) {
                        return B.handleFileDrop(e, n)
                    }
                    ,
                    this.$scope.handleDragEnter = function(e, n) {
                        return B.handleDragEnter(e, n)
                    }
                    ,
                    this.$scope.$on("SELECT-MAP-CHANGE", function(e) {
                        for (var n = [], t = 1; t < arguments.length; t++)
                            n[t - 1] = arguments[t];
                        B.onSelectedMapChanged(n[0], n[1])
                    }),
                    this.$scope.$on("SELECT-BRON-CHANGE", function(e) {
                        for (var t = [], r = 1; r < arguments.length; r++)
                            t[r - 1] = arguments[r];
                        n.selectedBron = t[0],
                        n.treeViewHasFocus = t[1],
                        B.bronChanged(t[0])
                    }),
                    this.$scope.onAddFiles = function(e) {
                        return B.onAddFiles(e)
                    }
                    ,
                    this.$scope.validateFolder = function(e, n) {
                        return B.validateFolder(e, n)
                    }
                    ,
                    this.$scope.createFolder = function(e) {
                        return B.createFolder(e)
                    }
                }
                return n.prototype.onAddFiles = function(e) {
                    var n = this
                      , t = this.validateFiles(e);
                    t.length > 0 && this.fileUploadService.uploadFiles(t, this.$scope.selectedMap).finally(function() {
                        n.loadQuotas()
                    })
                }
                ,
                n.prototype.validateFiles = function(e) {
                    if (this.$scope.selectedMap.Id === p.a.OneDriveForBusiness) {
                        for (var n = [], t = 0, r = e; t < r.length; t++) {
                            (d = r[t]).size > 15728640 ? this.applicationService.showMessage("Bestand '{0}' te groot, maximum is 15 MB.".replace("{0}", d.name), a.j.ERROR, a.f) : n.push(d)
                        }
                        return n
                    }
                    var i = this.findRoot(this.$scope.selectedMap);
                    if (i.quota && i.quota.beschikbaar) {
                        for (var o = 0, s = 0, c = e; s < c.length; s++) {
                            var d;
                            o += (d = c[s]).size
                        }
                        if (o > i.quota.beschikbaar)
                            return this.applicationService.showMessage("Niet genoeg ruimte beschikbaar in bibliotheek " + i.caption, a.j.ERROR, a.f),
                            []
                    }
                    return e
                }
                ,
                n.prototype.onSelectedMapChanged = function(e, n) {
                    Object(u.w)(this.$scope.selectedMap) || (this.$scope.selectedMap.selected = !1),
                    this.$scope.selectedMap = e,
                    this.$scope.selectedMap.selected = !0,
                    Object(u.w)(this.$scope.selectedMap.parent) || (this.$scope.selectedMap.parent.isCollapsed = !1),
                    this.$scope.treeViewHasFocus = n,
                    this.mapChanged(e)
                }
                ,
                n.prototype.getBronnenTabTitle = function(e) {
                    switch (e) {
                    case d.a.Weergave:
                        return "Weergave";
                    case d.a.Toegang:
                        return "Toegang";
                    case d.a.Multimedia:
                    default:
                        return "Multimedia"
                    }
                }
                ,
                n.prototype.clickFileUpload = function(e) {
                    e.magToevoegen && (r("#hiddenUploadButton").val(""),
                    r("#hiddenUploadButton").click())
                }
                ,
                n.prototype.getKennisnetDiensten = function(e) {
                    this.bronnenService.getKennisnetDiensten(this.currentUser.person.id).then(function(n) {
                        e.bestanden = n
                    })
                }
                ,
                n.prototype.updateBronnenView = function(e, n) {
                    switch (n) {
                    case "lijst":
                        e.viewClass = "list";
                        break;
                    case "tegels":
                        e.viewClass = "tile";
                        break;
                    default:
                        e.viewClass = "list"
                    }
                }
                ,
                n.prototype.getBronnen = function(e, n) {
                    var t = this
                      , r = this.$q.defer()
                      , i = this.currentUser.relatedPersons.current.id;
                    return this.$scope.$broadcast("SHOW_API_PROGRESS_INDICATOR", "bestanden"),
                    Object(u.w)(e) ? this.bronnenService.getRoot(i).then(function(e) {
                        e.Items = t.relocateExternalFolders(e.Items),
                        t.getBronnenCompleted(r, t.$scope.bibliothekenFolder, e)
                    }) : this.bronnenService.getBronnen(e, this.findRoot(n).Id).then(function(e) {
                        t.getBronnenCompleted(r, n, e)
                    }),
                    r.promise
                }
                ,
                n.prototype.getBronnenCompleted = function(n, t, r) {
                    var i = this;
                    this.bronnenService.addStateToBronnen(r, t, this.$scope),
                    t.mappen = [],
                    t.bestanden = [],
                    e.each(r.Items, function(e) {
                        if ((e.Type & h.Enums.BronType.Map) === h.Enums.BronType.Map) {
                            var n = e.Id ? e.Id : 0
                              , r = {
                                map: e,
                                parent: t,
                                isCollapsed: !0,
                                caption: e.Naam,
                                Id: n,
                                mappen: [],
                                bestanden: []
                            };
                            i.loadQuotaForFolder(r).catch(function(e) {
                                i.applicationService.showMessage("Quota voor map {0} kon niet worden opgehaald. Probeer het later nog eens.".replace("{0}", r.caption), a.j.WARNING, a.f)
                            }),
                            t.mappen.push(r)
                        } else
                            t.bestanden.push(e)
                    }),
                    this.$scope.$broadcast("HIDE_API_PROGRESS_INDICATOR", "bestanden"),
                    n.resolve(r.Items)
                }
                ,
                n.prototype.relocateExternalFolders = function(n) {
                    return e.where(n, {
                        Id: p.a.OneDriveForBusiness
                    }).length ? this.bronnenService.relocateOneDriveFolder(n) : n
                }
                ,
                n.prototype.mapChanged = function(e) {
                    if (!Object(u.w)(e.map)) {
                        if (e.map.Id === this.KENNISNET_ID)
                            this.getKennisnetDiensten(e);
                        else {
                            if (this.idIsUtilityId(e.map.Id))
                                return void this.redirectToUtility(e);
                            this.getBronnen(this.$scope.selectedMap.map, this.$scope.selectedMap)
                        }
                        this.setPrivileges(this.$scope.selectedMap, null),
                        this.setDownloadMogelijkheid(null)
                    }
                }
                ,
                n.prototype.createUtilityId = function(e) {
                    return -1 * e - 2e3
                }
                ,
                n.prototype.idIsUtilityId = function(e) {
                    return e <= -2e3
                }
                ,
                n.prototype.getUtilityId = function(e) {
                    return -1 * (e + 2e3)
                }
                ,
                n.prototype.redirectToUtility = function(e) {
                    e.bestanden = [],
                    this.utilitiesService.redirectToUtility(this.getUtilityId(e.map.Id))
                }
                ,
                n.prototype.bronChanged = function(e) {
                    this.setPrivileges(this.$scope.selectedMap, e),
                    this.setDownloadMogelijkheid(e),
                    this.bronnenService.resetBronContentUri(e),
                    this.bronnenService.getMediaType(e) === c.a.Anders ? this.$scope.changeTab(d.a.Weergave) : this.$scope.changeTab(d.a.Multimedia)
                }
                ,
                n.prototype.openBronHernoemenDialog = function() {
                    var n = this;
                    if (this.$scope.magWijzigen && this.getFocusedBron().ParentId !== this.$scope.bibliothekenFolder.Id) {
                        var r = this.getFocusedBron()
                          , o = r.Naam
                          , c = "";
                        if (r.BronSoort === h.Enums.BronSoort.Bestand) {
                            var d = this.bronnenService.decomposeFileName(r.Naam);
                            o = d.name,
                            c = d.extension
                        } else
                            o = r.Naam,
                            c = "";
                        var l = {
                            mapnaam: o
                        };
                        this.dialogService.showDialog({
                            title: "Geef een nieuwe naam op",
                            template: t(105),
                            buttons: [s.a.Ok, s.a.Cancel],
                            callback: function(t, o) {
                                if (t.clickedButtonType === s.a.Ok)
                                    if (i.isDefined(t.data)) {
                                        r.BronSoort === h.Enums.BronSoort.Bestand && (t.data.mapnaam += "." + c);
                                        var d = "";
                                        if ((r.Type & h.Enums.BronType.Map) === h.Enums.BronType.Map) {
                                            var l = [];
                                            n.validateMap(t.data, l),
                                            d = e.first(l)
                                        } else
                                            d = n.getErrorMessageIfBronNaamIsInvalid(t.data.mapnaam);
                                        if (Object(u.u)(d)) {
                                            var p = n.getFocusedBron()
                                              , m = p.Naam;
                                            p.Naam = t.data.mapnaam,
                                            n.bronnenService.wijzigBronNaam(n.currentUser.relatedPersons.current.id, r, t.data.mapnaam).then(function(e) {
                                                o.resolve({
                                                    shouldClose: e
                                                })
                                            }, function(e) {
                                                p.Naam = m,
                                                o.resolve({
                                                    shouldClose: !0
                                                })
                                            })
                                        } else
                                            n.applicationService.showMessage(d, a.j.WARNING, a.f),
                                            o.resolve({
                                                shouldClose: !1,
                                                invalidPropertyNames: ["mapnaam"]
                                            })
                                    } else
                                        o.resolve({
                                            shouldClose: !0
                                        });
                                else
                                    o.resolve({
                                        shouldClose: !0
                                    })
                            },
                            viewModel: l
                        })
                    }
                }
                ,
                n.prototype.getErrorMessageIfUrlIsInvalid = function(e) {
                    var n = null;
                    return !Object(u.u)(e) && this.matchesRegExPattern(e, /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/) || (n = "Vul een geldige url in"),
                    n
                }
                ,
                n.prototype.getErrorMessageIfBronNaamIsInvalid = function(e) {
                    var n = this.$scope.selectedMap
                      , t = null;
                    return Object(u.u)(e) ? t = "Vul een geldige naam in." : this.bronNaamBestaatAl(n, e) && (t = "Er bestaat al een bron met deze naam."),
                    t
                }
                ,
                n.prototype.bronNaamBestaatAl = function(n, t) {
                    return i.isDefined(e.findWhere(n.bestanden, {
                        Naam: t
                    })) || i.isDefined(e.findWhere(n.mappen, {
                        Naam: t
                    }))
                }
                ,
                n.prototype.openUrlAanmakenDialog = function() {
                    var e = this;
                    if (this.$scope.magToevoegen && this.$scope.magUrlToevoegen) {
                        var n = this.$scope.selectedMap;
                        this.dialogService.showDialog({
                            title: "URL toevoegen",
                            template: t(109),
                            buttons: [s.a.Ok, s.a.Cancel],
                            callback: function(t, r) {
                                if (t.clickedButtonType === s.a.Ok)
                                    if (i.isDefined(t.data)) {
                                        var o = e.getErrorMessageIfBronNaamIsInvalid(t.data.caption)
                                          , c = ["caption"];
                                        null === o && (o = e.getErrorMessageIfUrlIsInvalid(t.data.url),
                                        c = ["url"]),
                                        null !== o ? (e.applicationService.showMessage(o, a.j.WARNING, a.f),
                                        r.resolve({
                                            shouldClose: !1,
                                            invalidPropertyNames: c
                                        })) : e.bronnenService.nieuwUrl(e.currentUser.relatedPersons.current.id, n.map.Id, t.data.caption, t.data.url).then(function(t) {
                                            r.resolve({
                                                shouldClose: t
                                            }),
                                            e.getBronnen(n.map, n)
                                        })
                                    } else
                                        r.resolve({
                                            shouldClose: !0
                                        });
                                else
                                    r.resolve({
                                        shouldClose: !0
                                    })
                            },
                            viewModel: {
                                caption: "",
                                url: "http://"
                            }
                        })
                    }
                }
                ,
                n.prototype.matchesRegExPattern = function(e, n) {
                    if (i.isUndefined(n) || Object(u.u)(e))
                        return !1;
                    var t = e.match(n);
                    return null !== t && t.length >= 1
                }
                ,
                n.prototype.validateFolder = function(n, t) {
                    var r = e.pluck(this.$scope.bibliothekenFolder.mappen, "Naam")
                      , i = e.pluck(this.$scope.selectedMap.mappen, "Naam");
                    return this.folderValidator.validate(n, r, i, t)
                }
                ,
                n.prototype.createFolder = function(n) {
                    var t = this
                      , r = n
                      , i = this.$scope.selectedMap
                      , o = this.bronnenService.createFolder(r, i.map.Id)
                      , a = e.extend({
                        map: [],
                        parent: i,
                        bestanden: [],
                        mappen: [],
                        unserialized: !0
                    }, o);
                    this.bronnenService.createMap(this.currentUser.relatedPersons.current.id, i.map.Id, n).then(function(e) {
                        a.Id = e.Id,
                        a.map = e,
                        a.unserialized = !1,
                        a.mappen = [],
                        a.parent = i,
                        t.$scope.selectedMap.mappen.push(a),
                        t.setPrivileges(a, null),
                        t.setDownloadMogelijkheid(null)
                    })
                }
                ,
                n.prototype.validateMap = function(n, t) {
                    return i.isDefined(n.mapnaam) ? e.isUndefined(e.findWhere(this.$scope.bibliothekenFolder.mappen, {
                        Naam: n.mapnaam
                    })) ? !!e.isUndefined(e.findWhere(this.$scope.selectedMap.mappen, {
                        Naam: n.mapnaam
                    })) || (t.push("De map bestaat al."),
                    !1) : (t.push("Ongeldige naam."),
                    !1) : (t.push("Naam opgeven."),
                    !1)
                }
                ,
                n.prototype.downloadBron = function(e) {
                    this.$scope.magDownloaden && this.downloadTokenService.downloadFromLocation(e.Uri + "?download=true")
                }
                ,
                n.prototype.showVerwijderBronDialog = function(e) {
                    var n = this;
                    if (this.$scope.magVerwijderen && this.$scope.selectedMap !== this.$scope.bibliothekenFolder && this.getFocusedBron().ParentId !== this.$scope.bibliothekenFolder.Id) {
                        var t = this.findRoot(this.$scope.selectedMap)
                          , r = (e.Type & h.Enums.BronType.Map) === h.Enums.BronType.Map ? " verwijderen?<br><br>De verwijderde bron en alle onderliggende items worden <b>automatisch na 8 dagen definitief verwijderd</b> uit de prullenbak." : " verwijderen?<br><br>De verwijderde bron wordt <b>automatisch na 8 dagen definitief verwijderd</b> uit de prullenbak."
                          , i = t.Id === p.a.Prullenbak ? " definitief verwijderen?" : r
                          , o = (e.Type & h.Enums.BronType.Map) === h.Enums.BronType.Map ? "De bron <b>'" + e.Naam + "'</b> en alle onderliggende items" + i : "De bron <b>'" + e.Naam + "'</b>" + i;
                        this.dialogService.showConfirm("Bron verwijderen", o, [s.a.Ok, s.a.Cancel], function(t) {
                            t.clickedButtonType === s.a.Ok && n.verwijderBron(e)
                        })
                    }
                }
                ,
                n.prototype.openTabContainer = function() {
                    r(".container").removeClass("aside-toggle"),
                    r(".btn-tabs").addClass("ng-hide")
                }
                ,
                n.prototype.closeTabContainer = function() {
                    r(".container").toggleClass("aside-toggle"),
                    r(".btn-tabs").toggleClass("ng-hide")
                }
                ,
                n.prototype.verwijderBron = function(e) {
                    var n = this
                      , t = this.findRoot(this.$scope.selectedMap)
                      , r = this.currentUser.person.id
                      , i = this.findFolderById(e.Id, this.$scope.bibliothekenFolder);
                    if (Object(u.t)(i) ? this.removeFolderFromParent(i) : this.removeFileFromParent(this.$scope.selectedMap, e),
                    this.useRecycleBin && t.Id !== p.a.Prullenbak) {
                        e.ParentId = p.a.Prullenbak;
                        var o = this.getFocusedBron();
                        this.bronnenService.wijzigBron(r, e.Id, o).then(function() {
                            n.applicationService.showMessage("De bron <b>'" + e.Naam + "'</b> is verplaatst naar de prullenbak.", a.j.INFORMATION, a.f, ""),
                            n.loadQuotas(),
                            n.updateSelectionAfterDelete(i, e)
                        }, function(e) {})
                    } else
                        this.bronnenService.verwijderBron(this.currentUser.person.id, e.Id).then(function(t) {
                            n.applicationService.showMessage("De bron <b>'" + e.Naam + "'</b> is verwijderd.", a.j.INFORMATION, a.f, ""),
                            n.loadQuotas(),
                            n.updateSelectionAfterDelete(i, e)
                        }, function(t) {
                            Object(u.w)(i) ? n.$scope.selectedMap.bestanden.push(e) : n.$scope.selectedMap.mappen.push(i)
                        })
                }
                ,
                n.prototype.handleDrop = function(e, n) {
                    var t = this
                      , r = n
                      , o = this.findBronById(r, this.$scope.bibliothekenFolder);
                    if (!Object(u.w)(o)) {
                        var s = o.map
                          , c = null;
                        c = Object(u.w)(e.ParentId) ? this.findBronById(e, this.$scope.bibliothekenFolder) : e;
                        var d = null;
                        if (!Object(u.w)(c) && (d = Object(u.w)(c.ParentId) ? c.map : c).ParentId !== s.Id)
                            if ((d.Type & m.Map) !== m.Map || (s.Type & m.OneDriveForBusiness) !== m.OneDriveForBusiness)
                                if ((d.Type & m.Kennisnet) !== m.Kennisnet)
                                    if ((d.Type & m.OneDriveForBusiness) !== m.OneDriveForBusiness || (d.Type & m.Map) !== m.Map) {
                                        this.getBronnen(s, o).then(function(e) {
                                            if (t.isParent(o, d))
                                                t.applicationService.showMessage("Een map kan niet naar een van zijn onderliggende mappen verplaatst worden.", a.j.ERROR, a.f, "Bronnen");
                                            else {
                                                var n = t.findRoot(o)
                                                  , r = t.$q.when(!0);
                                                i.isDefined(d.RootId) && (n.Id !== d.RootId || d.RootId === p.a.MijnEloDocumenten && n.Id === p.a.Prullenbak || d.RootId === p.a.Prullenbak && n.Id === p.a.MijnEloDocumenten) || (r = t.doesTargetHaveEnoughSpace(n, d.Grootte)),
                                                r.then(function(e) {
                                                    e ? (t.$scope.$broadcast("SHOW_API_PROGRESS_INDICATOR", "bestanden"),
                                                    t.internalDragDropService.dropBron(d, o).then(function(e) {
                                                        e && t.removeItemFromFolder(d, t.$scope.selectedMap),
                                                        t.loadQuotas()
                                                    }).finally(function() {
                                                        t.$scope.$broadcast("HIDE_API_PROGRESS_INDICATOR", "bestanden")
                                                    })) : t.showInsufficientSpaceMessage(o)
                                                }).catch(function(e) {
                                                    t.showUnknownErrorOccurredMessage(e)
                                                })
                                            }
                                        })
                                    } else
                                        this.applicationService.showMessage("Een OneDrive For Business map kan niet in zijn geheel verplaatst worden.", a.j.ERROR, a.f, "Bronnen");
                                else
                                    this.applicationService.showMessage("Een Kennisnet item kan niet verplaatst worden.", a.j.ERROR, a.f, "Bronnen");
                            else
                                this.applicationService.showMessage("Een map kan niet naar OneDrive For Business verplaatst worden.", a.j.ERROR, a.f, "Bronnen")
                    }
                }
                ,
                n.prototype.removeItemFromFolder = function(n, t) {
                    if ((n.Type & m.Map) === m.Map) {
                        var r = t.mappen;
                        r = e.without(r, e.findWhere(r, {
                            Id: n.Id
                        })),
                        t.mappen = r
                    } else {
                        var i = t.bestanden;
                        i = e.without(i, e.findWhere(i, {
                            Id: n.Id
                        })),
                        t.bestanden = i
                    }
                }
                ,
                n.prototype.handleFileDrop = function(n, t) {
                    var r, i = this, o = null;
                    r = Object(u.t)(t.srcElement) ? t.srcElement.getAttribute("id") || "*" : Object(u.t)(t.originalTarget) && !Object(u.p)(t.originalTarget.id) ? t.originalTarget.id : "*";
                    var a = e.map(n, function(e) {
                        return e.size
                    }).reduce(function(e, n) {
                        return e + n
                    }, 0);
                    "*" === r ? (o = this.$scope.selectedMap,
                    this.doesTargetHaveEnoughSpace(o, a).then(function(e) {
                        e ? i.fileUploadService.uploadFiles(n, o).finally(function() {
                            i.loadQuotas()
                        }) : i.showInsufficientSpaceMessage(o)
                    }).catch(function(e) {
                        i.showUnknownErrorOccurredMessage(e)
                    })) : (o = this.findFolderById(r, this.$scope.bibliothekenFolder),
                    this.getBronnen(o.map, o).then(function(e) {
                        i.doesTargetHaveEnoughSpace(o, a).then(function(e) {
                            e ? i.fileUploadService.uploadFiles(n, o).finally(function() {
                                i.loadQuotas()
                            }) : i.showInsufficientSpaceMessage(o)
                        }).catch(function(e) {
                            i.showUnknownErrorOccurredMessage(e)
                        })
                    }))
                }
                ,
                n.prototype.handleDragEnter = function(e, n) {
                    var t = this.getId(e)
                      , r = this.getId(n)
                      , i = this.findBronById(t, this.$scope.bibliothekenFolder)
                      , o = this.findFolderById(r, this.$scope.bibliothekenFolder);
                    return this.canAdd(o) && this.canDrag(i)
                }
                ,
                n.prototype.canAdd = function(e) {
                    return e.map.Privilege === h.Enums.BronPrivilege.Eigenaar || e.map.Privilege === h.Enums.BronPrivilege.MapEigenaar || e.map.Privilege === h.Enums.BronPrivilege.Auteur
                }
                ,
                n.prototype.canDrag = function(e) {
                    var n;
                    return (n = i.isDefined(e.Privilege) ? e.Privilege : e.map.Privilege) === h.Enums.BronPrivilege.Eigenaar || n === h.Enums.BronPrivilege.MapEigenaar || n === h.Enums.BronPrivilege.Auteur
                }
                ,
                n.prototype.getId = function(n) {
                    return n.length > 0 ? e.first(n).getAttribute("id") : 0
                }
                ,
                n.prototype.removeFolderFromParent = function(n) {
                    var t = n.parent.mappen;
                    t = e.without(t, e.findWhere(t, {
                        Id: n.map.Id
                    })),
                    n.parent.mappen = t
                }
                ,
                n.prototype.removeFileFromParent = function(n, t) {
                    var r = n.bestanden;
                    r = e.without(r, e.findWhere(r, {
                        Id: t.Id
                    })),
                    n.bestanden = r
                }
                ,
                n.prototype.findBronById = function(n, t) {
                    if (t.Id.toString() === n.toString())
                        return t;
                    if (i.isDefined(t.bestanden)) {
                        var r = e.find(t.bestanden, function(e) {
                            return n.toString() === e.Id + ""
                        });
                        if (i.isDefined(r))
                            return r
                    }
                    if (i.isDefined(t.mappen))
                        for (var o = 0; o < t.mappen.length; o++) {
                            var a = t.mappen[o];
                            if (a.Id.toString() === n.toString())
                                return a;
                            var s = this.findBronById(n, a);
                            if (i.isDefined(s))
                                return s
                        }
                }
                ,
                n.prototype.findFolderById = function(e, n) {
                    if (n.Id.toString() === e.toString())
                        return n;
                    if (i.isDefined(n.mappen))
                        for (var t = 0; t < n.mappen.length; t++) {
                            var r = n.mappen[t];
                            if (r.Id.toString() === e.toString())
                                return r;
                            var o = this.findFolderById(e, r);
                            if (i.isDefined(o))
                                return o
                        }
                }
                ,
                n.prototype.handleKeyboardEvent = function(e) {}
                ,
                n.prototype.countNumberOfParents = function(e, n) {
                    return n++,
                    Object(u.w)(e.parent) ? n : this.countNumberOfParents(e.parent, n)
                }
                ,
                n.prototype.isParent = function(e, n) {
                    return e.map.ParentId === n.Id || null !== e.parent && this.isParent(e.parent, n)
                }
                ,
                n.prototype.setDownloadMogelijkheid = function(e) {
                    Object(u.w)(e) ? this.$scope.magDownloaden = !1 : this.$scope.magDownloaden = (e.Type & m.Document) === m.Document
                }
                ,
                n.prototype.setPrivileges = function(e, n) {
                    Object(u.w)(n) ? (this.$scope.selectedBron = void 0,
                    this.setMapPrivileges(e)) : this.setFilePrivileges(e, n)
                }
                ,
                n.prototype.setFilePrivileges = function(e, n) {
                    var t = this.findRoot(e);
                    if (t.Id === p.a.Prullenbak || e.map && e.map.Id === this.KENNISNET_ID)
                        return this.$scope.magWijzigen = !1,
                        this.$scope.magToevoegen = !1,
                        this.$scope.magMapToevoegen = !1,
                        this.$scope.magUrlToevoegen = !1,
                        void (this.$scope.magVerwijderen = t.Id === p.a.Prullenbak);
                    if (e.map.Id !== p.a.ProjectDocumenten) {
                        switch (n.Privilege) {
                        case h.Enums.BronPrivilege.MapEigenaar:
                        case h.Enums.BronPrivilege.Eigenaar:
                            return this.$scope.magVerwijderen = 0 !== n.ParentId && this.heeftSchrijfRechten && this.bronnenService.findRootId(e) !== p.a.OneDriveForBusiness,
                            void (this.$scope.magWijzigen = 0 !== n.ParentId && this.heeftSchrijfRechten && this.bronnenService.findRootId(e) !== p.a.OneDriveForBusiness);
                        case h.Enums.BronPrivilege.Redacteur:
                            return this.$scope.magWijzigen = 0 !== n.ParentId && this.heeftSchrijfRechten,
                            void (this.$scope.magVerwijderen = !1);
                        case h.Enums.BronPrivilege.Auteur:
                            return this.$scope.magWijzigen = 0 !== n.ParentId && n.Type !== h.Enums.BronType.Map && this.heeftSchrijfRechten && this.bronnenService.findRootId(e) !== p.a.OneDriveForBusiness,
                            void (this.$scope.magVerwijderen = !1);
                        case h.Enums.BronPrivilege.Lezer:
                            return this.$scope.magWijzigen = !1,
                            void (this.$scope.magVerwijderen = !1)
                        }
                        this.$scope.magToevoegen = !1,
                        this.$scope.magVerwijderen = !1,
                        this.$scope.magWijzigen = !1
                    } else
                        this.setProjectMapPrivileges(n)
                }
                ,
                n.prototype.setMapPrivileges = function(e) {
                    var n = this.findRoot(e);
                    if (n.Id === p.a.Prullenbak || e.map.Id === this.KENNISNET_ID)
                        return this.$scope.magWijzigen = !1,
                        this.$scope.magToevoegen = !1,
                        this.$scope.magMapToevoegen = !1,
                        this.$scope.magUrlToevoegen = !1,
                        void (this.$scope.magVerwijderen = !1);
                    if (this.$scope.magMapToevoegen = !0,
                    this.$scope.magUrlToevoegen = !0,
                    (e.map.Type & h.Enums.BronType.Map) === h.Enums.BronType.Map && (this.$scope.magMapToevoegen = this.countNumberOfParents(e, 0) < 7),
                    n.Id === p.a.OneDriveForBusiness && (this.$scope.magMapToevoegen = !1,
                    this.$scope.magUrlToevoegen = !1),
                    e.map.Id !== p.a.ProjectDocumenten) {
                        switch (e.map.Privilege) {
                        case h.Enums.BronPrivilege.MapEigenaar:
                        case h.Enums.BronPrivilege.Eigenaar:
                            return this.$scope.magToevoegen = this.heeftSchrijfRechten,
                            this.$scope.magVerwijderen = 0 !== e.parent.map.Id && this.findRoot(e).Id !== p.a.OneDriveForBusiness && this.heeftSchrijfRechten,
                            void (this.$scope.magWijzigen = 0 !== e.parent.map.Id && this.findRoot(e).Id !== p.a.OneDriveForBusiness && this.heeftSchrijfRechten);
                        case h.Enums.BronPrivilege.Redacteur:
                            return this.$scope.magToevoegen = this.heeftSchrijfRechten,
                            this.$scope.magWijzigen = 0 !== e.parent.map.Id && this.heeftSchrijfRechten,
                            void (this.$scope.magVerwijderen = !1);
                        case h.Enums.BronPrivilege.Auteur:
                            return this.$scope.magToevoegen = this.heeftSchrijfRechten && (this.$scope.oneDriveForBusinessCoupled || this.findRoot(e).Id !== p.a.OneDriveForBusiness),
                            this.$scope.magVerwijderen = !1,
                            void (this.$scope.magWijzigen = !1);
                        case h.Enums.BronPrivilege.Lezer:
                            return this.$scope.magWijzigen = !1,
                            this.$scope.magVerwijderen = !1,
                            void (this.$scope.magToevoegen = !1)
                        }
                        this.$scope.magToevoegen = !1,
                        this.$scope.magVerwijderen = !1,
                        this.$scope.magWijzigen = !1
                    } else
                        this.setProjectMapPrivileges(e.map)
                }
                ,
                n.prototype.setProjectMapPrivileges = function(e) {
                    e.Privilege === h.Enums.BronPrivilege.Lezer ? (this.$scope.magToevoegen = !1,
                    this.$scope.magVerwijderen = !1,
                    this.$scope.magWijzigen = !1) : (this.$scope.magToevoegen = this.heeftSchrijfRechten,
                    this.$scope.magVerwijderen = this.heeftSchrijfRechten,
                    this.$scope.magWijzigen = this.heeftSchrijfRechten)
                }
                ,
                n.prototype.getFocusedBron = function() {
                    return !0 === this.$scope.treeViewHasFocus ? Object(u.w)(this.$scope.selectedMap) ? null : this.$scope.selectedMap.map : this.$scope.selectedBron
                }
                ,
                n.prototype.findRoot = function(e) {
                    return Object(u.w)(e.parent) ? e : e.parent === this.$scope.bibliothekenFolder ? e : this.findRoot(e.parent)
                }
                ,
                n.prototype.getPrivilegeNaam = function() {
                    var e = "onbekend"
                      , n = this.getFocusedBron();
                    if (Object(u.w)(n))
                        return e;
                    if (this.findRoot(this.$scope.selectedMap).map.Id === p.a.ProjectDocumenten) {
                        switch (n.Privilege) {
                        case 1:
                            e = "Lezer";
                            break;
                        case 2:
                            e = "Eigenaar"
                        }
                    } else
                        switch (n.Privilege) {
                        case Contracts.Bronnen.Enums.BronPrivilege.Auteur:
                            e = "Auteur";
                            break;
                        case Contracts.Bronnen.Enums.BronPrivilege.Eigenaar:
                            e = "Eigenaar";
                            break;
                        case Contracts.Bronnen.Enums.BronPrivilege.Geen:
                            e = "Geen";
                            break;
                        case Contracts.Bronnen.Enums.BronPrivilege.Lezer:
                            e = "Lezer";
                            break;
                        case Contracts.Bronnen.Enums.BronPrivilege.MapEigenaar:
                            e = "Map Eigenaar";
                            break;
                        case Contracts.Bronnen.Enums.BronPrivilege.Redacteur:
                            e = "Redacteur"
                        }
                    return e
                }
                ,
                n.prototype.getUserSettings = function(e, n) {
                    var t = {
                        size: {
                            name: "Normaal",
                            value: "normaal"
                        },
                        collapsed: 0
                    };
                    e.sizeOption = t.size.value,
                    this.$timeout(function() {
                        return e.rijHoogte = t.size.value
                    }, 0)
                }
                ,
                n.prototype.loadQuotaForFolder = function(n) {
                    var t = this.$q.defer();
                    if (this.canQuotaBeRetrievedForFolder(n)) {
                        this.currentUser.relatedPersons.current.id;
                        var r = e.findWhere(n.map.Links, {
                            Rel: "Quota"
                        });
                        this.bronnenService.getQuota(n.Id, r).then(function(e) {
                            n.quota = e,
                            t.resolve()
                        }).catch(function(e) {
                            t.reject(e)
                        })
                    } else
                        t.resolve();
                    return t.promise
                }
                ,
                n.prototype.canQuotaBeRetrievedForFolder = function(n) {
                    return n.parent === this.$scope.bibliothekenFolder && e.contains([p.a.MijnEloDocumenten, p.a.GedeeldeDocumenten, p.a.Prullenbak], n.Id)
                }
                ,
                n.prototype.loadQuotas = function() {
                    var n = this
                      , t = []
                      , r = e.filter(this.$scope.bibliothekenFolder.mappen, function(n) {
                        return e.contains([p.a.MijnEloDocumenten, p.a.GedeeldeDocumenten, p.a.Prullenbak], n.Id)
                    });
                    return e.forEach(r, function(e) {
                        t.push(n.loadQuotaForFolder(e))
                    }),
                    this.$q.all(t)
                }
                ,
                n.prototype.doesTargetHaveEnoughSpace = function(n, t) {
                    var r = this.$q.defer();
                    if (this.canQuotaBeRetrievedForFolder(n)) {
                        var i = this.findRoot(n)
                          , o = e.findWhere(i.map.Links, {
                            Rel: "Quota"
                        });
                        this.bronnenService.getQuota(i.Id, o).then(function(e) {
                            var n = e.beschikbaar - t > 0;
                            i.quota = e,
                            r.resolve(n)
                        }).catch(function(e) {
                            r.reject(e)
                        })
                    } else
                        r.resolve(!0);
                    return r.promise
                }
                ,
                n.prototype.showInsufficientSpaceMessage = function(e) {
                    this.applicationService.showMessage("Niet genoeg ruimte beschikbaar in {0}.".replace("{0}", e.caption), a.j.ERROR, a.f)
                }
                ,
                n.prototype.showUnknownErrorOccurredMessage = function(e) {
                    this.applicationService.showMessage("Onbekende fout opgetreden. Probeer het later nog eens of neem contact op met de helpdesk.", a.j.ERROR, a.f, "Bronnen")
                }
                ,
                n.prototype.updateSelectionAfterDelete = function(e, n) {
                    this.$scope.selectedMap === e && this.onSelectedMapChanged(e.parent, this.$scope.treeViewHasFocus),
                    this.$scope.selectedBron === n && (this.$scope.selectedBron = void 0,
                    this.bronChanged(void 0))
                }
                ,
                n.CONTROLLER_NAME = "bronnenOverzichtController",
                n.$inject = ["$scope", "$q", "$timeout", "$filter", "bronnenService", "dialogService", "applicationService", "currentUser", "settingsService", "fileUploadService", "internalDragDropService", "folderValidator", "magisterLocale", "profielService", "utilitiesService", "downloadTokenService", n],
                n
            }()
        }
        ).call(this, t(3), t(15), t(1))
    },
    504: function(e, n, t) {
        "use strict";
        t.d(n, "a", function() {
            return i
        });
        var r = function() {
            function e(e) {
                var n = this;
                this.$scope = e,
                e.isBibliothekenVisible = !0,
                e.isHulpprogrammasVisible = !0,
                e.togglePanelVisibility = function(e) {
                    return n.togglePanelVisibility(e)
                }
                ,
                this.$scope.selectMap = function(e) {
                    n.$scope.$emit("SELECT-MAP-CHANGE", e, !0)
                }
                ,
                this.$scope.handleDrop = function(n) {
                    var t = n.draggable.element[0].id
                      , r = n.dropTarget[0].id
                      , i = e.drop();
                    void 0 !== i && i(t, r)
                }
                ,
                this.$scope.handleFileDrop = function(n, t) {
                    var r = e.fileDrop();
                    void 0 !== r && r(n, t)
                }
                ,
                this.$scope.handleDragEnter = function(n, t) {
                    var r = e.dragEnter();
                    return void 0 === r || r(n, t)
                }
            }
            return e.prototype.togglePanelVisibility = function(e) {
                return !e
            }
            ,
            e.prototype.expandParentNodes = function(e) {}
            ,
            e.$inject = ["$scope"],
            e
        }();
        function i() {
            return {
                template: t(505),
                scope: {
                    rootMap: "=",
                    hulpprogrammasRootMap: "=",
                    treeViewHasFocus: "=",
                    kennisnetClick: "=",
                    drop: "&",
                    fileDrop: "&",
                    enter: "&",
                    dragEnter: "&"
                },
                controller: r,
                link: function(e, n, t) {}
            }
        }
    },
    505: function(e, n) {
        e.exports = '<div class="widget">\r\n    <div class="block">\r\n        <h3>\r\n            <span data-ng-class="{\'glyph icon-up-arrow\': isBibliothekenVisible, \'glyph icon-down-arrow\': !isBibliothekenVisible}" data-ng-click="isBibliothekenVisible = togglePanelVisibility(isBibliothekenVisible);"></span>\r\n            <b>Bibliotheken</b>\r\n        </h3>\r\n        <div class="content-auto" data-ng-show="isBibliothekenVisible">\r\n            <div data-sm-tree-view="treeview"\r\n                 data-source="rootMap"\r\n                 data-has-focus="treeViewHasFocus"\r\n                 data-selected-node="selectedMap"\r\n                 data-drop="handleDrop"\r\n                 data-file-drop="handleFileDrop"\r\n                 data-enter="handleDragEnter"\r\n                 data-repeat-finished-id="bronnen"></div>\r\n        </div>\r\n    </div>\r\n    <div class="block">\r\n        <h3>\r\n            <span data-ng-class="{\'glyph icon-up-arrow\': isHulpprogrammasVisible, \'glyph icon-down-arrow\': !isHulpprogrammasVisible}" data-ng-click="isHulpprogrammasVisible = togglePanelVisibility(isHulpprogrammasVisible);"></span>\r\n            <b>Hulpprogramma\'s</b>\r\n        </h3>\r\n        <div class="content-auto" data-ng-show="isHulpprogrammasVisible">\r\n            <ul class="list sources small-sources">\r\n                <li class="map" data-ng-repeat="map in hulpprogrammasRootMap.mappen">\r\n                    \x3c!--<div data-sm-kennis-net-link="kennisnetlink" data-sm-default-kennisnet-link="true"></div>--\x3e\r\n                    <a data-ng-click="selectMap(map)" data-ng-bind="map.map.Naam"></a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n    </div>\r\n</div>'
    },
    506: function(e, n, t) {
        "use strict";
        (function(e) {
            t.d(n, "a", function() {
                return s
            });
            var r = t(86)
              , i = t(0)
              , o = Contracts.Bronnen.Enums.BronType
              , a = function() {
                function n(n, t, o, a, s) {
                    var c = this;
                    this.$scope = n,
                    this.bronnenService = t,
                    this.profielService = o,
                    this.downloadTokenService = a,
                    this.$window = s,
                    n.selectBron = function(e) {
                        return c.selectBron(e)
                    }
                    ,
                    n.selectMap = function(e) {
                        return c.selectMap(e)
                    }
                    ,
                    n.createBreadcrumb = function(e, n) {
                        return c.createBreadcrumb(e, n)
                    }
                    ,
                    n.onFileUploaded = function(e, n, t) {
                        return c.onFileUploaded(e, n, t)
                    }
                    ,
                    n.library = null,
                    this.$scope.SysteemMapType = r.a,
                    this.profielService.oneDriveForBusinessGekoppeld().then(function(e) {
                        n.oneDriveForBusinessCoupled = e.isCoupled,
                        n.oneDriveForBusinessEnabled = e.isEnabled
                    }),
                    n.handleDrop = function(e) {
                        var t = e.draggable.element[0].id
                          , r = e.dropTarget[0].id
                          , i = n.drop();
                        void 0 !== i && i(t, r)
                    }
                    ,
                    n.handleFileDrop = function(e, t) {
                        var r = n.fileDrop();
                        void 0 !== r && r(e, t)
                    }
                    ,
                    n.handleDragEnter = function(e, t) {
                        var r = n.dragEnter();
                        return void 0 === r || r(e, t)
                    }
                    ,
                    n.createHintElement = function(n) {
                        var t = e.element(document.createElement(n.get(0).tagName));
                        return t.html(n.html()),
                        t.width(n.width()),
                        t.height(n.height()),
                        t.attr("id", n.attr("id")),
                        t.attr("class", n.attr("class")),
                        t.addClass("bron-drag-hint"),
                        t
                    }
                    ,
                    this.$scope.isSelectedMap = function(e) {
                        return !Object(i.w)(n.selectedBron) && n.selectedBron.Id === e.Id
                    }
                    ;
                    var d = this.$scope.$watch("selectedMap", function(e, n) {
                        e && e !== n && c.setLibrary(e, e.Id < 0)
                    });
                    this.$scope.$on("$destroy", function() {
                        d()
                    }),
                    n.dragEnabled = !0
                }
                return n.prototype.onFileUploaded = function(e, n, t) {
                    this.$scope.$emit("FILE-UPLOADED", e, n, t)
                }
                ,
                n.prototype.selectMap = function(e) {
                    var n;
                    Object(i.w)(this.selectedMap) || (n = this.selectedMap.map.Id === e.map.Id),
                    this.selectedMap = e,
                    !0 === n && (this.$scope.selectedMap = e,
                    this.$scope.$emit("SELECT-MAP-CHANGE", e, !1)),
                    this.$scope.$emit("SELECT-BRON-CHANGE", e.map, !1)
                }
                ,
                n.prototype.selectBron = function(e) {
                    this.$scope.selectedBron && this.$scope.selectedBron.Id === e.Id ? this.openBron(e) : (this.$scope.selectedBron = e,
                    this.$scope.$emit("SELECT-BRON-CHANGE", e, !1))
                }
                ,
                n.prototype.createBreadcrumb = function(n, t) {
                    return e.isDefined(n) ? n.parent && !Object(i.w)(n.parent.parent) ? " <i> " + n.parent.map.Naam + " </i> " + n.map.Naam : n.map.Naam : ""
                }
                ,
                n.prototype.openBron = function(e) {
                    (e.Type & o.Document) === o.Document ? this.downloadTokenService.downloadFromLocation(this.bronnenService.extractDownloadLInk(e)) : (e.Type & o.Link) === o.Link && this.$window.open(e.Uri)
                }
                ,
                n.prototype.setLibrary = function(e, n) {
                    if (this.$scope.library = null,
                    n)
                        this.$scope.library = e;
                    else {
                        var t = e;
                        do {
                            if (t.parent.Id < 0)
                                return void (this.$scope.library = t.parent);
                            t = t.parent
                        } while (t && null !== t.parent)
                    }
                }
                ,
                n.$inject = ["$scope", "bronnenService", "profielService", "downloadTokenService", "$window"],
                n
            }();
            function s() {
                return {
                    template: t(507),
                    scope: {
                        selectedBron: "=",
                        selectedMap: "=",
                        drop: "&",
                        fileDrop: "&",
                        viewClass: "=",
                        enter: "&",
                        dragEnter: "&"
                    },
                    controller: a
                }
            }
        }
        ).call(this, t(1))
    },
    507: function(e, n) {
        e.exports = '<div class="widget">\r\n    <div class="block" data-sm-loading-indicator="{domain: \'bestanden\', className: \'icon-paper bronnen-loading-indicator\', overlay: false}">\r\n        <span ng-show="library.quota" class="bronnen-quota-label">{{library.quota.gebruikt | sizeConverter}}/{{library.quota.totaal | sizeConverter}}</span>\r\n        <h3 data-ng-bind-html="createBreadcrumb(selectedMap);" class="breadcrumb"></h3>\r\n        <div>\r\n            <ul class="{{viewClass}} sources" id="bestanden-overzicht">\r\n                <li id="{{map.map.Id}}"\r\n                    data-sm-drag-drop="{drag: true, drop: true, fileDrop: true}" data-hint-element="createHintElement" data-drop="handleDrop" data-file-drop="handleFileDrop"\r\n                    data-enter="handleDragEnter"\r\n                    class="{{map.map | determineFileIconBronnen}}"\r\n                    data-ng-class="{\'selected\': isSelectedMap(map.map)}"\r\n                    data-ng-repeat="map in selectedMap.mappen | orderBy: \'map.Naam\'"\r\n                    data-sm-notify-complete="complete"\r\n                    data-ng-click="selectMap(map)">\r\n                    <a data-ng-class="{\'unserialized\': map.unserialized}" data-ng-bind="map.map.Naam" id="{{map.map.Id}}"></a>\r\n                </li>\r\n                <li id="{{bron.Id}}"\r\n                    data-ng-class="{\'selected\': isSelectedMap(bron)}"\r\n                    data-sm-drag-drop="{drag: true}" data-hint-element="createHintElement"\r\n                    data-enter="handleDragEnter"\r\n                    class="{{bron | determineFileIconBronnen}}"\r\n                    data-ng-repeat="bron in selectedMap.bestanden | orderBy: \'Naam\'"\r\n                    data-sm-notify-complete="complete"\r\n                    data-ng-click="selectBron(bron)">\r\n                    <a data-ng-class="{\'unserialized\': bron.unserialized}" data-ng-bind="bron.Naam"></a>\r\n                </li>\r\n            </ul>\r\n            \r\n            <p class="empty-message" data-ng-show="selectedMap.mappen.length === 0 && selectedMap.bestanden.length === 0 \r\n                                                    && (oneDriveForBusinessCoupled || selectedMap.map.Id !== SysteemMapType.OneDriveForBusiness)">\r\n                Geen items in deze map.\r\n            </p>\r\n\r\n            <p class="empty-message" data-ng-show="selectedMap.mappen.length === 0 && selectedMap.bestanden.length === 0 \r\n                                                    && (!oneDriveForBusinessCoupled && oneDriveForBusinessEnabled && selectedMap.map.Id === SysteemMapType.OneDriveForBusiness)">\r\n                Je hebt nog geen koppeling met OneDrive for Education. Ga naar <a href="/magister/#/mijn-instellingen">Mijn instellingen</a> om de koppeling tot stand te brengen.\r\n            </p>\r\n        </div>\r\n    </div>\r\n</div>'
    },
    508: function(e, n, t) {
        "use strict";
        t.d(n, "a", function() {
            return i
        });
        var r = function() {
            return function() {}
        }();
        function i() {
            return {
                template: t(509),
                controller: r
            }
        }
    },
    509: function(e, n) {
        e.exports = '<div class="widget">\r\n    <div class="block">\r\n        <h3><em class="">Bibliotheken</em> >> Project-documenten</h3>\r\n        <div class="content">\r\n            <ul class="list sources">\r\n                <li class="map"><a href="#">Leerjaar 1</a></li>\r\n                <li class="map"><a href="#">Leerjaar 2</a></li>\r\n                <li class="textfile"><a href="#">Onderdelen van een boek</a></li>\r\n                <li class="excel"><a href="#">Leerjaar</a></li>\r\n                <li class="textfile"><a href="#">Leerjaar</a></li>\r\n                <li class="excel"><a href="#">Leerjaar</a></li>\r\n                <li class="audiofile"><a href="#">Leerjaar</a></li>\r\n                <li class="videofile"><a href="#">Leerjaar</a></li>\r\n                <li class="webpage"><a href="#">Leerjaar</a></li>\r\n                <li class="presentationfile"><a href="#">Leerjaar</a></li>\r\n            </ul>\r\n        </div>\r\n    </div>\x3c!-- block --\x3e\r\n</div>\x3c!-- widget --\x3e'
    },
    510: function(e, n, t) {
        "use strict";
        (function(e, r) {
            t.d(n, "a", function() {
                return c
            });
            var i = t(8)
              , o = t(85)
              , a = t(86)
              , s = Contracts.Bronnen
              , c = function() {
                function n(e, n, t, r, i, o) {
                    this.$q = e,
                    this.fileService = n,
                    this.bronnenService = t,
                    this.dialogService = r,
                    this.applicationService = i,
                    this.currentUser = o
                }
                return n.prototype.uploadFiles = function(e, n) {
                    var t = this.$q.defer();
                    return e && e.length > 0 ? this.internalUploadFiles(e, n).then(function() {
                        t.resolve()
                    }).catch(function(e) {
                        t.reject(e)
                    }) : t.reject("De meegegeven files array is niet gedefinieerd of bevat geen bestanden om te uploaden."),
                    t.promise
                }
                ,
                n.prototype.internalUploadFiles = function(n, t) {
                    var r = this
                      , i = this.$q.defer()
                      , o = [];
                    return e.forEach(n, function(e) {
                        var n = r.findDuplicate(e, t)
                          , i = r.targetIsOneDriveForBusiness(t);
                        n ? r.showOverschrijvenDialog(e.name, t.map.Naam).then(function(a) {
                            a && (i ? (r.removeFromParent(n, t),
                            o.push(r.internalUploadFile(e, t))) : r.bronnenService.verwijderBron(r.currentUser.person.id, n.Id).then(function(i) {
                                i && (r.removeFromParent(n, t),
                                o.push(r.internalUploadFile(e, t)))
                            }))
                        }) : o.push(r.internalUploadFile(e, t))
                    }),
                    this.$q.all(o).then(function() {
                        i.resolve()
                    }).catch(function(e) {
                        i.reject(e)
                    }),
                    i.promise
                }
                ,
                n.prototype.internalUploadFile = function(n, t) {
                    var i = this
                      , o = this.$q.defer()
                      , a = this.createUnserializedBron(n, t)
                      , s = r.extend(a, {
                        unserialized: !0
                    });
                    return t.bestanden.push(s),
                    this.uploadFile(n, a, t).then(function(n) {
                        e.extend(s, n),
                        s.unserialized = !1,
                        i.showUploadSuccess(s)
                    }).catch(function(e) {
                        i.removeFromParent(s, t),
                        r.isDefined(e.data) ? null != e.data.omschrijving ? i.showUploadFailure(s, e.data.omschrijving) : null != e.data.message && i.showUploadFailure(s, e.data.message) : i.showUploadFailure(s, e)
                    }).finally(function() {
                        o.resolve()
                    }),
                    o.promise
                }
                ,
                n.prototype.showUploadSuccess = function(e) {
                    var n = "De bron <b>" + (e.Naam || "") + "</b> is succesvol toegevoegd.";
                    this.applicationService.showMessage(n, i.j.INFORMATION, i.f, "ELO Bronnen")
                }
                ,
                n.prototype.showUploadFailure = function(e, n) {
                    this.applicationService.showMessage(n, i.j.ERROR, i.f, "PROBLEEM!")
                }
                ,
                n.prototype.showOverschrijvenDialog = function(e, n) {
                    var t = this.$q.defer()
                      , r = "De bron <b>'" + e + "'</b> bestaat al in de map '<b>" + n + "</b>', overschrijven?";
                    return this.dialogService.showConfirm("Bron overschrijven", r, [o.a.Ok, o.a.Cancel], function(e) {
                        t.resolve(e.clickedButtonType === o.a.Ok)
                    }),
                    t.promise
                }
                ,
                n.prototype.removeFromParent = function(n, t) {
                    var r = t.bestanden;
                    r = e.without(r, e.findWhere(r, {
                        Naam: n.Naam
                    })),
                    t.bestanden = r
                }
                ,
                n.prototype.findDuplicate = function(n, t) {
                    var r = t.bestanden;
                    return e.findWhere(r, {
                        Naam: n.name
                    })
                }
                ,
                n.prototype.createUnserializedBron = function(e, n) {
                    return {
                        Id: 0,
                        Links: [],
                        BronSoort: s.Enums.BronSoort.Bestand,
                        Naam: e.name,
                        Referentie: 0,
                        Uri: "",
                        Grootte: e.size,
                        Privilege: s.Enums.BronPrivilege.Eigenaar,
                        Type: s.Enums.BronType.Document,
                        ContentType: e.type,
                        GewijzigdOp: new Date,
                        GeplaatstDoor: "",
                        GemaaktOp: new Date,
                        FileBlobId: 0,
                        ParentId: n.map.Id,
                        RootId: this.findRootId(n),
                        UniqueId: "",
                        Volgnr: 0,
                        ModuleSoort: Contracts.ELO.Enums.ModuleSoort.Bron
                    }
                }
                ,
                n.prototype.findRootId = function(e) {
                    return e.parent && 0 !== e.parent.Id ? this.findRootId(e.parent) : e.Id
                }
                ,
                n.prototype.uploadFile = function(e, n, t) {
                    var r = this
                      , i = this.$q.defer();
                    return this.fileService.uploadFile(e).then(function(e) {
                        n.UniqueId = e,
                        r.bronnenService.maakNieuweBron(r.currentUser.relatedPersons.current.id, n, t).then(function(e) {
                            e ? i.resolve(e) : i.reject()
                        }, function(e) {
                            i.reject(e)
                        })
                    }, function() {
                        i.reject()
                    }),
                    i.promise
                }
                ,
                n.prototype.targetIsOneDriveForBusiness = function(e) {
                    return this.findRootId(e) === a.a.OneDriveForBusiness
                }
                ,
                n.$inject = ["$q", "fileService", "bronnenService", "dialogService", "applicationService", "currentUser", n],
                n
            }()
        }
        ).call(this, t(3), t(1))
    },
    511: function(e, n, t) {
        "use strict";
        (function(e, r) {
            t.d(n, "a", function() {
                return d
            });
            var i = t(8)
              , o = t(85)
              , a = t(86)
              , s = t(0)
              , c = Contracts.Bronnen.Enums.BronType
              , d = function() {
                function n(e, n, t, r, i) {
                    this.$q = e,
                    this.bronnenService = n,
                    this.dialogService = t,
                    this.applicationService = r,
                    this.currentUser = i,
                    this.COPY_BRON_SUCCESS_MESSAGE = "De bron is succesvol gekopieerd.",
                    this.messageTitle = "ELO Bronnen"
                }
                return n.prototype.dropBron = function(e, n) {
                    return this.internalDropBron(e, n)
                }
                ,
                n.prototype.internalDropBron = function(n, t) {
                    var r = this
                      , i = this.$q.defer();
                    if (n.ParentId !== t.Id)
                        if (t.Id !== a.a.Prullenbak || !e.isDefined(n.Privilege) || n.Privilege !== Contracts.Bronnen.Enums.BronPrivilege.Eigenaar && n.Privilege !== Contracts.Bronnen.Enums.BronPrivilege.MapEigenaar && n.Privilege !== Contracts.Bronnen.Enums.BronPrivilege.Auteur) {
                            var s = this.findDuplicate(n, t);
                            (n.Type & c.OneDriveForBusiness) === c.OneDriveForBusiness ? (n.Type & c.Map) !== c.Map && (e.isDefined(s) ? this.showOverschrijvenDialog(n.Naam, t.map.Naam).then(function(e) {
                                e ? r.bronnenService.verwijderBron(r.currentUser.person.id, s.Id).then(function(e) {
                                    r.dropOneDriveForBusinessFile(n, t).then(function(e) {
                                        i.resolve(e)
                                    })
                                }) : i.resolve(!1)
                            }) : this.dropOneDriveForBusinessFile(n, t).then(function(e) {
                                i.resolve(e)
                            })) : e.isDefined(s) ? this.showOverschrijvenDialog(n.Naam, t.map.Naam).then(function(e) {
                                t.RootId = r.bronnenService.findRootId(t),
                                e && t.RootId !== a.a.OneDriveForBusiness ? r.bronnenService.verwijderBron(r.currentUser.person.id, s.Id).then(function(e) {
                                    r.finishDrop(n, t).then(function(e) {
                                        i.resolve(e)
                                    })
                                }) : e ? r.finishDrop(n, t).then(function(e) {
                                    i.resolve(e)
                                }) : i.resolve(!1)
                            }) : this.finishDrop(n, t).then(function(e) {
                                i.resolve(e)
                            }, function(e) {
                                i.reject(e)
                            })
                        } else {
                            var d = (n.Type & c.Map) === c.Map ? "De bron <b>'" + n.Naam + "'</b> en alle onderliggende items verwijderen?<br><br>De verwijderde bron en alle onderliggende items worden <b>automatisch na 8 dagen definitief verwijderd</b> uit de prullenbak." : "De bron <b>'" + n.Naam + "'</b> verwijderen?<br><br>De verwijderde bron wordt <b>automatisch na 8 dagen definitief verwijderd</b> uit de prullenbak.";
                            this.dialogService.showConfirm("Bron verwijderen", d, [o.a.Ok, o.a.Cancel], function(e) {
                                e.clickedButtonType === o.a.Ok && r.finishDrop(n, t).then(function(e) {
                                    i.resolve(e)
                                }, function(e) {
                                    i.reject(e)
                                })
                            })
                        }
                    return i.promise
                }
                ,
                n.prototype.dropOneDriveForBusinessFile = function(e, n) {
                    var t = this
                      , r = this.$q.defer()
                      , o = Object(s.j)(e.Links, s.a.toLocal);
                    return this.bronnenService.oneDriveForBusinessToLocal(o).then(function(o) {
                        var a = {
                            Id: 0,
                            Links: [],
                            BronSoort: Contracts.Bronnen.Enums.BronSoort.Bestand,
                            Naam: e.Naam,
                            Referentie: 0,
                            Uri: "",
                            Grootte: e.Grootte,
                            Privilege: Contracts.Bronnen.Enums.BronPrivilege.Eigenaar,
                            Type: c.Document,
                            ContentType: e.ContentType,
                            GewijzigdOp: new Date,
                            GeplaatstDoor: "",
                            GemaaktOp: new Date,
                            FileBlobId: 0,
                            ParentId: n.Id,
                            UniqueId: o.id,
                            Volgnr: 0,
                            RootId: t.bronnenService.findRootId(n),
                            ModuleSoort: 1
                        };
                        t.bronnenService.maakNieuweBron(t.currentUser.relatedPersons.current.id, a, n).then(function(e) {
                            t.applicationService.showMessage(t.COPY_BRON_SUCCESS_MESSAGE, i.j.INFORMATION, 3e3, t.messageTitle),
                            r.resolve(!1)
                        })
                    }),
                    r.promise
                }
                ,
                n.prototype.findDuplicate = function(e, n) {
                    var t = n.bestanden;
                    return r.each(n.mappen, function(e) {
                        t.push(e.map)
                    }),
                    r.findWhere(t, {
                        Naam: e.Naam
                    })
                }
                ,
                n.prototype.showOverschrijvenDialog = function(e, n) {
                    var t = this.$q.defer()
                      , r = "De bron <b>'" + e + "'</b> bestaat al in de map '<b>" + n + "</b>', overschrijven?";
                    return this.dialogService.showConfirm("Bron overschrijven", r, [o.a.Ok, o.a.Cancel], function(e) {
                        t.resolve(e.clickedButtonType === o.a.Ok)
                    }),
                    t.promise
                }
                ,
                n.prototype.finishDrop = function(e, n) {
                    var t = this
                      , r = this.$q.defer()
                      , o = this.currentUser.person.id;
                    return e.ParentId = n.Id,
                    e.RootId = this.bronnenService.findRootId(n),
                    e.RootId === a.a.OneDriveForBusiness ? this.bronnenService.maakNieuweBron(o, e, n).then(function() {
                        t.applicationService.showMessage(t.COPY_BRON_SUCCESS_MESSAGE, i.j.INFORMATION, 3e3, t.messageTitle),
                        r.resolve(!1)
                    }, function(e) {
                        r.reject()
                    }) : this.bronnenService.wijzigBron(o, e.Id, e).then(function(e) {
                        t.applicationService.showMessage("De bron is succesvol verplaatst.", i.j.INFORMATION, 3e3, t.messageTitle),
                        r.resolve(!0)
                    }, function(e) {
                        r.reject()
                    }),
                    r.promise
                }
                ,
                n.$inject = ["$q", "bronnenService", "dialogService", "applicationService", "currentUser", n],
                n
            }()
        }
        ).call(this, t(1), t(3))
    },
    87: function(e, n, t) {
        "use strict";
        t.d(n, "a", function() {
            return r
        });
        var r = function() {
            function e() {}
            return e.Map = "map",
            e.Bestand = "bestand",
            e.Html = "html",
            e.Url = "url",
            e.DigitaalLesmateriaal = "digitaalLesmateriaal",
            e.Noordhoff = "noordhoff",
            e
        }()
    },
    92: function(e, n, t) {
        "use strict";
        t.d(n, "a", function() {
            return i
        });
        var r = t(0)
          , i = function() {
            function e(e, n) {
                this.fullName = e,
                this.isFolder = n,
                this.decomposeFileName(e)
            }
            return e.prototype.decomposeFileName = function(e) {
                !Object(r.w)(e) && e.length > 0 && ("." === e.substr(e.length - 1, 1) || -1 === e.lastIndexOf(".") ? this.name = e : (this.extension = e.substr(e.lastIndexOf(".") + 1, e.length),
                this.name = e.substr(0, e.lastIndexOf("."))))
            }
            ,
            e
        }()
    },
    93: function(e, n, t) {
        "use strict";
        (function(e, r) {
            t.d(n, "a", function() {
                return l
            });
            var i = t(89)
              , o = t(86)
              , a = t(0)
              , s = t(87)
              , c = t(92)
              , d = Contracts.Bronnen.Enums.BronType
              , l = function() {
                function n() {
                    this.videoExtensions = "mp4 avi 264 m2v vc1 yuv wmv f4v raw m2ts m3u8 ismv mov 3gpp 3gp 3g2 flv mkv m2v m1v mts ts trp mpg mpeg mp4 h264 mxf divx xvid vob asf",
                    this.audioExtensions = "aac aif aifc aiff au flac m4a mid midi mp3 mpa opus rmi snd wav",
                    this.IS_AANGEMELD_BIJ_KENNISNET_SESSIONCOOKIE_KEY = "isAangemeldBijKennisNet"
                }
                return n.prototype.getLink = function(e) {
                    switch (e.soort) {
                    case s.a.Url:
                        return e.url;
                    default:
                        return Object(a.m)(e.links, "download")
                    }
                }
                ,
                n.prototype.transformBronnen = function(n, t) {
                    var r = this;
                    return e.isUndefined(n) ? [] : n.map(function(e) {
                        return r.transformBron(e, t)
                    })
                }
                ,
                n.prototype.transformBron = function(e, n) {
                    return {
                        id: e.id,
                        parentId: e.parentId,
                        type: this.determineBronType(e),
                        rootMapId: n,
                        naam: e.naam,
                        privilege: e.privilege,
                        contentType: e.contentType,
                        grootte: e.grootte,
                        url: e.url,
                        links: e.links,
                        soort: e.soort,
                        gemaaktOp: e.gemaaktOp,
                        gewijzigdOp: e.gewijzigdOp,
                        mediaType: this.getMediaType(e.naam, e.url)
                    }
                }
                ,
                n.prototype.transformBronDtoToBron = function(e, n) {
                    return {
                        id: e.Id,
                        parentId: e.ParentId,
                        type: e.Type,
                        rootMapId: n,
                        naam: e.Naam,
                        privilege: this.firstCharacterToLowerCase(Contracts.Bronnen.Enums.BronPrivilege[e.Privilege]),
                        contentType: e.ContentType,
                        grootte: e.Grootte,
                        url: null,
                        links: e.Links,
                        soort: this.firstCharacterToLowerCase(Contracts.Bronnen.Enums.BronSoort[e.BronSoort]),
                        gemaaktOp: e.GemaaktOp,
                        gewijzigdOp: e.GewijzigdOp,
                        mediaType: null
                    }
                }
                ,
                n.prototype.firstCharacterToLowerCase = function(e) {
                    return e.slice(0, 1).toLowerCase() + e.slice(1)
                }
                ,
                n.prototype.determineBronType = function(e) {
                    var n = d.Onbekend;
                    return e.soort === s.a.Map && (n = d.Map),
                    e.soort === s.a.Bestand && (n = d.Document),
                    e.soort === s.a.Url && (n = d.Link),
                    n
                }
                ,
                n.prototype.getMediaType = function(e, n) {
                    var t = new c.a(e,!1).extension
                      , r = i.a.Anders;
                    return Object(a.u)(t) || (-1 !== this.videoExtensions.indexOf(t) && (r = i.a.Video),
                    -1 !== this.audioExtensions.indexOf(t) && (r = i.a.Audio)),
                    Object(a.u)(n) || -1 === n.indexOf("www.youtube.com") || (r = i.a.YouTube),
                    r
                }
                ,
                n.prototype.isFolder = function(e) {
                    return e.soort === s.a.Map
                }
                ,
                n.prototype.isFile = function(e) {
                    return e.soort === s.a.Bestand
                }
                ,
                n.prototype.convertToTreeNodes = function(e) {
                    var n = this;
                    return r.map(e, function(e) {
                        return n.convertToTreeNode(e)
                    })
                }
                ,
                n.prototype.convertToTreeNode = function(n) {
                    var t = {
                        id: n.id,
                        text: n.naam,
                        data: n
                    };
                    return e.isArray(n.links) || (t.data.links = this.createLinksArray(n)),
                    t
                }
                ,
                n.prototype.convertToListItems = function(e) {
                    var n = this;
                    return r.map(e, function(e) {
                        return n.convertToListItem(e)
                    })
                }
                ,
                n.prototype.convertToListItem = function(n) {
                    var t = {
                        id: n.id,
                        text: n.naam,
                        data: n
                    };
                    return e.isArray(n.links) || (t.data.links = this.createLinksArray(n)),
                    t
                }
                ,
                n.prototype.createLinksArray = function(e) {
                    var n = [];
                    return this.addLink(e, n, "self"),
                    this.addLink(e, n, "download"),
                    this.addLink(e, n, "parent"),
                    this.addLink(e, n, "children"),
                    n
                }
                ,
                n.prototype.addLink = function(e, n, t) {
                    Object(a.k)(e.links, t) && n.push({
                        rel: t,
                        href: e.links[t].href
                    })
                }
                ,
                n.prototype.convertToBron = function(e) {
                    return r.map(e, function(e) {
                        return e.data
                    })
                }
                ,
                n.prototype.isBronInRecycleBin = function(e) {
                    return e.rootMapId === o.a.Prullenbak
                }
                ,
                n.prototype.isMedia = function(e) {
                    return !Object(a.w)(e.mediaType) && r.contains([i.a.Audio, i.a.Video, i.a.YouTube], e.mediaType)
                }
                ,
                n.$inject = [n],
                n
            }()
        }
        ).call(this, t(1), t(3))
    },
    96: function(e, n, t) {
        "use strict";
        var r = function() {
            function e(e, n) {
                this.uris = n;
                var t = globalSettings.apiHost + "api/";
                this.detailResource = e(t + this.uris.root + "/:bronId", {
                    persoonId: "@persoonId",
                    bronId: "@Id"
                }, {
                    update: {
                        method: "PUT"
                    }
                }),
                this.rootResource = e(t + this.uris.root, {
                    persoonId: "@persoonId",
                    path: "@parentId",
                    bronId: "@bronId"
                }),
                this.rootItemsResource = e(t + this.uris.rootItems, {
                    persoonId: "@persoonId",
                    path: "@parentId",
                    bronId: "@bronId"
                }, {
                    save: {
                        method: "POST"
                    }
                }),
                this.mapItemsResource = e(t + this.uris.mapItems, {
                    persoonId: "@persoonId",
                    path: "@parentId",
                    bronId: "@bronId"
                }, {
                    save: {
                        method: "POST"
                    }
                }),
                this.downloadResource = e(t + this.uris.download, {
                    bronId: "@bronId"
                })
            }
            return e.prototype.root = function(e, n, t) {
                return this.rootResource.execute({
                    persoonId: e,
                    parentId: n,
                    bronId: t
                }).$promise
            }
            ,
            e.prototype.rootItems = function(e, n, t, r) {
                return this.rootItemsResource.execute({
                    persoonId: n,
                    uniqueId: t,
                    bronId: r
                }).$promise
            }
            ,
            e.prototype.saveRootItem = function(e, n) {
                var t = {
                    persoonId: n
                };
                return 0 === e.Id && e.UniqueId ? t.uniqueId = e.UniqueId : t.bronId = e.Id,
                this.rootItemsResource.save(t, e).$promise
            }
            ,
            e.prototype.saveItem = function(e, n, t) {
                var r = {
                    persoonId: n,
                    mapId: t
                };
                return 0 === e.Id && e.UniqueId ? r.uniqueId = e.UniqueId : r.bronId = e.Id,
                this.mapItemsResource.save(r, e).$promise
            }
            ,
            e.prototype.updateDetail = function(e, n, t) {
                return this.detailResource.update({
                    persoonId: n,
                    bronId: t
                }).$promise
            }
            ,
            e.prototype.download = function(e, n) {
                return this.detailResource.execute({
                    bronId: n
                }).$promise
            }
            ,
            e
        }();
        t.d(n, "a", function() {
            return a
        });
        var i, o = (i = Object.setPrototypeOf || {
            __proto__: []
        }instanceof Array && function(e, n) {
            e.__proto__ = n
        }
        || function(e, n) {
            for (var t in n)
                n.hasOwnProperty(t) && (e[t] = n[t])
        }
        ,
        function(e, n) {
            function t() {
                this.constructor = e
            }
            i(e, n),
            e.prototype = null === n ? Object.create(n) : (t.prototype = n.prototype,
            new t)
        }
        ), a = function(e) {
            function n(n) {
                return e.call(this, n, {
                    root: "documenten/onedriveforbusiness",
                    rootItems: "documenten/onedriveforbusiness/items",
                    map: "documenten/onedriveforbusiness/mappen/:mapId",
                    mapItems: "documenten/onedriveforbusiness/mappen/:mapId/items",
                    detail: "documenten/onedriveforbusiness/documenten/:documentId",
                    download: "documenten/onedriveforbusiness/documenten/:documentId/download",
                    toLocal: "documenten/onedriveforbusiness/documenten/:documentId/tolocal",
                    redirect: "documenten/onedriveforbusiness/documenten/:documentId/redirect"
                }) || this
            }
            return o(n, e),
            n.$inject = ["$resource", n],
            n
        }(r)
    }
}]);
